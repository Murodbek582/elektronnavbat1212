from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import Optional
from backend.database import fetch_all, fetch_one, insert, execute
from backend.auth import get_current_user, require_admin, log_audit

router = APIRouter(prefix="/api/reviews", tags=["Doctor Reviews"])

class DoctorReviewCreateRequest(BaseModel):
    doctor_id: int
    appointment_id: Optional[int] = None
    rating: int = Field(..., ge=1, le=5)
    comment: Optional[str] = None

@router.get("/doctor/{doctor_id}")
async def get_doctor_reviews(doctor_id: int):
    reviews = fetch_all("""
        SELECT dr.*, p.full_name as patient_name
        FROM doctor_reviews dr
        JOIN patients p ON dr.patient_id = p.id
        WHERE dr.doctor_id = ? AND dr.is_approved = 1
        ORDER BY dr.id DESC LIMIT 30
    """, (doctor_id,))

    stats = fetch_one("""
        SELECT COUNT(id) as total_reviews, COALESCE(AVG(rating), 5.0) as avg_rating
        FROM doctor_reviews
        WHERE doctor_id = ? AND is_approved = 1
    """, (doctor_id,))

    return {
        "reviews": reviews,
        "total_reviews": stats["total_reviews"],
        "avg_rating": round(stats["avg_rating"], 1)
    }

@router.post("")
async def create_doctor_review(req: DoctorReviewCreateRequest, current_user: dict = Depends(get_current_user)):
    patient = fetch_one("SELECT id, full_name FROM patients WHERE user_id = ?", (current_user["id"],))
    if not patient:
        raise HTTPException(status_code=400, detail="Faqat ro'yxatdan o'tgan bemorlar shifokorga baho bera oladi")

    # Insert review
    rev_id = insert("""
        INSERT INTO doctor_reviews (doctor_id, patient_id, appointment_id, rating, comment, is_approved)
        VALUES (?, ?, ?, ?, ?, 1)
    """, (req.doctor_id, patient["id"], req.appointment_id, req.rating, req.comment))

    log_audit(current_user["id"], "LEAVE_REVIEW", "doctor_reviews", str(rev_id), details=f"Rating: {req.rating}")
    return {"message": "Baholash va fikringiz uchun tashakkur! Sharhingiz e'lon qilindi.", "id": rev_id}

@router.get("/all", dependencies=[Depends(require_admin)])
async def get_all_reviews():
    reviews = fetch_all("""
        SELECT dr.*, p.full_name as patient_name, d.full_name as doctor_name
        FROM doctor_reviews dr
        JOIN patients p ON dr.patient_id = p.id
        JOIN doctors d ON dr.doctor_id = d.id
        ORDER BY dr.id DESC LIMIT 50
    """)
    return {"reviews": reviews}
