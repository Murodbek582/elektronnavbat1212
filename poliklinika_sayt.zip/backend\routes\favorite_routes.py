from fastapi import APIRouter, HTTPException, Depends
from backend.database import fetch_all, fetch_one, insert, execute
from backend.auth import get_current_user

router = APIRouter(prefix="/api/favorites", tags=["Favorite Doctors"])

@router.get("/my")
async def get_my_favorites(current_user: dict = Depends(get_current_user)):
    patient = fetch_one("SELECT id FROM patients WHERE user_id = ?", (current_user["id"],))
    if not patient:
        return {"favorites": []}

    favorites = fetch_all("""
        SELECT fd.id as fav_id, d.*, dep.name_uz as department_name_uz, dep.code as department_code
        FROM favorite_doctors fd
        JOIN doctors d ON fd.doctor_id = d.id
        JOIN departments dep ON d.department_id = dep.id
        WHERE fd.patient_id = ? AND d.is_active = 1
    """, (patient["id"],))

    return {"favorites": favorites}

@router.post("/toggle/{doctor_id}")
async def toggle_favorite(doctor_id: int, current_user: dict = Depends(get_current_user)):
    patient = fetch_one("SELECT id FROM patients WHERE user_id = ?", (current_user["id"],))
    if not patient:
        raise HTTPException(status_code=400, detail="Bemor hisobi topilmadi")

    existing = fetch_one("""
        SELECT id FROM favorite_doctors WHERE patient_id = ? AND doctor_id = ?
    """, (patient["id"], doctor_id))

    if existing:
        execute("DELETE FROM favorite_doctors WHERE id = ?", (existing["id"],))
        return {"favorited": False, "message": "Shifokor sevimlilar ro'yxatidan chiqarildi"}
    else:
        insert("""
            INSERT INTO favorite_doctors (patient_id, doctor_id)
            VALUES (?, ?)
        """, (patient["id"], doctor_id))
        return {"favorited": True, "message": "Shifokor sevimlilar ro'yxatiga qo'shildi"}
