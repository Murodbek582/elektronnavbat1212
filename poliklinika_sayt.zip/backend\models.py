from pydantic import BaseModel, Field, field_validator
from typing import Optional
import re

class LoginRequest(BaseModel):
    username: str = Field(..., description="Email, telefon raqami yoki 14 xonali JShShIR")
    password: str = Field(..., min_length=4)

class PatientRegisterRequest(BaseModel):
    full_name: str = Field(..., min_length=3, max_length=120)
    pinfl: str = Field(..., description="14 xonali JShShIR raqami")
    phone: str = Field(..., description="Telefon raqami masalan +998901234567")
    birth_date: str = Field(..., description="YYYY-MM-DD")
    gender: Optional[str] = "male"
    password: str = Field(..., min_length=6)
    address: Optional[str] = None
    blood_group: Optional[str] = None

    @field_validator("pinfl")
    @classmethod
    def validate_pinfl(cls, v: str) -> str:
        clean = v.strip()
        if not re.match(r"^\d{14}$", clean):
            raise ValueError("JShShIR (PINFL) aynan 14 ta raqamdan iborat bo'lishi shart!")
        return clean

    @field_validator("phone")
    @classmethod
    def validate_phone(cls, v: str) -> str:
        clean = re.sub(r"[\s\-\(\)]", "", v.strip())
        if not re.match(r"^\+?998\d{9}$", clean):
            raise ValueError("Telefon raqami O'zbekiston formatida (+998XXXXXXXXX) kiritilishi lozim")
        if not clean.startswith("+"):
            clean = "+" + clean
        return clean

class DoctorCreateRequest(BaseModel):
    full_name: str = Field(..., min_length=3)
    department_id: int
    specialization_uz: str
    specialization_ru: str
    specialization_en: str
    room_number: str
    phone: Optional[str] = None
    email: Optional[str] = None
    password: Optional[str] = "Doctor123!"
    appointment_duration: int = 20
    working_days: str = "1,2,3,4,5"
    start_time: str = "08:30"
    end_time: str = "17:30"
    photo_url: Optional[str] = None
    bio_uz: Optional[str] = None
    bio_ru: Optional[str] = None
    bio_en: Optional[str] = None

class DoctorUpdateRequest(BaseModel):
    full_name: Optional[str] = None
    department_id: Optional[int] = None
    specialization_uz: Optional[str] = None
    specialization_ru: Optional[str] = None
    specialization_en: Optional[str] = None
    room_number: Optional[str] = None
    phone: Optional[str] = None
    appointment_duration: Optional[int] = None
    working_days: Optional[str] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    is_active: Optional[bool] = None
    photo_url: Optional[str] = None
    bio_uz: Optional[str] = None

class DepartmentCreateRequest(BaseModel):
    name_uz: str
    name_ru: str
    name_en: str
    code: str
    description_uz: Optional[str] = None
    description_ru: Optional[str] = None
    description_en: Optional[str] = None
    icon: Optional[str] = "stethoscope"

class AppointmentBookRequest(BaseModel):
    doctor_id: int
    department_id: Optional[int] = None
    appointment_date: str = Field(..., description="YYYY-MM-DD")
    start_time: str = Field(..., description="HH:MM masalan 09:00")
    reason: Optional[str] = "Ko'rik va maslahat"
    patient_id: Optional[int] = None # When booked by reception or admin
    patient_name: Optional[str] = None
    patient_phone: Optional[str] = None
    patient_pinfl: Optional[str] = None
    patient_birth_date: Optional[str] = None
    patient_gender: Optional[str] = "male"
    patient_address: Optional[str] = None

class AppointmentCancelRequest(BaseModel):
    reason: str = Field(..., min_length=3)

class CallQueueRequest(BaseModel):
    doctor_id: Optional[int] = None
    room_number: Optional[str] = None

class CompleteAppointmentRequest(BaseModel):
    notes: Optional[str] = None
    diagnosis: Optional[str] = None

class PasswordResetRequest(BaseModel):
    email_or_phone: str
    pinfl: Optional[str] = None
    new_password: str = Field(..., min_length=6)

class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str = Field(..., min_length=6)

class SMSGatewayConfigRequest(BaseModel):
    provider: str = Field(..., description="'demo', 'eskiz', or 'playmobile'")
    api_key: Optional[str] = ""
    sender_name: Optional[str] = "Poliklinika"
