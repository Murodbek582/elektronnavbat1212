import sqlite3
import os
from contextlib import contextmanager
from datetime import datetime
from backend.config import DATABASE_URL

def get_connection():
    conn = sqlite3.connect(DATABASE_URL, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    return conn

@contextmanager
def get_db():
    conn = get_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def fetch_one(query: str, params: tuple = ()):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        row = cursor.fetchone()
        return dict(row) if row else None

def fetch_all(query: str, params: tuple = ()):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = cursor.fetchall()
        return [dict(row) for row in rows]

def execute(query: str, params: tuple = ()):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        return cursor.rowcount

def insert(query: str, params: tuple = ()):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        return cursor.lastrowid

def init_db():
    schema = """
    -- Users Table
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE,
        phone TEXT UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin', 'doctor', 'patient')),
        full_name TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Departments Table
    CREATE TABLE IF NOT EXISTS departments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name_uz TEXT NOT NULL,
        name_ru TEXT NOT NULL,
        name_en TEXT NOT NULL,
        code TEXT UNIQUE NOT NULL,
        description_uz TEXT,
        description_ru TEXT,
        description_en TEXT,
        icon TEXT DEFAULT 'stethoscope',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Doctors Table
    CREATE TABLE IF NOT EXISTS doctors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE,
        department_id INTEGER NOT NULL,
        full_name TEXT NOT NULL,
        specialization_uz TEXT NOT NULL,
        specialization_ru TEXT NOT NULL,
        specialization_en TEXT NOT NULL,
        room_number TEXT NOT NULL,
        photo_url TEXT,
        phone TEXT,
        appointment_duration INTEGER NOT NULL DEFAULT 20, -- minutes
        working_days TEXT NOT NULL DEFAULT '1,2,3,4,5',   -- Monday to Friday
        start_time TEXT NOT NULL DEFAULT '08:30',
        end_time TEXT NOT NULL DEFAULT '17:30',
        is_active INTEGER NOT NULL DEFAULT 1,
        bio_uz TEXT,
        bio_ru TEXT,
        bio_en TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
        FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE RESTRICT
    );

    -- Patients Table
    CREATE TABLE IF NOT EXISTS patients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE,
        pinfl TEXT UNIQUE NOT NULL, -- 14 digits
        full_name TEXT NOT NULL,
        birth_date TEXT NOT NULL,   -- YYYY-MM-DD
        gender TEXT CHECK(gender IN ('male', 'female', 'other')),
        phone TEXT NOT NULL,
        address TEXT,
        blood_group TEXT,
        is_verified INTEGER NOT NULL DEFAULT 1, -- Verification status from state API / demo
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    -- Doctor Schedules Table
    CREATE TABLE IF NOT EXISTS doctor_schedules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        doctor_id INTEGER NOT NULL,
        day_of_week INTEGER NOT NULL CHECK(day_of_week BETWEEN 0 AND 6), -- 0=Monday, 6=Sunday
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        slot_duration INTEGER NOT NULL DEFAULT 20,
        max_patients_per_slot INTEGER NOT NULL DEFAULT 1,
        is_active INTEGER NOT NULL DEFAULT 1,
        FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
    );

    -- Appointments Table
    CREATE TABLE IF NOT EXISTS appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        appointment_number TEXT UNIQUE NOT NULL,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        department_id INTEGER NOT NULL,
        appointment_date TEXT NOT NULL, -- YYYY-MM-DD
        start_time TEXT NOT NULL,       -- HH:MM
        end_time TEXT NOT NULL,         -- HH:MM
        status TEXT NOT NULL DEFAULT 'waiting' CHECK(status IN ('waiting', 'in_consultation', 'completed', 'cancelled', 'absent')),
        reason TEXT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE RESTRICT,
        FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE RESTRICT,
        FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE RESTRICT
    );

    -- Queue Tickets Table
    CREATE TABLE IF NOT EXISTS queue_tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        appointment_id INTEGER UNIQUE NOT NULL,
        ticket_number TEXT NOT NULL, -- e.g. TR-001
        queue_date TEXT NOT NULL,    -- YYYY-MM-DD
        priority_number INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'waiting' CHECK(status IN ('waiting', 'calling', 'serving', 'completed', 'cancelled', 'absent')),
        called_at TIMESTAMP,
        served_at TIMESTAMP,
        room_number TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE CASCADE,
        UNIQUE(ticket_number, queue_date)
    );

    -- Notifications Table
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        type TEXT NOT NULL DEFAULT 'system' CHECK(type IN ('booking', 'cancellation', 'queue_call', 'reminder', 'system')),
        channel TEXT NOT NULL DEFAULT 'in_app' CHECK(channel IN ('in_app', 'sms')),
        delivery_status TEXT NOT NULL DEFAULT 'delivered' CHECK(delivery_status IN ('delivered', 'simulated', 'failed')),
        is_read INTEGER NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    -- Audit Logs Table
    CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT NOT NULL,
        entity_type TEXT NOT NULL,
        entity_id TEXT,
        ip_address TEXT,
        details TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    -- System Configuration Table
    CREATE TABLE IF NOT EXISTS system_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        description TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Clinic Services Catalog Table
    CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        department_id INTEGER NOT NULL,
        name_uz TEXT NOT NULL,
        name_ru TEXT NOT NULL,
        name_en TEXT NOT NULL,
        description_uz TEXT,
        description_ru TEXT,
        description_en TEXT,
        price INTEGER NOT NULL DEFAULT 0, -- In UZS (e.g. 50000)
        duration_minutes INTEGER NOT NULL DEFAULT 20,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE RESTRICT
    );

    -- Digital Medical Documents Table
    CREATE TABLE IF NOT EXISTS medical_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER,
        appointment_id INTEGER,
        doc_type TEXT NOT NULL CHECK(doc_type IN ('visit_summary', 'prescription_rec', 'lab_result', 'ticket', 'general')),
        title TEXT NOT NULL,
        content_json TEXT, -- JSON structure with anamnesis, diagnosis, recommendations, lab indicators
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
        FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE SET NULL,
        FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE SET NULL
    );

    -- Doctor Reviews and Star Ratings
    CREATE TABLE IF NOT EXISTS doctor_reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        doctor_id INTEGER NOT NULL,
        patient_id INTEGER NOT NULL,
        appointment_id INTEGER,
        rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
        comment TEXT,
        is_approved INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE,
        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
        FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE SET NULL
    );

    -- Favorite Doctors Table
    CREATE TABLE IF NOT EXISTS favorite_doctors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(patient_id, doctor_id),
        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
        FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
    );

    -- AI Knowledge Base (Editable by Admin)
    CREATE TABLE IF NOT EXISTS ai_knowledge_base (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category TEXT NOT NULL CHECK(category IN ('clinic', 'doctor', 'department', 'service', 'rules', 'faq', 'contact', 'preparation')),
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        keywords TEXT,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Clinic Announcements Table
    CREATE TABLE IF NOT EXISTS clinic_announcements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        priority TEXT NOT NULL DEFAULT 'normal' CHECK(priority IN ('normal', 'high', 'urgent')),
        target_role TEXT NOT NULL DEFAULT 'all',
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- System Monitoring Logs Table
    CREATE TABLE IF NOT EXISTS system_metrics_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cpu_percent REAL,
        memory_percent REAL,
        disk_percent REAL,
        active_connections INTEGER DEFAULT 0,
        response_time_ms REAL DEFAULT 0,
        status TEXT DEFAULT 'healthy',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Indexes for high performance
    CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
    CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
    CREATE INDEX IF NOT EXISTS idx_patients_pinfl ON patients(pinfl);
    CREATE INDEX IF NOT EXISTS idx_patients_user ON patients(user_id);
    CREATE INDEX IF NOT EXISTS idx_doctors_dept ON doctors(department_id);
    CREATE INDEX IF NOT EXISTS idx_doctors_active ON doctors(is_active);
    CREATE INDEX IF NOT EXISTS idx_appts_date_doc ON appointments(appointment_date, doctor_id);
    CREATE INDEX IF NOT EXISTS idx_appts_patient ON appointments(patient_id);
    CREATE INDEX IF NOT EXISTS idx_appts_status ON appointments(status);
    CREATE INDEX IF NOT EXISTS idx_queue_date_status ON queue_tickets(queue_date, status);
    CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
    CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);
    CREATE INDEX IF NOT EXISTS idx_services_dept ON services(department_id);
    CREATE INDEX IF NOT EXISTS idx_med_docs_patient ON medical_documents(patient_id);
    CREATE INDEX IF NOT EXISTS idx_reviews_doctor ON doctor_reviews(doctor_id);
    CREATE INDEX IF NOT EXISTS idx_ai_kb_cat ON ai_knowledge_base(category);
    CREATE INDEX IF NOT EXISTS idx_ai_kb_active ON ai_knowledge_base(is_active);
    """
    with get_db() as conn:
        conn.executescript(schema)
