/**
 * MEDI AI - Smart Medical Healthcare Assistant
 * Elektron Navbat Polyclinic Platform
 * Complete Voice Input/Output, Multilingual (UZ/RU/EN), Resilient Error Handling & Context History
 */

// Global State
let mediAiOpen = false;
let mediAiHistory = [];
let mediAiLang = localStorage.getItem("poliklinika_lang") || "uz";
let mediAiListening = false;
let currentSpeakingUtterance = null;
let lastUserMessage = "";

const MEDI_AI_STORAGE_KEY = "poliklinika_medi_ai_history_v2";

// Localized Dictionary for MEDI AI Widget
const MEDI_AI_LOCALES = {
    uz: {
        title: "MEDI AI",
        subtitle: "Aqlli tibbiy yordamchi",
        placeholder: "Savolingizni erkin yozing (masalan: bosh og'rig'i, ish vaqti)...",
        send: "Yuborish",
        welcome: "Assalomu alaykum! Men MEDI AI — poliklinikaning aqlli tibbiy yordamchisiman. Sizga qanday yordam bera olaman?",
        typing: "MEDI AI javob tayyorlamoqda...",
        disclaimer: "⚕️ Bu tibbiy maslahat emas. Aniq tashxis uchun shifokorga murojaat qiling.",
        emergency_msg: "🚨 SHOSHILINCH HOLAT ANIQLANDI! Darhol 103 ga qo'ng'iroq qiling!",
        call_103: "📞 103 ga qo'ng'iroq qilish",
        dismiss: "Yopish",
        quick_actions: [
            "📅 Navbat olish",
            "🩺 Shifokorlar ro'yxati",
            "⏰ Ish vaqti",
            "📍 Manzil va telefon",
            "🔬 Tahlil narxlari",
            "📋 Talon holati"
        ],
        book_btn: "Navbat olish",
        copy_btn: "Nusxa",
        copied: "Nusxalandi!",
        speak_btn: "Ovoz",
        stop_btn: "To'xtatish",
        regen_btn: "Qayta",
        clear_btn: "Tozalash",
        new_chat_btn: "Yangi suhbat",
        error_msg: "AI javob tayyorlashda xatolik yuz berdi. Iltimos qayta urinib ko'ring.",
        retry_btn: "Qayta urinish",
        listening: "Tinglanmoqda... Gapiring",
        mic_title: "Ovoz bilan so'rang"
    },
    ru: {
        title: "MEDI AI",
        subtitle: "Умный медицинский помощник",
        placeholder: "Задайте ваш вопрос свободно (например: болит голова, терапевт)...",
        send: "Отправить",
        welcome: "Здравствуйте! Я MEDI AI — умный медицинский помощник поликлиники. Чем я могу вам помочь?",
        typing: "MEDI AI готовит ответ...",
        disclaimer: "⚕️ Это не медицинская консультация. Для точного диагноза обратитесь к врачу.",
        emergency_msg: "🚨 ЭКСТРЕННАЯ СИТУАЦИЯ! Срочно вызовите скорую помощь по номеру 103!",
        call_103: "📞 Позвонить 103",
        dismiss: "Закрыть",
        quick_actions: [
            "📅 Записаться в очередь",
            "🩺 Список врачей",
            "⏰ График работы",
            "📍 Адрес и телефон",
            "🔬 Цены на анализы",
            "📋 Статус талона"
        ],
        book_btn: "Записаться",
        copy_btn: "Копия",
        copied: "Скопировано!",
        speak_btn: "Озвучить",
        stop_btn: "Стоп",
        regen_btn: "Повторить",
        clear_btn: "Очистить",
        new_chat_btn: "Новый чат",
        error_msg: "Произошла ошибка при ответе ИИ. Пожалуйста, попробуйте еще раз.",
        retry_btn: "Повторить",
        listening: "Слушаю... Говорите",
        mic_title: "Голосовой ввод"
    },
    en: {
        title: "MEDI AI",
        subtitle: "Smart Medical Assistant",
        placeholder: "Type your question freely (e.g. headache, working hours)...",
        send: "Send",
        welcome: "Hello! I am MEDI AI — your smart healthcare assistant. How can I help you today?",
        typing: "MEDI AI is typing an answer...",
        disclaimer: "⚕️ This is not medical advice. Consult a doctor for accurate diagnosis.",
        emergency_msg: "🚨 MEDICAL EMERGENCY DETECTED! Call 103 immediately!",
        call_103: "📞 Call 103",
        dismiss: "Dismiss",
        quick_actions: [
            "📅 Book Appointment",
            "🩺 Doctors List",
            "⏰ Working Hours",
            "📍 Address & Contact",
            "🔬 Diagnostic Fees",
            "📋 Check Ticket"
        ],
        book_btn: "Book Appointment",
        copy_btn: "Copy",
        copied: "Copied!",
        speak_btn: "Speak",
        stop_btn: "Stop",
        regen_btn: "Regenerate",
        clear_btn: "Clear",
        new_chat_btn: "New Chat",
        error_msg: "An error occurred while contacting AI. Please try again.",
        retry_btn: "Retry",
        listening: "Listening... Speak now",
        mic_title: "Voice Input"
    }
};

function getMediText(key) {
    const loc = MEDI_AI_LOCALES[mediAiLang] || MEDI_AI_LOCALES["uz"];
    return loc[key] || MEDI_AI_LOCALES["uz"][key] || key;
}

// Save & Load Chat History from LocalStorage
function saveMediAiHistoryToStorage() {
    try {
        localStorage.setItem(MEDI_AI_STORAGE_KEY, JSON.stringify(mediAiHistory.slice(-20)));
    } catch (e) {}
}

function loadMediAiHistoryFromStorage() {
    try {
        const stored = localStorage.getItem(MEDI_AI_STORAGE_KEY);
        if (stored) {
            mediAiHistory = JSON.parse(stored) || [];
        }
    } catch (e) {
        mediAiHistory = [];
    }
}

// ─── Injection of Styles & Widget DOM ─────────────────────────────────────────
function injectMediAiHTML() {
    if (document.getElementById("medi-ai-root")) return;

    const style = document.createElement("style");
    style.id = "medi-ai-styles";
    style.textContent = `
        @keyframes mediPulse {
            0%, 100% { transform: scale(1); opacity: 0.6; }
            50% { transform: scale(1.3); opacity: 0; }
        }
        @keyframes mediSlideUp {
            from { opacity: 0; transform: translateY(20px) scale(0.97); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes mediSlideDown {
            from { opacity: 1; transform: translateY(0) scale(1); }
            to { opacity: 0; transform: translateY(20px) scale(0.97); }
        }
        @keyframes mediDot {
            0%, 80%, 100% { transform: scale(0.6); opacity: 0.4; }
            40% { transform: scale(1); opacity: 1; }
        }
        #medi-ai-panel {
            animation: mediSlideUp 0.25s cubic-bezier(0.16,1,0.3,1) forwards;
        }
        #medi-ai-panel.closing {
            animation: mediSlideDown 0.2s ease-in forwards;
        }
        .medi-ai-typing-dot {
            display: inline-block;
            width: 7px; height: 7px;
            border-radius: 50%;
            background: #3b82f6;
            margin: 0 2px;
        }
        .medi-ai-typing-dot:nth-child(1) { animation: mediDot 1.2s infinite 0s; }
        .medi-ai-typing-dot:nth-child(2) { animation: mediDot 1.2s infinite 0.2s; }
        .medi-ai-typing-dot:nth-child(3) { animation: mediDot 1.2s infinite 0.4s; }
        .medi-pulse-ring {
            position: absolute; inset: 0;
            border-radius: 50%;
            border: 3px solid rgba(59,130,246,0.6);
            animation: mediPulse 2s ease-out infinite;
        }
        #medi-ai-chat-area::-webkit-scrollbar { width: 5px; }
        #medi-ai-chat-area::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 5px; }
        .medi-chip {
            padding: 5px 12px;
            border-radius: 9999px;
            background: #eff6ff;
            color: #1d4ed8;
            font-size: 11.5px;
            font-weight: 600;
            border: 1px solid #bfdbfe;
            white-space: nowrap;
            cursor: pointer;
            transition: all 0.15s ease;
        }
        .medi-chip:hover {
            background: #dbeafe;
            transform: translateY(-1px);
        }
        .medi-action-btn {
            font-size: 10px;
            font-weight: 700;
            padding: 2px 7px;
            border-radius: 6px;
            background: #f1f5f9;
            color: #475569;
            border: 1px solid #e2e8f0;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 3px;
            transition: all 0.15s;
        }
        .medi-action-btn:hover {
            background: #e2e8f0;
            color: #0f172a;
        }
    `;
    document.head.appendChild(style);

    const wrapper = document.createElement("div");
    wrapper.id = "medi-ai-root";
    wrapper.innerHTML = `
        <!-- Floating Animated Launcher Button -->
        <button id="medi-ai-fab"
            onclick="toggleMediAi()"
            aria-label="MEDI AI"
            style="position:fixed;bottom:1.5rem;right:1.5rem;z-index:50;
                   width:60px;height:60px;border-radius:50%;border:none;cursor:pointer;
                   background:linear-gradient(135deg,#2563eb,#0d9488);
                   box-shadow:0 10px 30px rgba(37,99,235,0.4);
                   display:flex;align-items:center;justify-content:center;
                   transition:transform 0.2s ease;">
            <span class="medi-pulse-ring"></span>
            <!-- Medical Cross SVG -->
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                <rect x="11" y="4" width="6" height="20" rx="2" fill="white"/>
                <rect x="4" y="11" width="20" height="6" rx="2" fill="white"/>
            </svg>
        </button>

        <!-- Main Chat Panel -->
        <div id="medi-ai-panel"
            style="display:none;position:fixed;bottom:6rem;right:1.5rem;z-index:50;
                   width:23rem;max-width:calc(100vw - 2rem);
                   border-radius:1.5rem;overflow:hidden;
                   background:#ffffff;
                   box-shadow:0 25px 60px rgba(15,23,42,0.2), 0 8px 24px rgba(37,99,235,0.15);
                   border:1px solid #e2e8f0;">

            <!-- Header -->
            <div style="background:linear-gradient(135deg,#1d4ed8,#0f766e);padding:14px 16px;display:flex;align-items:center;justify-content:space-between;color:#fff;">
                <div style="display:flex;align-items:center;gap:10px;">
                    <div style="width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,0.2);display:flex;align-items:center;justify-content:center;">
                        <svg width="20" height="20" viewBox="0 0 28 28" fill="none">
                            <rect x="11" y="4" width="6" height="20" rx="2" fill="white"/>
                            <rect x="4" y="11" width="20" height="6" rx="2" fill="white"/>
                        </svg>
                    </div>
                    <div>
                        <div style="font-weight:800;font-size:15px;line-height:1.1;" id="medi-ai-header-title">MEDI AI</div>
                        <div style="font-size:11px;opacity:0.85;" id="medi-ai-header-subtitle">Aqlli tibbiy yordamchi</div>
                    </div>
                </div>

                <div style="display:flex;align-items:center;gap:6px;">
                    <!-- New Chat -->
                    <button onclick="startNewMediAiChat()" title="Yangi suhbat"
                            style="background:rgba(255,255,255,0.15);border:none;color:#fff;width:28px;height:28px;border-radius:8px;cursor:pointer;font-size:13px;display:flex;align-items:center;justify-content:center;">
                        🔄
                    </button>
                    <!-- Clear -->
                    <button onclick="clearMediAiChat()" title="Tarixni tozalash"
                            style="background:rgba(255,255,255,0.15);border:none;color:#fff;width:28px;height:28px;border-radius:8px;cursor:pointer;font-size:12px;display:flex;align-items:center;justify-content:center;">
                        🗑️
                    </button>
                    <!-- Language selector -->
                    <select id="medi-ai-lang-select" onchange="setMediAiLang(this.value)"
                            style="background:rgba(255,255,255,0.18);color:#fff;border:1px solid rgba(255,255,255,0.3);border-radius:8px;padding:3px 6px;font-size:11px;cursor:pointer;outline:none;font-weight:700;">
                        <option value="uz" style="color:#0f172a;">🇺🇿 UZ</option>
                        <option value="ru" style="color:#0f172a;">🇷🇺 RU</option>
                        <option value="en" style="color:#0f172a;">🇬🇧 EN</option>
                    </select>
                    <!-- Close -->
                    <button onclick="closeMediAi()"
                            style="background:rgba(255,255,255,0.15);border:none;color:#fff;width:28px;height:28px;border-radius:8px;cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center;line-height:1;">
                        ✕
                    </button>
                </div>
            </div>

            <!-- Emergency Banner -->
            <div id="medi-ai-emergency-banner" style="display:none;background:#ef4444;color:#fff;padding:10px 14px;align-items:center;justify-content:space-between;gap:8px;">
                <span id="medi-ai-emergency-text" style="font-size:12px;font-weight:700;line-height:1.3;flex:1;"></span>
                <button onclick="window.location.href='tel:103'" style="background:#fff;color:#dc2626;border:none;border-radius:8px;padding:5px 9px;font-size:11px;font-weight:800;cursor:pointer;white-space:nowrap;">
                    📞 103
                </button>
            </div>

            <!-- Chat Area -->
            <div id="medi-ai-chat-area"
                style="height:18rem;overflow-y:auto;padding:14px;background:#f8fafc;display:flex;flex-direction:column;gap:10px;">
                <!-- Bubbles -->
            </div>

            <!-- Typing indicator -->
            <div id="medi-ai-typing" style="display:none;padding:4px 14px 8px;background:#f8fafc;">
                <div style="display:inline-flex;align-items:center;gap:4px;background:#fff;border-radius:14px;padding:6px 12px;box-shadow:0 1px 4px rgba(0,0,0,0.06);">
                    <span class="medi-ai-typing-dot"></span>
                    <span class="medi-ai-typing-dot"></span>
                    <span class="medi-ai-typing-dot"></span>
                    <span style="font-size:11px;color:#64748b;margin-left:4px;" id="medi-ai-typing-label">Yozmoqda...</span>
                </div>
            </div>

            <!-- Quick Action Chips -->
            <div style="background:#f8fafc;padding:6px 12px;border-top:1px solid #e2e8f0;overflow-x:auto;">
                <div id="medi-ai-quick-scroll" style="display:flex;gap:6px;padding-bottom:2px;">
                    <!-- Rendered by renderQuickActions() -->
                </div>
            </div>

            <!-- Input Bar -->
            <div style="padding:10px 12px;background:#fff;border-top:1px solid #e2e8f0;display:flex;align-items:center;gap:6px;">
                <input id="medi-ai-input"
                    type="text"
                    placeholder="Savolingizni yozing..."
                    onkeydown="if(event.key==='Enter')sendMediAiMessage(this.value)"
                    style="flex:1;border:1.5px solid #e2e8f0;border-radius:12px;padding:9px 12px;font-size:13.5px;outline:none;background:#f8fafc;transition:border-color 0.15s;"
                    onfocus="this.style.borderColor='#3b82f6'"
                    onblur="this.style.borderColor='#e2e8f0'"
                />
                <!-- Mic -->
                <button id="medi-ai-mic-btn"
                    onclick="startMediAiVoice()"
                    title="Ovozli qidiruv"
                    style="width:36px;height:36px;border-radius:10px;border:1px solid #e2e8f0;background:#f8fafc;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all 0.15s;">
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#64748b" stroke-width="2">
                        <rect x="9" y="2" width="6" height="12" rx="3"/>
                        <path d="M5 10a7 7 0 0 0 14 0"/>
                        <line x1="12" y1="17" x2="12" y2="22"/>
                        <line x1="8" y1="22" x2="16" y2="22"/>
                    </svg>
                </button>
                <!-- Send -->
                <button id="medi-ai-send-btn"
                    onclick="sendMediAiMessage(document.getElementById('medi-ai-input').value)"
                    style="width:36px;height:36px;border-radius:10px;border:none;background:#2563eb;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:background 0.15s;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                        <line x1="22" y1="2" x2="11" y2="13"/>
                        <polygon points="22 2 15 22 11 13 2 9 22 2"/>
                    </svg>
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(wrapper);

    // Sync select dropdown with current language
    const langSelect = document.getElementById("medi-ai-lang-select");
    if (langSelect) langSelect.value = mediAiLang;

    renderQuickActions();
    updateMediAiUIStrings();
}

function updateMediAiUIStrings() {
    const titleEl = document.getElementById("medi-ai-header-title");
    const subEl = document.getElementById("medi-ai-header-subtitle");
    const inputEl = document.getElementById("medi-ai-input");
    const typingLabel = document.getElementById("medi-ai-typing-label");

    if (titleEl) titleEl.textContent = getMediText("title");
    if (subEl) subEl.textContent = getMediText("subtitle");
    if (inputEl) inputEl.setAttribute("placeholder", getMediText("placeholder"));
    if (typingLabel) typingLabel.textContent = getMediText("typing");
    renderQuickActions();
}

function renderQuickActions() {
    const container = document.getElementById("medi-ai-quick-scroll");
    if (!container) return;
    const actions = (MEDI_AI_LOCALES[mediAiLang] || MEDI_AI_LOCALES["uz"]).quick_actions || [];
    container.innerHTML = actions.map(act => `
        <button class="medi-chip" onclick="handleQuickChipClick('${act.replace(/'/g, "\\'")}')">${act}</button>
    `).join("");
}

function handleQuickChipClick(chipText) {
    const cleanText = chipText.replace(/^[^\w\s\u0400-\u04FF]+/, "").trim();
    sendMediAiMessage(cleanText);
}

// ─── Open / Close / Toggle ───────────────────────────────────────────────────
function toggleMediAi() {
    mediAiOpen ? closeMediAi() : openMediAi();
}

function openMediAi() {
    const panel = document.getElementById("medi-ai-panel");
    if (!panel) return;
    panel.style.display = "block";
    panel.classList.remove("closing");
    mediAiOpen = true;

    // Focus input
    setTimeout(() => {
        const inp = document.getElementById("medi-ai-input");
        if (inp) inp.focus();
    }, 150);

    // If chat empty, load saved or show welcome
    const chatArea = document.getElementById("medi-ai-chat-area");
    if (chatArea && chatArea.children.length === 0) {
        if (mediAiHistory.length > 0) {
            renderStoredHistory();
        } else {
            appendMediAiMessage("ai", getMediText("welcome"));
        }
    }
    scrollMediAiToBottom();
}

function closeMediAi() {
    const panel = document.getElementById("medi-ai-panel");
    if (!panel) return;
    panel.classList.add("closing");
    setTimeout(() => {
        panel.style.display = "none";
        panel.classList.remove("closing");
    }, 200);
    mediAiOpen = false;
    stopSpeakingAIResponse();
}

function setMediAiLang(lang) {
    mediAiLang = lang;
    localStorage.setItem("poliklinika_lang", lang);
    const sel = document.getElementById("medi-ai-lang-select");
    if (sel) sel.value = lang;
    updateMediAiUIStrings();

    // Sync header dropdown if available
    const headerLang = document.getElementById("currentLangLabel");
    if (headerLang) {
        headerLang.textContent = lang === "uz" ? "🇺🇿 O'zbekcha" : lang === "ru" ? "🇷🇺 Русский" : "🇬🇧 English";
    }
}

// ─── Message Flow ─────────────────────────────────────────────────────────────
async function sendMediAiMessage(text) {
    if (!text || !text.trim()) return;
    const input = document.getElementById("medi-ai-input");
    if (input) input.value = "";

    const userMsg = text.trim();
    lastUserMessage = userMsg;

    // Render User Bubble
    appendMediAiMessage("user", userMsg);
    mediAiHistory.push({ role: "user", content: userMsg });
    saveMediAiHistoryToStorage();

    showMediAiTyping();

    // Call API with automatic retry capability
    try {
        const data = await callMediAiAPIWithRetry(userMsg, 0);
        handleMediAiResponse(data);
    } catch (err) {
        hideMediAiTyping();
        appendMediAiError(getMediText("error_msg"));
        console.error("[MEDI AI] Request failed:", err);
    }
}

async function callMediAiAPIWithRetry(message, retryCount = 0) {
    try {
        const response = await fetch("/api/ai/medi-chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                message: message,
                history: mediAiHistory.slice(-10),
                lang: mediAiLang
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        return await response.json();
    } catch (err) {
        if (retryCount < 1) {
            // One automatic retry
            await new Promise(r => setTimeout(r, 1200));
            return await callMediAiAPIWithRetry(message, retryCount + 1);
        }
        throw err;
    }
}

function handleMediAiResponse(data) {
    hideMediAiTyping();
    const reply = data.reply || "";

    const metadata = {
        suggested_doctor: data.suggested_doctor || null,
        is_emergency: data.is_emergency || false
    };

    appendMediAiMessage("ai", reply, metadata);
    mediAiHistory.push({ role: "assistant", content: reply });
    saveMediAiHistoryToStorage();

    if (data.is_emergency || data.action === "call_103") {
        showEmergencyBanner(getMediText("emergency_msg"));
    }
}

// Render Stored History
function renderStoredHistory() {
    const chatArea = document.getElementById("medi-ai-chat-area");
    if (!chatArea) return;
    chatArea.innerHTML = "";
    mediAiHistory.forEach(item => {
        appendMediAiMessage(item.role === "assistant" ? "ai" : "user", item.content, {});
    });
}

// ─── Rendering Chat Bubbles ──────────────────────────────────────────────────
function appendMediAiMessage(role, text, metadata = {}) {
    const chatArea = document.getElementById("medi-ai-chat-area");
    if (!chatArea) return;

    const isUser = role === "user";
    const bubbleWrapper = document.createElement("div");
    bubbleWrapper.style.cssText = `display:flex;flex-direction:column;align-items:${isUser ? 'flex-end' : 'flex-start'};`;

    const bubbleId = `medi-bubble-${Date.now()}-${Math.floor(Math.random()*1000)}`;

    let html = "";
    if (!isUser) {
        html += `
            <div style="display:flex;align-items:center;gap:5px;margin-bottom:3px;">
                <span style="font-size:11px;font-weight:700;color:#64748b;">MEDI AI</span>
                <span style="font-size:10px;color:#94a3b8;">${new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>
            </div>
        `;
    }

    const bubbleStyle = isUser
        ? "background:linear-gradient(135deg,#2563eb,#0d9488);color:#fff;border-radius:16px 16px 4px 16px;box-shadow:0 2px 8px rgba(37,99,235,0.25);"
        : `background:#ffffff;color:#1e293b;border-radius:16px 16px 16px 4px;border:1px solid ${metadata.is_emergency ? '#ef4444' : '#e2e8f0'};box-shadow:0 2px 6px rgba(0,0,0,0.05);`;

    const formattedText = escapeHtml(text).replace(/\n/g, "<br>");

    html += `
        <div id="${bubbleId}" style="${bubbleStyle}padding:10px 14px;max-width:88%;font-size:13px;line-height:1.5;word-break:break-word;">
            ${formattedText}
            ${!isUser ? `<div style="font-size:10px;color:#94a3b8;margin-top:5px;border-top:1px dashed #e2e8f0;padding-top:4px;">${getMediText("disclaimer")}</div>` : ''}
        </div>
    `;

    // Doctor recommendation card
    if (!isUser && metadata.suggested_doctor) {
        const doc = metadata.suggested_doctor;
        html += `
            <div style="margin-top:6px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;padding:8px 12px;max-width:88%;">
                <div style="font-weight:700;font-size:12px;color:#1e3a8a;">${doc.doctor_name || doc.specialization}</div>
                <div style="font-size:11px;color:#3b82f6;">${doc.specialization} • ${doc.room}-XONA</div>
                <button onclick="bookWithSuggestedDoctor(${doc.doctor_id || 'null'}, '${doc.dept_code || ''}')"
                        style="margin-top:6px;background:#2563eb;color:#fff;border:none;border-radius:8px;padding:4px 10px;font-size:11px;font-weight:700;cursor:pointer;">
                    ${getMediText("book_btn")} ➔
                </button>
            </div>
        `;
    }

    // AI message action bar: Copy, Speak, Regenerate
    if (!isUser) {
        html += `
            <div style="display:flex;align-items:center;gap:4px;margin-top:4px;">
                <button class="medi-action-btn" onclick="copyBubbleText('${bubbleId}', this)">
                    📋 <span>${getMediText("copy_btn")}</span>
                </button>
                <button class="medi-action-btn" onclick="toggleSpeakMessage('${bubbleId}', this)">
                    🔊 <span>${getMediText("speak_btn")}</span>
                </button>
                <button class="medi-action-btn" onclick="regenerateLastUserMessage()">
                    🔁 <span>${getMediText("regen_btn")}</span>
                </button>
            </div>
        `;
    }

    bubbleWrapper.innerHTML = html;
    chatArea.appendChild(bubbleWrapper);
    scrollMediAiToBottom();
}

function appendMediAiError(errMsg) {
    const chatArea = document.getElementById("medi-ai-chat-area");
    if (!chatArea) return;

    const div = document.createElement("div");
    div.style.cssText = "display:flex;flex-direction:column;align-items:flex-start;";
    div.innerHTML = `
        <div style="background:#fef2f2;border:1px solid #fecaca;color:#991b1b;border-radius:14px;padding:8px 12px;font-size:12px;">
            ⚠️ ${errMsg}
            <button onclick="retryLastUserMessage()" style="margin-left:8px;background:#dc2626;color:#fff;border:none;border-radius:6px;padding:2px 8px;font-size:10.5px;font-weight:700;cursor:pointer;">
                ${getMediText("retry_btn")}
            </button>
        </div>
    `;
    chatArea.appendChild(div);
    scrollMediAiToBottom();
}

// ─── Actions & Helpers ────────────────────────────────────────────────────────
function copyBubbleText(bubbleId, btn) {
    const el = document.getElementById(bubbleId);
    if (!el) return;
    const text = el.innerText.replace(getMediText("disclaimer"), "").trim();
    navigator.clipboard.writeText(text).then(() => {
        const span = btn.querySelector("span");
        if (span) span.textContent = getMediText("copied");
        setTimeout(() => {
            if (span) span.textContent = getMediText("copy_btn");
        }, 1500);
    });
}

function toggleSpeakMessage(bubbleId, btn) {
    if ('speechSynthesis' in window && window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
        btn.querySelector("span").textContent = getMediText("speak_btn");
        return;
    }

    const el = document.getElementById(bubbleId);
    if (!el) return;
    const text = el.innerText.replace(getMediText("disclaimer"), "").trim();

    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.95;

        // Choose voice matching mediAiLang
        if (typeof getBestVoiceForLang === 'function') {
            const v = getBestVoiceForLang(mediAiLang);
            if (v) utterance.voice = v;
        }

        const span = btn.querySelector("span");
        utterance.onstart = () => { if (span) span.textContent = getMediText("stop_btn"); };
        utterance.onend = () => { if (span) span.textContent = getMediText("speak_btn"); };
        utterance.onerror = () => { if (span) span.textContent = getMediText("speak_btn"); };

        window.speechSynthesis.speak(utterance);
    }
}

function stopSpeakingAIResponse() {
    if ('speechSynthesis' in window && window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
    }
}

function regenerateLastUserMessage() {
    if (!lastUserMessage) return;
    sendMediAiMessage(lastUserMessage);
}

function retryLastUserMessage() {
    if (!lastUserMessage) return;
    sendMediAiMessage(lastUserMessage);
}

function startNewMediAiChat() {
    mediAiHistory = [];
    saveMediAiHistoryToStorage();
    const chatArea = document.getElementById("medi-ai-chat-area");
    if (chatArea) chatArea.innerHTML = "";
    appendMediAiMessage("ai", getMediText("welcome"));
}

function clearMediAiChat() {
    if (confirm("MEDI AI suhbat tarixini tozalashni tasdiqlaysizmi?")) {
        startNewMediAiChat();
    }
}

function bookWithSuggestedDoctor(doctorId, deptCode) {
    closeMediAi();
    if (typeof showSection === "function") {
        showSection("patient");
    }
    if (doctorId && typeof selectDoctor === "function") {
        setTimeout(() => selectDoctor(doctorId), 300);
    }
}

function showMediAiTyping() {
    const t = document.getElementById("medi-ai-typing");
    if (t) t.style.display = "block";
    scrollMediAiToBottom();
}

function hideMediAiTyping() {
    const t = document.getElementById("medi-ai-typing");
    if (t) t.style.display = "none";
}

function showEmergencyBanner(text) {
    const banner = document.getElementById("medi-ai-emergency-banner");
    const label = document.getElementById("medi-ai-emergency-text");
    if (banner && label) {
        label.textContent = text;
        banner.style.display = "flex";
    }
}

function hideEmergencyBanner() {
    const banner = document.getElementById("medi-ai-emergency-banner");
    if (banner) banner.style.display = "none";
}

function scrollMediAiToBottom() {
    const chatArea = document.getElementById("medi-ai-chat-area");
    if (chatArea) {
        setTimeout(() => { chatArea.scrollTop = chatArea.scrollHeight; }, 60);
    }
}

function escapeHtml(str) {
    if (!str) return "";
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

// ─── Voice Input (Web Speech Recognition) ─────────────────────────────────────
function startMediAiVoice() {
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) {
        alert("Brauzeringiz ovozli qidiruvni qo'llab-quvvatlamaydi (Google Chrome yoki Edge tavsiya etiladi).");
        return;
    }

    const rec = new SpeechRec();
    rec.continuous = false;
    rec.interimResults = false;
    rec.lang = mediAiLang === "ru" ? "ru-RU" : mediAiLang === "en" ? "en-US" : "uz-UZ";

    const micBtn = document.getElementById("medi-ai-mic-btn");
    const input = document.getElementById("medi-ai-input");

    rec.onstart = () => {
        mediAiListening = true;
        if (micBtn) {
            micBtn.style.background = "#fee2e2";
            micBtn.style.borderColor = "#ef4444";
        }
        if (input) input.setAttribute("placeholder", getMediText("listening"));
    };

    rec.onresult = (evt) => {
        const transcript = evt.results[0][0].transcript;
        if (transcript && transcript.trim()) {
            sendMediAiMessage(transcript);
        }
    };

    rec.onerror = () => {
        mediAiListening = false;
        if (micBtn) {
            micBtn.style.background = "#f8fafc";
            micBtn.style.borderColor = "#e2e8f0";
        }
        if (input) input.setAttribute("placeholder", getMediText("placeholder"));
    };

    rec.onend = () => {
        mediAiListening = false;
        if (micBtn) {
            micBtn.style.background = "#f8fafc";
            micBtn.style.borderColor = "#e2e8f0";
        }
        if (input) input.setAttribute("placeholder", getMediText("placeholder"));
    };

    rec.start();
}

// ─── Initialization ───────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
    loadMediAiHistoryFromStorage();
    injectMediAiHTML();
});
