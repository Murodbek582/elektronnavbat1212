from datetime import date, datetime, timedelta
from backend.database import get_db, fetch_one, execute
from backend.auth import hash_password

def seed_extra_modules(cursor):
    # Get department IDs
    dept_rows = cursor.execute("SELECT code, id FROM departments").fetchall()
    dept_id_map = {row[0]: row[1] for row in dept_rows}

    # 7. Clinic Services (11 Core Polyclinic Services)
    services_data = [
        ("TR", "Umumiy tibbiy konsultatsiya", "Общая медицинская консультация", "General Medical Consultation",
         "Shifokor-terapevt ko'rigi, dastlabki tashxis va davolash rejasini tuzish", 45000, 20),
        ("TR", "Laboratoriya xizmatlari", "Лабораторные услуги", "Laboratory Diagnostic Services",
         "Keng qamrovli laboratoriya tahlillari va tezkor natijalar", 60000, 15),
        ("TR", "Umumiy qon tahlili (KLA)", "Общий анализ крови (ОАК)", "Complete Blood Count (CBC)",
         "Gemoglobin, leykotsitlar va eritrotsitlar miqdorini aniq o'lchash", 35000, 15),
        ("KD", "Elektrokardiogramma (EKG)", "Электрокардиография (ЭКГ)", "Electrocardiogram (ECG)",
         "Yurak ritmi va o'tkazuvchanligini 12 ta kanalli tekshiruvi", 50000, 15),
        ("KD", "Kardiolog ko'rigi va EKG tahlili", "Прием кардиолога с анализом ЭКГ", "Cardiologist Consultation & ECG",
         "Yurak-qon tomir tizimi kengaytirilgan konsultatsiyasi", 75000, 25),
        ("JR", "Ultratovush tekshiruvi (UZI)", "Ультразвуковое исследование (УЗИ)", "Ultrasound Diagnostics (USG)",
         "Qorin bo'shlig'i a'zolari va buyraklar ultratovush diagnostikasi", 80000, 20),
        ("ST", "Stomatologik ko'rik va davolash", "Стоматологический осмотр и лечение", "Dental Examination & Treatment",
         "Tish kariyesini plombalash, gigiyenik tozalash va milk davolash", 90000, 30),
        ("PD", "Pediatr ko'rigi va emlash maslahati", "Прием педиатра и консультация по вакцинации", "Pediatrician Consultation & Vaccination",
         "Bolalar salomatligi, rivojlanish nazorati va profilaktik emlash", 40000, 20),
        ("NV", "Nevrolog ko'rigi va bosh miya diagnostikasi", "Осмотр невролога и диагностика", "Neurologist Consultation",
         "Surunkali bosh og'riqlari, nevropatiyalar va umurtqa pog'onasi ko'rigi", 60000, 20),
        ("OF", "Ko'z tubi tekshiruvi va ko'rish o'tkirligi", "Проверка зрения и глазного дна", "Ophthalmology Eye Examination",
         "Avtorefraktometriya, ko'z bosimini o'lchash va ko'zoynak tanlash", 50000, 20),
        ("TR", "Profilaktik tibbiy dispanserizatsiya", "Профилактическая диспансеризация", "Preventive Medical Check-up",
         "To'liq kompleks skrining ko'rigi (terapevt, laboratoriya, EKG)", 120000, 45)
    ]

    for s in services_data:
        dept_code, n_uz, n_ru, n_en, desc_uz, price, dur = s
        dept_id = dept_id_map.get(dept_code, 1)
        cursor.execute("""
            INSERT INTO services (department_id, name_uz, name_ru, name_en, description_uz, price, duration_minutes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (dept_id, n_uz, n_ru, n_en, desc_uz, price, dur))

    # 8. AI Knowledge Base Entries
    kb_entries = [
        ("clinic", "Poliklinika qayerda joylashgan va telefon raqami qanday?",
         "Poliklinika manzili: Toshkent shahri, Chilonzor tumani, Bunyodkor ko'chasi 42-uy. Yagona call-markaz telefoni: +998 71 200-00-11.",
         "manzil, telefon, lokatsiya, qayerda, kontakt, raqam"),
        ("clinic", "Poliklinikaning ish vaqti qachon?",
         "Poliklinika dushanbadan jumagacha soat 08:00 dan 18:00 gacha ishlaydi. Shanba kuni soat 09:00 dan 15:00 gacha navbatchi shifokorlar qabul o'tkazadi. Yakshanba — dam olish kuni.",
         "ish vaqti, soat, qachon, grafik, shanba, yakshanba"),
        ("rules", "Elektron navbat qanday olinadi?",
         "Elektron navbat olish uchun saytdagi 'Bemor portali' bo'limiga o'ting, 14 xonali JShShIR raqamingizni kiriting, kerakli bo'lim va shifokorni tanlang, so'ng qulay kun va soatni tanlab 'Navbat talonini olish' tugmasini bosing.",
         "navbat olish, qanday navbat, talon, qabulga yozilish, bron"),
        ("rules", "Navbatni bekor qilish qoidasi qanday?",
         "Navbatni qabul belgilangan vaqtdan kamida 1 soat oldin 'Mening navbatlarim' bo'limida 'Bekor qilish' tugmasini bosib bekor qilishingiz mumkin. O'tib ketgan vaqtdagi qabulni bekor qilib bo'lmaydi.",
         "bekor qilish, qaytarish, kechikish, rad etish"),
        ("preparation", "Qon tahliliga qanday tayyorgarlik ko'rish kerak?",
         "Qon tahlillari (umumiy va biokimyoviy) qat'iy och qoringa (kamida 8-10 soat ovqatlanmasdan) ertalab soat 08:00 dan 10:30 gacha topshiriladi. Tahlildan oldin faqat gazsiz toza suv ichish mumkin.",
         "qon tahlili, och qoringa, laboratoriya, tayyorgarlik, tahlil"),
        ("preparation", "UZI tekshiruviga qanday tayyorlaniladi?",
         "Qorin bo'shlig'i UZI tekshiruvi och qoringa o'tkaziladi. Kichik tos a'zolari va qovuq UZI tekshiruvidan 1 soat oldin 1 litr toza gazsiz suv ichib, siydik pufagini to'ldirish talab etiladi.",
         "uzi, ultratovush, tayyorgarlik, qorin bo'shlig'i"),
        ("preparation", "EKG tekshiruviga tayyorgarlik bormi?",
         "EKG tekshiruvidan 30 daqiqa oldin jismoniy zo'riqish, chekish va kofe ichish tavsiya etilmaydi. Tekshiruv oldidan 5-10 daqiqa tinch o'tirish zarur.",
         "ekg, kardiogramma, yurak, tayyorgarlik"),
        ("faq", "Shifokor qabuliga qancha vaqt oldin kelish kerak?",
         "Talon bo'yicha belgilangan vaqtdan kamida 10 daqiqa oldin tegishli xona oldida hozir bo'lishingiz va ekrandagi chaqiruvni kuzatishingiz tavsiya etiladi.",
         "vaqt, necha daqiqa, qachon kelish, kechikish"),
        ("faq", "Talonni chop etish shartmi?",
         "Yo'q, talonni qog'ozda chop etish majburiy emas. Talondagi raqam (masalan TR-001) va xona raqamini telefoningizda saqlab qolsangiz yoki skrinshot qilsangiz kifoya.",
         "chop etish, qog'oz, talon, majburiymi")
    ]

    for kb in kb_entries:
        cursor.execute("""
            INSERT INTO ai_knowledge_base (category, question, answer, keywords)
            VALUES (?, ?, ?, ?)
        """, kb)

    # 9. Medical Documents
    p1 = cursor.execute("SELECT id FROM patients LIMIT 1").fetchone()
    d1 = cursor.execute("SELECT id FROM doctors LIMIT 1").fetchone()
    if p1 and d1:
        cursor.execute("""
            INSERT INTO medical_documents (patient_id, doctor_id, doc_type, title, content_json, notes)
            VALUES (?, ?, 'visit_summary', 'Terapevt ko''rigi xulosasi', ?, 'Profilaktik tekshiruv tavsiyalari berildi')
        """, (p1[0], d1[0], '{"anamnesis": "Bemor umumiy holsizlik va engil charchoqdan shikoyat qildi.", "diagnosis": "Astenik sindrom, surunkali charchoq", "recommendations": "1. Kun tartibiga rioya qilish. 2. Vitamin D3 2000 ME kuniga 1 mahal. 3. 2 haftadan so''ng qayta ko''rik."}'))

        cursor.execute("""
            INSERT INTO medical_documents (patient_id, doctor_id, doc_type, title, content_json, notes)
            VALUES (?, ?, 'lab_result', 'Umumiy qon tahlili natijasi (KLA)', ?, 'Tahlil natijalari me''yor darajasida')
        """, (p1[0], d1[0], '{"indicators": {"Gemoglobin": "142 g/l (Norma: 130-160)", "Eritrotsitlar": "4.5 x 10^12/l", "Leykotsitlar": "6.8 x 10^9/l", "EOCh (SOE)": "7 mm/soat"}, "conclusion": "Patologik o''zgarishlar aniqlanmadi."}'))

        # Reviews
        cursor.execute("""
            INSERT INTO doctor_reviews (doctor_id, patient_id, rating, comment)
            VALUES (?, ?, 5, 'Dr. Rustamov juda tajribali va e''tiborli shifokor. Katta rahmat!')
        """, (d1[0], p1[0]))

        # Favorites
        cursor.execute("""
            INSERT OR IGNORE INTO favorite_doctors (patient_id, doctor_id)
            VALUES (?, ?)
        """, (p1[0], d1[0]))

    # Announcements
    cursor.execute("""
        INSERT INTO clinic_announcements (title, content, priority)
        VALUES ('Profilaktik dispanserizatsiya haftaligi', 'Hurmatli fuqarolar! Poliklinikamizda bepul umumiy qon tahlili va EKG skriningi o''tkazilmoqda.', 'high')
    """)
    cursor.execute("""
        INSERT INTO clinic_announcements (title, content, priority)
        VALUES ('MEDI AI aqlli tibbiy yordamchi ishga tushirildi', 'Endi har bir bemor saytdagi MEDI AI yordamchisiga o''z shikoyatlarini yozib, kerakli mutaxassisni tezda aniqlashi mumkin.', 'normal')
    """)

    print("Extra AI & service modules seeded successfully!")

def seed_database():
    with get_db() as conn:
        cursor = conn.cursor()

        # Check if already seeded
        existing_admin = cursor.execute("SELECT id FROM users WHERE email = 'admin@poliklinika.uz'").fetchone()
        if existing_admin:
            # Check if new AI modules need seeding
            srv_count = cursor.execute("SELECT COUNT(id) FROM services").fetchone()[0]
            if srv_count > 0:
                print("Database already seeded with all modules.")
                return
            else:
                print("Base database exists. Seeding new AI and clinic service modules...")
                seed_extra_modules(cursor)
                return

        print("Seeding database with professional polyclinic data...")

        # 1. System Settings
        cursor.execute("INSERT OR REPLACE INTO system_settings (key, value, description) VALUES (?, ?, ?)",
                       ("sms_gateway_provider", "demo", "SMS gateway mode: demo, eskiz, or playmobile"))
        cursor.execute("INSERT OR REPLACE INTO system_settings (key, value, description) VALUES (?, ?, ?)",
                       ("pinfl_api_mode", "demo", "Uzbekistan PINFL verification mode: demo or live"))
        cursor.execute("INSERT OR REPLACE INTO system_settings (key, value, description) VALUES (?, ?, ?)",
                       ("daily_queue_counter_date", str(date.today()), "Date of current queue counter"))

        # 2. Departments
        departments = [
            ("Terapiya va umumiy amaliyot", "Терапия и общая практика", "Therapy & General Practice", "TR",
             "Kattalar uchun umumiy tibbiy ko'rik, tashxis va davolash xizmatlari", "stethoscope"),
            ("Kardiologiya", "Кардиология", "Cardiology", "KD",
             "Yurak-qon tomir tizimi kasalliklarini profilaktikasi va davolash", "heart-pulse"),
            ("Nevrologiya", "Неврология", "Neurology", "NV",
             "Asab tizimi, miya qon aylanishi va umurtqa pog'onasi muammolari", "brain"),
            ("Pediatriya", "Педиатрия", "Pediatrics", "PD",
             "Chaqaloqlar va bolalar salomatligi, emlash va rivojlanish nazorati", "baby"),
            ("Umumiy jarrohlik", "Общая хирургия", "General Surgery", "JR",
             "Kichik ambulator jarrohlik amaliyotlari va jarohatlar ko'rigi", "scalpel"),
            ("Oftalmologiya", "Офтальмология", "Ophthalmology", "OF",
             "Ko'rish qobiliyatini tekshirish, ko'z bosimi va kasalliklarini davolash", "eye"),
            ("Stomatologiya", "Стоматология", "Dentistry", "ST",
             "Tish kasalliklari profilaktikasi, plombalash va milk davolash", "smile"),
            ("Ginekologiya", "Гинекология", "Gynecology", "GN",
             "Ayollar salomatligi, rejalashtirish va akusherlik maslahatlari", "shield-check"),
            ("Endokrinologiya", "Эндокринология", "Endocrinology", "EN",
             "Qandli diabet, qalqonsimon bez va gormonal buzilishlar", "activity"),
            ("Dermatologiya", "Дерматология", "Dermatology", "DR",
             "Teri, soch va tirnoq kasalliklarini zamonaviy tashxislash", "sparkles")
        ]

        dept_id_map = {}
        for d in departments:
            cursor.execute("""
                INSERT INTO departments (name_uz, name_ru, name_en, code, description_uz, icon)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (d[0], d[1], d[2], d[3], d[4], d[5]))
            dept_id_map[d[3]] = cursor.lastrowid

        # 3. Super Admin User
        admin_pass = hash_password("Admin123!")
        cursor.execute("""
            INSERT INTO users (email, phone, password_hash, role, full_name)
            VALUES (?, ?, ?, ?, ?)
        """, ("admin@poliklinika.uz", "+998712000011", admin_pass, "admin", "Bosh Administrator"))
        admin_id = cursor.lastrowid

        # 4. Doctors (10 Required Medical Specialists)
        doctors_info = [
            ("dr.rustamov@poliklinika.uz", "+998901110101", "Dr. Rustamov Jamshid Olimovich", "TR",
             "Terapevt (Umumiy amaliyot shifokori)", "Терапевт (Врач общей практики)", "Therapist (General Practitioner)",
             "101", "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300", 20, "08:30", "17:30",
             "15 yillik tajribaga ega oliy toifali terapevt."),

            ("dr.umarova@poliklinika.uz", "+998901110102", "Dr. Umarova Nodira Botirovna", "KD",
             "Kardiolog", "Кардиолог", "Cardiologist",
             "102", "https://images.unsplash.com/photo-1594824813576-96b61329cfae?w=300", 20, "09:00", "17:00",
             "Yurak ritmi buzilishlari va gipertoniya bo'yicha mutaxassis."),

            ("dr.qosimov@poliklinika.uz", "+998901110103", "Dr. Qosimov Bobur Faxriddinovich", "NV",
             "Nevrolog", "Невролог", "Neurologist",
             "103", "https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=300", 20, "08:30", "16:30",
             "Bosh og'riqlari va asab tizimi funktsional buzilishlari mutaxassisi."),

            ("dr.ismoilova@poliklinika.uz", "+998901110104", "Dr. Ismoilova Feruza Mansurovna", "PD",
             "Pediatr", "Педиатр", "Pediatrician",
             "104", "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=300", 20, "09:00", "16:00",
             "Bolalar kasalliklari va profilaktik emlash bo'yicha maslahatchi."),

            ("dr.saidov@poliklinika.uz", "+998901110105", "Dr. Saidov Sardor Akramovich", "JR",
             "Jarroh", "Хирург", "Surgeon",
             "105", "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=300", 20, "08:30", "17:00",
             "Kichik ambulator operatsiyalar va travmatologik yordam ustasi."),

            ("dr.mahmudova@poliklinika.uz", "+998901110106", "Dr. Mahmudova Gulnora Anvarovna", "OF",
             "Okulist (Oftalmolog)", "Окулист (Офтальмолог)", "Ophthalmologist",
             "106", "https://images.unsplash.com/photo-1651008376811-b90baee60c1f?w=300", 20, "09:00", "16:30",
             "Ko'rish o'tkirligi va ko'z tubi tekshiruvi mutaxassisi."),

            ("dr.nazarov@poliklinika.uz", "+998901110107", "Dr. Nazarov Ulug'bek Komilovich", "ST",
             "Stomatolog", "Стоматолог", "Dentist",
             "107", "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=300", 30, "09:00", "18:00",
             "Tishlarni og'riqsiz davolash va estetik restavratsiya."),

            ("dr.alimova@poliklinika.uz", "+998901110108", "Dr. Alimova Malika Shavkatovna", "GN",
             "Ginekolog", "Гинеколог", "Gynecologist",
             "108", "https://images.unsplash.com/photo-1622902046580-2b47f47f5471?w=300", 20, "08:30", "16:00",
             "Reproduktiv salomatlik va homiladorlik nazorati bo'yicha oliy toifali shifokor."),

            ("dr.zokirov@poliklinika.uz", "+998901110109", "Dr. Zokirov Eldor Baxtiyorovich", "EN",
             "Endokrinolog", "Эндокринолог", "Endocrinologist",
             "109", "https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=300", 20, "09:00", "17:00",
             "Qalqonsimon bez va metabolik o'zgarishlar diagnostikasi."),

            ("dr.xolmatova@poliklinika.uz", "+998901110110", "Dr. Xolmatova Nilufar Erkinovna", "DR",
             "Dermatolog", "Дерматолог", "Dermatologist",
             "110", "https://images.unsplash.com/photo-1594824813680-e889d1c16f2f?w=300", 20, "08:30", "16:30",
             "Teri va allergik kasalliklar diagnostikasi.")
        ]

        doc_pass = hash_password("Doctor123!")
        doctor_records = []

        for item in doctors_info:
            email, phone, name, dept_code, spec_uz, spec_ru, spec_en, room, photo, duration, st, et, bio = item
            cursor.execute("""
                INSERT INTO users (email, phone, password_hash, role, full_name)
                VALUES (?, ?, ?, 'doctor', ?)
            """, (email, phone, doc_pass, name))
            u_id = cursor.lastrowid

            dept_id = dept_id_map[dept_code]
            cursor.execute("""
                INSERT INTO doctors (
                    user_id, department_id, full_name, specialization_uz, specialization_ru, specialization_en,
                    room_number, photo_url, phone, appointment_duration, working_days, start_time, end_time, bio_uz
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '1,2,3,4,5', ?, ?, ?)
            """, (u_id, dept_id, name, spec_uz, spec_ru, spec_en, room, photo, phone, duration, st, et, bio))
            doc_id = cursor.lastrowid
            doctor_records.append((doc_id, u_id, dept_id, name, room, dept_code))

            # Add default schedule (Mon-Fri)
            for day in range(5):
                cursor.execute("""
                    INSERT INTO doctor_schedules (doctor_id, day_of_week, start_time, end_time, slot_duration)
                    VALUES (?, ?, ?, ?, ?)
                """, (doc_id, day, st, et, duration))

        # 5. Patients (Preserving exact demo data from original prototype + extra test patients)
        patient_pass = hash_password("Patient123!")
        patients_info = [
            ("12345678901234", "Aliyev Anvar Anvarovich", "1985-04-12", "male", "+998901234567",
             "patient1@poliklinika.uz", "Toshkent sh., Yunusobod 4-mavze 12-uy"),
            ("11112222333344", "Karimova Dilnoza Baxtiyorovna", "1992-08-23", "female", "+998912345678",
             "patient2@poliklinika.uz", "Toshkent sh., Chilonzor 9-mavze 5-uy"),
            ("33334444555566", "Sobirov Jasur Otabekovich", "1998-11-05", "male", "+998935556677",
             "patient3@poliklinika.uz", "Toshkent sh., Shayxontohur tumani, Navoiy ko'chasi 18-uy"),
            ("55556666777788", "Toirova Shahnoza Rustamovna", "1990-02-17", "female", "+998971112233",
             "patient4@poliklinika.uz", "Toshkent sh., Mirzo Ulug'bek tumani, Mustaqillik shoh ko'chasi 4-uy")
        ]

        patient_records = []
        for p in patients_info:
            pinfl, name, birth, gender, phone, email, addr = p
            cursor.execute("""
                INSERT INTO users (email, phone, password_hash, role, full_name)
                VALUES (?, ?, ?, 'patient', ?)
            """, (email, phone, patient_pass, name))
            p_uid = cursor.lastrowid

            cursor.execute("""
                INSERT INTO patients (user_id, pinfl, full_name, birth_date, gender, phone, address, is_verified)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)
            """, (p_uid, pinfl, name, birth, gender, phone, addr))
            pat_id = cursor.lastrowid
            patient_records.append((pat_id, p_uid, name, pinfl))

        # 6. Sample Live Queue and Appointments for Today
        today_str = str(date.today())
        
        # Patient 1 with Doctor 1 (Terapevt) -> In-Consultation / Calling
        doc1_id, _, doc1_dept_id, doc1_name, doc1_room, _ = doctor_records[0]
        cursor.execute("""
            INSERT INTO appointments (appointment_number, patient_id, doctor_id, department_id, appointment_date, start_time, end_time, status, reason)
            VALUES (?, ?, ?, ?, ?, '09:00', '09:20', 'in_consultation', 'Umumiy holsizlik va ko''rik')
        """, (f"APT-{today_str}-001", patient_records[0][0], doc1_id, doc1_dept_id, today_str))
        appt1_id = cursor.lastrowid
        cursor.execute("""
            INSERT INTO queue_tickets (appointment_id, ticket_number, queue_date, priority_number, status, called_at, room_number)
            VALUES (?, 'TR-001', ?, 1, 'calling', ?, ?)
        """, (appt1_id, today_str, datetime.now().isoformat(), doc1_room))

        # Patient 2 with Doctor 1 (Terapevt) -> Waiting
        cursor.execute("""
            INSERT INTO appointments (appointment_number, patient_id, doctor_id, department_id, appointment_date, start_time, end_time, status, reason)
            VALUES (?, ?, ?, ?, ?, '09:20', '09:40', 'waiting', 'Profilaktik tibbiy ko''rik')
        """, (f"APT-{today_str}-002", patient_records[1][0], doc1_id, doc1_dept_id, today_str))
        appt2_id = cursor.lastrowid
        cursor.execute("""
            INSERT INTO queue_tickets (appointment_id, ticket_number, queue_date, priority_number, status, room_number)
            VALUES (?, 'TR-002', ?, 2, 'waiting', ?)
        """, (appt2_id, today_str, doc1_room))

        # Patient 3 with Doctor 2 (Kardiolog) -> Calling
        doc2_id, _, doc2_dept_id, doc2_name, doc2_room, _ = doctor_records[1]
        cursor.execute("""
            INSERT INTO appointments (appointment_number, patient_id, doctor_id, department_id, appointment_date, start_time, end_time, status, reason)
            VALUES (?, ?, ?, ?, ?, '09:30', '09:50', 'in_consultation', 'Yurak sohasida noxushlik')
        """, (f"APT-{today_str}-003", patient_records[2][0], doc2_id, doc2_dept_id, today_str))
        appt3_id = cursor.lastrowid
        cursor.execute("""
            INSERT INTO queue_tickets (appointment_id, ticket_number, queue_date, priority_number, status, called_at, room_number)
            VALUES (?, 'KD-001', ?, 1, 'calling', ?, ?)
        """, (appt3_id, today_str, datetime.now().isoformat(), doc2_room))

        # Patient 4 with Doctor 3 (Nevrolog) -> Waiting
        doc3_id, _, doc3_dept_id, doc3_name, doc3_room, _ = doctor_records[2]
        cursor.execute("""
            INSERT INTO appointments (appointment_number, patient_id, doctor_id, department_id, appointment_date, start_time, end_time, status, reason)
            VALUES (?, ?, ?, ?, ?, '10:00', '10:20', 'waiting', 'Bosh og''rig''i bo''yicha konsultatsiya')
        """, (f"APT-{today_str}-004", patient_records[3][0], doc3_id, doc3_dept_id, today_str))
        appt4_id = cursor.lastrowid
        cursor.execute("""
            INSERT INTO queue_tickets (appointment_id, ticket_number, queue_date, priority_number, status, room_number)
            VALUES (?, 'NV-001', ?, 1, 'waiting', ?)
        """, (appt4_id, today_str, doc3_room))

        # Sample Completed historical appointments for analytics (yesterday & last week)
        yesterday_str = str(date.today() - timedelta(days=1))
        cursor.execute("""
            INSERT INTO appointments (appointment_number, patient_id, doctor_id, department_id, appointment_date, start_time, end_time, status, reason, notes)
            VALUES (?, ?, ?, ?, ?, '11:00', '11:20', 'completed', 'Ko''z bosimi tekshiruvi', 'Ko''z bosimi me''yorda. Ko''z tomchilari tayinlandi.')
        """, (f"APT-{yesterday_str}-001", patient_records[0][0], doctor_records[5][0], doctor_records[5][2], yesterday_str))
        appt_hist_id = cursor.lastrowid
        cursor.execute("""
            INSERT INTO queue_tickets (appointment_id, ticket_number, queue_date, priority_number, status, served_at, room_number)
            VALUES (?, 'OF-001', ?, 1, 'completed', ?, '106')
        """, (appt_hist_id, yesterday_str, datetime.now().isoformat()))

        # Sample Notifications
        cursor.execute("""
            INSERT INTO notifications (user_id, title, message, type, channel, delivery_status)
            VALUES (?, 'Qabul muvaffaqiyatli band qilindi', 'Siz 101-xona shifokori Dr. Rustamov qabuliga yozildingiz. Talon raqamingiz: TR-001', 'booking', 'in_app', 'delivered')
        """, (patient_records[0][1],))
        cursor.execute("""
            INSERT INTO notifications (user_id, title, message, type, channel, delivery_status)
            VALUES (?, 'SMS Xabarnoma (Simulyatsiya)', 'Poliklinika: Siz 09:00 da Terapevt qabuliga yozildingiz. Talon: TR-001. Tel: +998 71 200-00-11', 'booking', 'sms', 'simulated')
        """, (patient_records[0][1],))

        # 7. Clinic Services (11 Core Polyclinic Services)
        services_data = [
            ("TR", "Umumiy tibbiy konsultatsiya", "Общая медицинская консультация", "General Medical Consultation",
             "Shifokor-terapevt ko'rigi, dastlabki tashxis va davolash rejasini tuzish", 45000, 20),
            ("TR", "Laboratoriya xizmatlari", "Лабораторные услуги", "Laboratory Diagnostic Services",
             "Keng qamrovli laboratoriya tahlillari va tezkor natijalar", 60000, 15),
            ("TR", "Umumiy qon tahlili (KLA)", "Общий анализ крови (ОАК)", "Complete Blood Count (CBC)",
             "Gemoglobin, leykotsitlar va eritrotsitlar miqdorini aniq o'lchash", 35000, 15),
            ("KD", "Elektrokardiogramma (EKG)", "Электрокардиография (ЭКГ)", "Electrocardiogram (ECG)",
             "Yurak ritmi va o'tkazuvchanligini 12 ta kanalli tekshiruvi", 50000, 15),
            ("KD", "Kardiolog ko'rigi va EKG tahlili", "Прием кардиолога с анализом ЭКГ", "Cardiologist Consultation & ECG",
             "Yurak-qon tomir tizimi kengaytirilgan konsultatsiyasi", 75000, 25),
            ("JR", "Ultratovush tekshiruvi (UZI)", "Ультразвуковое исследование (УЗИ)", "Ultrasound Diagnostics (USG)",
             "Qorin bo'shlig'i a'zolari va buyraklar ultratovush diagnostikasi", 80000, 20),
            ("ST", "Stomatologik ko'rik va davolash", "Стоматологический осмотр и лечение", "Dental Examination & Treatment",
             "Tish kariyesini plombalash, gigiyenik tozalash va milk davolash", 90000, 30),
            ("PD", "Pediatr ko'rigi va emlash maslahati", "Прием педиатра и консультация по вакцинации", "Pediatrician Consultation & Vaccination",
             "Bolalar salomatligi, rivojlanish nazorati va profilaktik emlash", 40000, 20),
            ("NV", "Nevrolog ko'rigi va bosh miya diagnostikasi", "Осмотр невролога и диагностика", "Neurologist Consultation",
             "Surunkali bosh og'riqlari, nevropatiyalar va umurtqa pog'onasi ko'rigi", 60000, 20),
            ("OF", "Ko'z tubi tekshiruvi va ko'rish o'tkirligi", "Проверка зрения и глазного дна", "Ophthalmology Eye Examination",
             "Avtorefraktometriya, ko'z bosimini o'lchash va ko'zoynak tanlash", 50000, 20),
            ("TR", "Profilaktik tibbiy dispanserizatsiya", "Профилактическая диспансеризация", "Preventive Medical Check-up",
             "To'liq kompleks skrining ko'rigi (terapevt, laboratoriya, EKG)", 120000, 45)
        ]

        for s in services_data:
            dept_code, n_uz, n_ru, n_en, desc_uz, price, dur = s
            dept_id = dept_id_map.get(dept_code, 1)
            cursor.execute("""
                INSERT INTO services (department_id, name_uz, name_ru, name_en, description_uz, price, duration_minutes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (dept_id, n_uz, n_ru, n_en, desc_uz, price, dur))

        # 8. AI Knowledge Base Entries (Approved Clinical Information)
        kb_entries = [
            ("clinic", "Poliklinika qayerda joylashgan va telefon raqami qanday?",
             "Poliklinika manzili: Toshkent shahri, Chilonzor tumani, Bunyodkor ko'chasi 42-uy. Yagona call-markaz telefoni: +998 71 200-00-11.",
             "manzil, telefon, lokatsiya, qayerda, kontakt, raqam"),
            ("clinic", "Poliklinikaning ish vaqti qachon?",
             "Poliklinika dushanbadan jumagacha soat 08:00 dan 18:00 gacha ishlaydi. Shanba kuni soat 09:00 dan 15:00 gacha navbatchi shifokorlar qabul o'tkazadi. Yakshanba — dam olish kuni.",
             "ish vaqti, soat, qachon, grafik, shanba, yakshanba"),
            ("rules", "Elektron navbat qanday olinadi?",
             "Elektron navbat olish uchun saytdagi 'Bemor portali' bo'limiga o'ting, 14 xonali JShShIR raqamingizni kiriting, kerakli bo'lim va shifokorni tanlang, so'ng qulay kun va soatni tanlab 'Navbat talonini olish' tugmasini bosing.",
             "navbat olish, qanday navbat, talon, qabulga yozilish, bron"),
            ("rules", "Navbatni bekor qilish qoidasi qanday?",
             "Navbatni qabul belgilangan vaqtdan kamida 1 soat oldin 'Mening navbatlarim' bo'limida 'Bekor qilish' tugmasini bosib bekor qilishingiz mumkin. O'tib ketgan vaqtdagi qabulni bekor qilib bo'lmaydi.",
             "bekor qilish, qaytarish, kechikish, rad etish"),
            ("preparation", "Qon tahliliga qanday tayyorgarlik ko'rish kerak?",
             "Qon tahlillari (umumiy va biokimyoviy) qat'iy och qoringa (kamida 8-10 soat ovqatlanmasdan) ertalab soat 08:00 dan 10:30 gacha topshiriladi. Tahlildan oldin faqat gazsiz toza suv ichish mumkin.",
             "qon tahlili, och qoringa, laboratoriya, tayyorgarlik, tahlil"),
            ("preparation", "UZI tekshiruviga qanday tayyorlaniladi?",
             "Qorin bo'shlig'i UZI tekshiruvi och qoringa o'tkaziladi. Kichik tos a'zolari va qovuq UZI tekshiruvidan 1 soat oldin 1 litr toza gazsiz suv ichib, siydik pufagini to'ldirish talab etiladi.",
             "uzi, ultratovush, tayyorgarlik, qorin bo'shlig'i"),
            ("preparation", "EKG tekshiruviga tayyorgarlik bormi?",
             "EKG tekshiruvidan 30 daqiqa oldin jismoniy zo'riqish, chekish va kofe ichish tavsiya etilmaydi. Tekshiruv oldidan 5-10 daqiqa tinch o'tirish zarur.",
             "ekg, kardiogramma, yurak, tayyorgarlik"),
            ("faq", "Shifokor qabuliga qancha vaqt oldin kelish kerak?",
             "Talon bo'yicha belgilangan vaqtdan kamida 10 daqiqa oldin tegishli xona oldida hozir bo'lishingiz va ekrandagi chaqiruvni kuzatishingiz tavsiya etiladi.",
             "vaqt, necha daqiqa, qachon kelish, kechikish"),
            ("faq", "Talonni chop etish shartmi?",
             "Yo'q, talonni qog'ozda chop etish majburiy emas. Talondagi raqam (masalan TR-001) va xona raqamini telefoningizda saqlab qolsangiz yoki skrinshot qilsangiz kifoya.",
             "chop etish, qog'oz, talon, majburiymi")
        ]

        for kb in kb_entries:
            cursor.execute("""
                INSERT INTO ai_knowledge_base (category, question, answer, keywords)
                VALUES (?, ?, ?, ?)
            """, kb)

        # 9. Digital Medical Documents
        p1_id = patient_records[0][0] # Aliyev Anvar
        cursor.execute("""
            INSERT INTO medical_documents (patient_id, doctor_id, appointment_id, doc_type, title, content_json, notes)
            VALUES (?, ?, 1, 'visit_summary', 'Terapevt ko''rigi xulosasi', ?, 'Profilaktik tekshiruv tavsiyalari berildi')
        """, (p1_id, doc1_id, '{"anamnesis": "Bemor umumiy holsizlik va engil charchoqdan shikoyat qildi.", "diagnosis": "Astenik sindrom, surunkali charchoq", "recommendations": "1. Kun tartibiga rioya qilish. 2. Vitamin D3 2000 ME kuniga 1 mahal. 3. 2 haftadan so''ng qayta ko''rik."}'))

        cursor.execute("""
            INSERT INTO medical_documents (patient_id, doctor_id, appointment_id, doc_type, title, content_json, notes)
            VALUES (?, ?, 1, 'lab_result', 'Umumiy qon tahlili natijasi (KLA)', ?, 'Tahlil natijalari me''yor darajasida')
        """, (p1_id, doc1_id, '{"indicators": {"Gemoglobin": "142 g/l (Norma: 130-160)", "Eritrotsitlar": "4.5 x 10^12/l", "Leykotsitlar": "6.8 x 10^9/l", "EOCh (SOE)": "7 mm/soat"}, "conclusion": "Patologik o''zgarishlar aniqlanmadi."}'))

        # 10. Doctor Reviews
        cursor.execute("""
            INSERT INTO doctor_reviews (doctor_id, patient_id, rating, comment)
            VALUES (?, ?, 5, 'Dr. Rustamov juda tajribali va e''tiborli shifokor. Barcha savollarimga batafsil javob berdilar. Katta rahmat!')
        """, (doc1_id, p1_id))

        cursor.execute("""
            INSERT INTO doctor_reviews (doctor_id, patient_id, rating, comment)
            VALUES (?, ?, 5, 'Dr. Umarova yuqori malakali kardiolog. EKG tekshiruvini darhol o''tkazib tushuntirib berdilar.')
        """, (doc2_id, patient_records[1][0]))

        # 11. Favorite Doctors
        cursor.execute("""
            INSERT OR IGNORE INTO favorite_doctors (patient_id, doctor_id)
            VALUES (?, ?)
        """, (p1_id, doc1_id))
        cursor.execute("""
            INSERT OR IGNORE INTO favorite_doctors (patient_id, doctor_id)
            VALUES (?, ?)
        """, (p1_id, doc2_id))

        # 12. Clinic Announcements
        cursor.execute("""
            INSERT INTO clinic_announcements (title, content, priority)
            VALUES ('Profilaktik dispanserizatsiya haftaligi', 'Hurmatli fuqarolar! Poliklinikamizda 1-dekabrgacha bepul umumiy qon tahlili va EKG skriningi o''tkazilmoqda.', 'high')
        """)
        cursor.execute("""
            INSERT INTO clinic_announcements (title, content, priority)
            VALUES ('MEDI AI aqlli tibbiy yordamchi ishga tushirildi', 'Endi har bir bemor saytdagi MEDI AI yordamchisiga o''z shikoyatlarini yozib, kerakli mutaxassisni tezda aniqlashi mumkin.', 'normal')
        """)

        print("Database successfully seeded with realistic polyclinic data!")

if __name__ == "__main__":
    from backend.database import init_db
    init_db()
    seed_database()
