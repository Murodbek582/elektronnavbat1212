import uvicorn
import os
import sys
from pathlib import Path

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from backend.config import HOST, PORT, DEBUG

if __name__ == "__main__":
    print(f"============================================================")
    print(f"  ELEKTRON NAVBAT — POLIKLINIKA TIZIMI (v2.0.0)")
    print(f"  Server ishga tushmoqda: http://{HOST}:{PORT}")
    print(f"  WebSocket kanali: ws://{HOST}:{PORT}/ws/queue")
    print(f"  Hujjatlar (Swagger API): http://{HOST}:{PORT}/docs")
    print(f"============================================================")
    uvicorn.run("backend.app:app", host=HOST, port=PORT, reload=DEBUG)
