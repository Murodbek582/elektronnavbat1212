from fastapi import APIRouter, HTTPException, Depends, Response
from backend.database import fetch_all, fetch_one
from backend.auth import require_admin
from datetime import date, timedelta
import io
import csv

router = APIRouter(prefix="/api/analytics", tags=["Analytics & Reports"])

@router.get("/dashboard", dependencies=[Depends(require_admin)])
async def get_analytics_dashboard():
    today = str(date.today())
    seven_days_ago = str(date.today() - timedelta(days=7))
    thirty_days_ago = str(date.today() - timedelta(days=30))
    
    # 1. Total statistics
    total_patients = fetch_one("SELECT COUNT(id) as count FROM patients")["count"]
    total_doctors = fetch_one("SELECT COUNT(id) as count FROM doctors WHERE is_active = 1")["count"]
    
    # Today's appointments breakdown
    today_stats = fetch_one("""
        SELECT 
            COUNT(id) as total,
            SUM(CASE WHEN status = 'waiting' THEN 1 ELSE 0 END) as waiting,
            SUM(CASE WHEN status = 'in_consultation' THEN 1 ELSE 0 END) as serving,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
            SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent
        FROM appointments
        WHERE appointment_date = ?
    """, (today,))
    
    # 2. Daily trend (Last 7 days)
    daily_trend = fetch_all("""
        SELECT 
            appointment_date as date,
            COUNT(id) as total,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled
        FROM appointments
        WHERE appointment_date >= ?
        GROUP BY appointment_date
        ORDER BY appointment_date ASC
    """, (seven_days_ago,))
    
    # 3. Most requested doctors
    popular_doctors = fetch_all("""
        SELECT 
            d.id, d.full_name, d.specialization_uz, d.room_number,
            COUNT(a.id) as total_appointments,
            SUM(CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END) as completed_appointments
        FROM doctors d
        LEFT JOIN appointments a ON d.id = a.doctor_id
        WHERE d.is_active = 1
        GROUP BY d.id
        ORDER BY total_appointments DESC
        LIMIT 6
    """)
    
    # 4. Department distribution
    dept_distribution = fetch_all("""
        SELECT 
            dep.name_uz, dep.code,
            COUNT(a.id) as appointment_count
        FROM departments dep
        LEFT JOIN appointments a ON dep.id = a.department_id
        GROUP BY dep.id
        ORDER BY appointment_count DESC
    """)
    
    # 5. Average estimated waiting time
    avg_wait = 16  # standard baseline in minutes

    return {
        "metrics": {
            "total_patients": total_patients,
            "total_doctors": total_doctors,
            "today_total": today_stats["total"] or 0,
            "today_waiting": today_stats["waiting"] or 0,
            "today_serving": today_stats["serving"] or 0,
            "today_completed": today_stats["completed"] or 0,
            "today_cancelled": today_stats["cancelled"] or 0,
            "today_absent": today_stats["absent"] or 0,
            "avg_waiting_time_minutes": avg_wait
        },
        "daily_trend": daily_trend,
        "popular_doctors": popular_doctors,
        "department_distribution": dept_distribution
    }

@router.get("/export/csv", dependencies=[Depends(require_admin)])
async def export_appointments_csv(start_date: str = None, end_date: str = None):
    query = """
        SELECT 
            a.appointment_number,
            qt.ticket_number,
            a.appointment_date,
            a.start_time,
            a.end_time,
            p.full_name as patient_name,
            p.pinfl as patient_pinfl,
            p.phone as patient_phone,
            d.full_name as doctor_name,
            d.specialization_uz as doctor_specialization,
            d.room_number,
            dep.name_uz as department_name,
            a.status,
            a.reason,
            a.notes,
            a.created_at
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        JOIN doctors d ON a.doctor_id = d.id
        JOIN departments dep ON a.department_id = dep.id
        LEFT JOIN queue_tickets qt ON a.id = qt.appointment_id
        WHERE 1=1
    """
    params = []
    if start_date:
        query += " AND a.appointment_date >= ?"
        params.append(start_date)
    if end_date:
        query += " AND a.appointment_date <= ?"
        params.append(end_date)
        
    query += " ORDER BY a.appointment_date DESC, a.start_time ASC"
    rows = fetch_all(query, tuple(params))
    
    output = io.StringIO()
    # Write UTF-8 BOM for Excel compatibility with Uzbek Cyrillic/Latin characters
    output.write('\ufeff')
    
    writer = csv.writer(output)
    writer.writerow([
        "Qabul Raqami", "Talon Raqami", "Sana", "Boshlanish Vaqti", "Tugash Vaqti",
        "Bemor F.I.Sh", "JShShIR (PINFL)", "Telefon", "Shifokor F.I.Sh", "Mutaxassislik",
        "Xona", "Bo'lim", "Holat", "Murojaat Sababi", "Tashxis / Izoh", "Yaratilgan Vaqt"
    ])
    
    for r in rows:
        writer.writerow([
            r["appointment_number"],
            r["ticket_number"] or "",
            r["appointment_date"],
            r["start_time"],
            r["end_time"],
            r["patient_name"],
            r["patient_pinfl"],
            r["patient_phone"],
            r["doctor_name"],
            r["doctor_specialization"],
            r["room_number"],
            r["department_name"],
            r["status"],
            r["reason"] or "",
            r["notes"] or "",
            r["created_at"]
        ])
        
    csv_data = output.getvalue()
    filename = f"poliklinika_hisobot_{date.today()}.csv"
    
    return Response(
        content=csv_data,
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )
