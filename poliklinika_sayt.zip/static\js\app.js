// Main Application Controller & Router

let currentAppSection = "patient";

document.addEventListener("DOMContentLoaded", () => {
    // 0. Register PWA Service Worker
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/static/sw.js').catch(err => console.log('SW registration error:', err));
    }

    // 1. Initialize Theme
    initTheme();

    // 2. Initialize Language
    const savedLang = localStorage.getItem("poliklinika_lang") || "uz";
    setLanguage(savedLang);

    // 3. Initialize WebSocket & Live Clock
    connectLiveWebSocket();
    startLiveClock();
    updateSoundUI();

    // 4. Initialize Auth State
    updateAuthUI();

    // 5. Route to default or hash section
    const hash = window.location.hash.replace("#", "");
    if (["patient", "services", "live", "doctor", "admin"].includes(hash)) {
        showSection(hash);
    } else {
        showSection("patient");
    }

    // 6. Check unread notifications periodically
    loadNotificationsCount();

    // 7. Load Announcements
    loadClinicAnnouncements();
});

// Section Navigation Router
function showSection(sectionId) {
    currentAppSection = sectionId;
    window.location.hash = sectionId;

    // Update nav links
    document.querySelectorAll(".nav-link").forEach(link => {
        link.classList.remove("text-blue-600", "dark:text-blue-400", "font-extrabold", "bg-blue-50", "dark:bg-blue-950/40");
        link.classList.add("text-slate-600", "dark:text-slate-300");
    });

    const activeLink = document.getElementById(`nav-${sectionId}`);
    if (activeLink) {
        activeLink.classList.add("text-blue-600", "dark:text-blue-400", "font-extrabold", "bg-blue-50", "dark:bg-blue-950/40");
        activeLink.classList.remove("text-slate-600", "dark:text-slate-300");
    }

    // Hide all sections
    const sections = ["patient", "services", "live", "doctor", "admin"];
    sections.forEach(s => {
        const el = document.getElementById(`section-${s}`);
        if (el) el.classList.add("hidden");
    });

    // Show target section
    const target = document.getElementById(`section-${sectionId}`);
    if (target) target.classList.remove("hidden");

    // Trigger section-specific loaders
    if (sectionId === "patient") {
        initPatientPortal();
        loadMyAppointments();
    } else if (sectionId === "services") {
        if (typeof initServicesSection === "function") {
            initServicesSection();
        }
    } else if (sectionId === "live") {
        loadLiveQueue();
    } else if (sectionId === "doctor") {
        loadDoctorDashboard();
    } else if (sectionId === "admin") {
        loadAdminDashboard();
    }
}

// Dark / Light Mode Switcher
function initTheme() {
    const savedTheme = localStorage.getItem("poliklinika_theme") || "light";
    if (savedTheme === "dark") {
        document.documentElement.classList.add("dark");
    } else {
        document.documentElement.classList.remove("dark");
    }
    updateThemeIcon();
}

function toggleTheme() {
    const isDark = document.documentElement.classList.toggle("dark");
    localStorage.setItem("poliklinika_theme", isDark ? "dark" : "light");
    updateThemeIcon();
}

function updateThemeIcon() {
    const icon = document.getElementById("themeIcon");
    if (!icon) return;
    const isDark = document.documentElement.classList.contains("dark");
    if (isDark) {
        icon.innerHTML = `<svg class="w-5 h-5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>`;
    } else {
        icon.innerHTML = `<svg class="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>`;
    }
}

// Authentication UI & State
function updateAuthUI() {
    const userStr = localStorage.getItem("poliklinika_user");
    const navAuth = document.getElementById("navAuthSection");
    const navAdmin = document.getElementById("nav-admin");
    
    let user = null;
    if (userStr) {
        try {
            user = JSON.parse(userStr);
        } catch (e) {}
    }

    // Hide or show Admin link in top header
    if (navAdmin) {
        if (user && user.role === 'admin') {
            navAdmin.classList.remove("hidden");
        } else {
            navAdmin.classList.add("hidden");
        }
    }

    if (!navAuth) return;

    if (user) {
        const roleBadgeClass = user.role === 'admin' ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300' :
                               user.role === 'doctor' ? 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300' :
                               'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300';
        const roleLabel = user.role === 'admin' ? 'Administrator' :
                          user.role === 'doctor' ? 'Shifokor' : 'Bemor';

        navAuth.innerHTML = `
            <div class="flex items-center gap-3">
                <div class="text-right hidden sm:block">
                    <div class="text-xs font-bold text-slate-800 dark:text-slate-100">${user.full_name}</div>
                    <span class="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${roleBadgeClass}">
                        ${roleLabel}
                    </span>
                </div>
                <button onclick="logoutUser()" class="p-2 rounded-xl text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-800 transition" title="${t('logout_btn')}">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                </button>
            </div>
        `;
        return;
    }

    navAuth.innerHTML = `
        <div class="flex items-center gap-2">
            <button onclick="openAuthModal()" class="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 transition">
                ${t("login_btn")}
            </button>
            <button onclick="openRegisterModal()" class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm transition">
                ${t("register_btn")}
            </button>
        </div>
    `;
}

function openAdminPortal(e) {
    if (e) e.preventDefault();
    const userStr = localStorage.getItem("poliklinika_user");
    let user = null;
    if (userStr) {
        try { user = JSON.parse(userStr); } catch (err) {}
    }
    if (user && user.role === 'admin') {
        showSection('admin');
    } else {
        openAuthModal('admin');
    }
}

function logoutUser() {
    localStorage.removeItem("poliklinika_token");
    localStorage.removeItem("poliklinika_user");
    updateAuthUI();
    showToast("Tizimdan muvaffaqiyatli chiqildi.", "info");
    showSection("patient");
}

// Auth Modals
function openAuthModal(targetRole = "patient") {
    const modal = document.getElementById("authModal");
    if (!modal) return;
    modal.classList.remove("hidden");
    selectAuthRoleTab(targetRole);
}

function closeAuthModal() {
    const modal = document.getElementById("authModal");
    if (modal) modal.classList.add("hidden");
}

function selectAuthRoleTab(role) {
    document.querySelectorAll(".auth-tab-btn").forEach(b => {
        b.className = "auth-tab-btn flex-1 py-2 text-xs font-bold text-slate-500 border-b-2 border-transparent hover:text-slate-700";
    });

    const active = document.getElementById(`auth-tab-${role}`);
    if (active) {
        active.className = "auth-tab-btn flex-1 py-2 text-xs font-bold text-blue-600 border-b-2 border-blue-600";
    }

    const userInput = document.getElementById("loginUsername");
    const passInput = document.getElementById("loginPassword");
    const demoFillContainer = document.getElementById("authDemoQuickFill");

    if (role === "patient") {
        userInput.placeholder = "JShShIR (14 ta raqam) yoki telefon";
        demoFillContainer.innerHTML = `
            <div class="text-[11px] text-slate-500 mb-1.5 font-bold">Tezkor Demo hisoblar:</div>
            <div class="flex flex-wrap gap-2">
                <button type="button" onclick="fillLoginCreds('12345678901234', 'Patient123!')" class="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 text-xs font-semibold hover:bg-blue-100">
                    Aliyev Anvar
                </button>
                <button type="button" onclick="fillLoginCreds('11112222333344', 'Patient123!')" class="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 text-xs font-semibold hover:bg-blue-100">
                    Karimova Dilnoza
                </button>
            </div>
        `;
    } else if (role === "doctor") {
        userInput.placeholder = "Shifokor email manzili";
        demoFillContainer.innerHTML = `
            <div class="text-[11px] text-slate-500 mb-1.5 font-bold">Tezkor Shifokor hisoblari:</div>
            <div class="flex flex-wrap gap-2">
                <button type="button" onclick="fillLoginCreds('dr.rustamov@poliklinika.uz', 'Doctor123!')" class="px-2.5 py-1 rounded-lg bg-teal-50 text-teal-700 text-xs font-semibold hover:bg-teal-100">
                    Dr. Rustamov (Terapevt)
                </button>
                <button type="button" onclick="fillLoginCreds('dr.umarova@poliklinika.uz', 'Doctor123!')" class="px-2.5 py-1 rounded-lg bg-teal-50 text-teal-700 text-xs font-semibold hover:bg-teal-100">
                    Dr. Umarova (Kardiolog)
                </button>
            </div>
        `;
    } else if (role === "admin") {
        userInput.placeholder = "admin@poliklinika.uz";
        demoFillContainer.innerHTML = `
            <div class="text-[11px] text-slate-500 mb-1.5 font-bold">Tezkor Admin hisobi:</div>
            <div class="flex flex-wrap gap-2">
                <button type="button" onclick="fillLoginCreds('admin@poliklinika.uz', 'Admin123!')" class="px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 text-xs font-semibold hover:bg-indigo-100">
                    Bosh Administrator
                </button>
            </div>
        `;
    }
}

function fillLoginCreds(user, pass) {
    const u = document.getElementById("loginUsername");
    const p = document.getElementById("loginPassword");
    if (u) u.value = user;
    if (p) p.value = pass;
}

async function submitLogin(e) {
    e.preventDefault();
    const u = document.getElementById("loginUsername")?.value.trim();
    const p = document.getElementById("loginPassword")?.value.trim();

    if (!u || !p) {
        showToast("Iltimos, login va parolni kiriting", "warning");
        return;
    }

    const btn = e.target.querySelector("button[type='submit']");
    const oldText = btn ? btn.innerHTML : "";
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="inline-block animate-spin mr-2">⟳</span> Kirilmoqda...'; }

    try {
        const res = await apiCall("/api/auth/login", "POST", { username: u, password: p });
        localStorage.setItem("poliklinika_token", res.access_token);
        localStorage.setItem("poliklinika_user", JSON.stringify(res.user));
        updateAuthUI();
        closeAuthModal();
        showToast(`Xush kelibsiz, ${res.user.full_name}!`, "success");

        if (res.user.role === "admin") {
            showSection("admin");
        } else if (res.user.role === "doctor") {
            showSection("doctor");
        } else {
            showSection("patient");
            if (res.user.patient && res.user.patient.pinfl) {
                const pinInput = document.getElementById("patientPinflInput");
                if (pinInput) pinInput.value = res.user.patient.pinfl;
                if (typeof verifyPatientPINFL === "function") verifyPatientPINFL(res.user.patient.pinfl);
            }
        }
    } catch (err) {
        showToast(err.message, "error", "Kirish rad etildi");
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = oldText; }
    }
}

// Registration Modal Handlers
function openRegisterModal() {
    closeAuthModal();
    const modal = document.getElementById("registerModal");
    if (modal) modal.classList.remove("hidden");
}

function closeRegisterModal() {
    const modal = document.getElementById("registerModal");
    if (modal) modal.classList.add("hidden");
}

async function submitRegister(e) {
    e.preventDefault();
    const name = document.getElementById("regFullName")?.value.trim();
    const pinfl = document.getElementById("regPinfl")?.value.trim();
    const phone = document.getElementById("regPhone")?.value.trim();
    const birth = document.getElementById("regBirthDate")?.value;
    const gender = document.getElementById("regGender")?.value || "male";
    const password = document.getElementById("regPassword")?.value;

    if (!name || name.length < 3) {
        showToast("Iltimos, to'liq ism-familiyangizni kiriting", "warning");
        return;
    }

    if (!pinfl || !/^\d{14}$/.test(pinfl)) {
        showToast("JShShIR (PINFL) aynan 14 ta raqamdan iborat bo'lishi shart!", "warning");
        return;
    }

    let cleanPhone = (phone || "").replace(/[\s\-\(\)]/g, "");
    if (!cleanPhone.startsWith("+") && cleanPhone.startsWith("998")) cleanPhone = "+" + cleanPhone;
    else if (!cleanPhone.startsWith("+") && cleanPhone.length === 9) cleanPhone = "+998" + cleanPhone;

    if (!/^\+998\d{9}$/.test(cleanPhone)) {
        showToast("Telefon raqami O'zbekiston formatida (+998XXXXXXXXX) kiritilishi lozim", "warning");
        return;
    }

    if (!birth) {
        showToast("Iltimos, tug'ilgan sanangizni tanlang", "warning");
        return;
    }

    if (!password || password.length < 6) {
        showToast("Parol kamida 6 ta belgidan iborat bo'lishi lozim", "warning");
        return;
    }

    const btn = e.target.querySelector("button[type='submit']");
    const oldText = btn ? btn.innerHTML : "";
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="inline-block animate-spin mr-2">⟳</span> Ro\'yxatdan o\'tilmoqda...'; }

    try {
        const res = await apiCall("/api/auth/register-patient", "POST", {
            full_name: name,
            pinfl,
            phone: cleanPhone,
            birth_date: birth,
            gender,
            password
        });

        localStorage.setItem("poliklinika_token", res.access_token);
        localStorage.setItem("poliklinika_user", JSON.stringify(res.user));
        updateAuthUI();
        closeRegisterModal();
        showToast(res.message || "Muvaffaqiyatli ro'yxatdan o'tdingiz!", "success");
        showSection("patient");

        // Auto-fill and verify PINFL in portal
        const pinInput = document.getElementById("patientPinflInput");
        if (pinInput) pinInput.value = pinfl;
        if (typeof verifyPatientPINFL === "function") verifyPatientPINFL(pinfl);
    } catch (err) {
        showToast(err.message, "error", "Ro'yxatdan o'tishda xatolik");
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = oldText; }
    }
}

// Notifications Bell & Drawer
async function loadNotificationsCount() {
    const token = localStorage.getItem("poliklinika_token");
    if (!token) return;

    try {
        const res = await apiCall("/api/notifications/my");
        const count = res.unread_count || 0;
        const badge = document.getElementById("notifBadge");
        if (badge) {
            if (count > 0) {
                badge.textContent = count;
                badge.classList.remove("hidden");
            } else {
                badge.classList.add("hidden");
            }
        }
    } catch (e) {}
}

async function toggleNotificationsDrawer() {
    const drawer = document.getElementById("notificationsDrawer");
    if (!drawer) return;

    const isHidden = drawer.classList.contains("hidden");
    if (isHidden) {
        drawer.classList.remove("hidden");
        loadNotificationsList();
    } else {
        drawer.classList.add("hidden");
    }
}

async function loadNotificationsList() {
    const list = document.getElementById("notificationsList");
    if (!list) return;

    list.innerHTML = `<div class="p-6 text-center text-slate-400 text-xs">Yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/notifications/my");
        const notifs = res.notifications || [];

        if (notifs.length === 0) {
            list.innerHTML = `<div class="p-6 text-center text-slate-400 text-xs">${t("no_notifications")}</div>`;
            return;
        }

        list.innerHTML = notifs.map(n => `
            <div class="p-3.5 rounded-xl border ${n.is_read ? 'border-slate-100 dark:border-slate-800/80 bg-white dark:bg-slate-900 opacity-70' : 'border-blue-200 dark:border-blue-900 bg-blue-50/50 dark:bg-blue-950/20'} mb-2">
                <div class="flex items-center justify-between mb-1">
                    <span class="font-bold text-xs ${n.is_read ? 'text-slate-700 dark:text-slate-300' : 'text-blue-600 dark:text-blue-400'}">${n.title}</span>
                    <span class="text-[10px] text-slate-400">${n.created_at.slice(11, 16)}</span>
                </div>
                <div class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">${n.message}</div>
                ${!n.is_read ? `
                    <div class="mt-2 text-right">
                        <button onclick="markNotificationRead(${n.id})" class="text-[11px] font-bold text-blue-600 hover:underline">
                            O'qildi
                        </button>
                    </div>
                ` : ''}
            </div>
        `).join('');

        loadNotificationsCount();
    } catch (err) {
        list.innerHTML = `<div class="p-4 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

async function markNotificationRead(id) {
    try {
        await apiCall(`/api/notifications/mark-read/${id}`, "POST", {});
        loadNotificationsList();
    } catch (e) {}
}

async function markAllNotificationsRead() {
    try {
        await apiCall("/api/notifications/mark-all-read", "POST", {});
        loadNotificationsList();
    } catch (e) {}
}

// Announcements Loader
async function loadClinicAnnouncements() {
    try {
        const res = await apiCall("/api/announcements");
        const list = res.announcements || [];
        const container = document.getElementById("clinicAnnouncementBanner");
        if (!container || list.length === 0) return;

        const latest = list[0];
        container.innerHTML = `
            <div class="flex items-center justify-between gap-3 text-xs">
                <div class="flex items-center gap-2 overflow-hidden">
                    <span class="px-2 py-0.5 rounded-full ${latest.type === 'warning' ? 'bg-amber-500' : latest.type === 'urgent' ? 'bg-rose-500' : 'bg-blue-500'} text-white font-bold text-[10px] uppercase">
                        ${latest.type === 'urgent' ? 'Shoshilinch' : latest.type === 'warning' ? 'Muhim' : 'E\'lon'}
                    </span>
                    <span class="font-bold truncate text-slate-800 dark:text-slate-100">${latest.title}:</span>
                    <span class="truncate text-slate-600 dark:text-slate-300">${latest.content}</span>
                </div>
                <button onclick="this.closest('#clinicAnnouncementBanner').remove()" class="text-slate-400 hover:text-slate-600 text-xs px-1">✕</button>
            </div>
        `;
        container.classList.remove("hidden");
    } catch (err) {
        console.warn("Announcements could not be loaded:", err);
    }
}
