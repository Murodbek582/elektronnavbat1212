from fastapi import APIRouter, HTTPException, status, Depends, Query
from backend.database import fetch_all, fetch_one, execute, insert
from backend.auth import require_patient, require_admin, require_doctor_or_admin, get_current_user, log_audit
from pydantic import BaseModel, Field
import re
from typing import Optional

router = APIRouter(prefix="/api/patients", tags=["Patients"])

class PinflVerifyRequest(BaseModel):
    pinfl: str = Field(..., description="14 xonali JShShIR raqami")

class PatientUpdateProfileRequest(BaseModel):
    full_name: Optional[str] = None
    phone: Optional[str] = None
    birth_date: Optional[str] = None
    gender: Optional[str] = None
    address: Optional[str] = None
    blood_group: Optional[str] = None

# Mock database of Uzbekistan Citizens for Demo Mode
DEMO_CITIZENS = {
    "12345678901234": {
        "full_name": "Aliyev Anvar Anvarovich",
        "birth_date": "1985-04-12",
        "gender": "male",
        "address": "Toshkent shahri, Yunusobod tumani, 4-mavze 12-uy",
        "document": "AA 1234567"
    },
    "11112222333344": {
        "full_name": "Karimova Dilnoza Baxtiyorovna",
        "birth_date": "1992-08-23",
        "gender": "female",
        "address": "Toshkent shahri, Chilonzor tumani, 9-mavze 5-uy",
        "document": "AB 7654321"
    },
    "33334444555566": {
        "full_name": "Sobirov Jasur Otabekovich",
        "birth_date": "1998-11-05",
        "gender": "male",
        "address": "Toshkent shahri, Shayxontohur tumani, Navoiy ko'chasi 18-uy",
        "document": "AC 9988776"
    },
    "55556666777788": {
        "full_name": "Toirova Shahnoza Rustamovna",
        "birth_date": "1990-02-17",
        "gender": "female",
        "address": "Toshkent shahri, Mirzo Ulug'bek tumani, Mustaqillik shoh ko'chasi 4-uy",
        "document": "AD 5544332"
    }
}

@router.post("/verify-pinfl")
async def verify_pinfl(req: PinflVerifyRequest):
    pinfl = req.pinfl.strip()
    if not re.match(r"^\d{14}$", pinfl):
        raise HTTPException(
            status_code=400,
            detail="JShShIR (PINFL) aynan 14 ta raqamdan iborat bo'lishi shart!"
        )
        
    # Check if already registered in our system
    existing_patient = fetch_one("SELECT * FROM patients WHERE pinfl = ?", (pinfl,))
    
    # In Demo Mode: match known citizen or generate consistent simulated info
    if pinfl in DEMO_CITIZENS:
        citizen = DEMO_CITIZENS[pinfl]
    else:
        # Generates realistic demo name if random 14 digits entered
        citizen = {
            "full_name": f"Sinov Fuqaro {pinfl[-4:]}",
            "birth_date": "1995-01-01",
            "gender": "male" if int(pinfl[0]) % 2 != 0 else "female",
            "address": "O'zbekiston Respublikasi, Toshkent shahri",
            "document": f"AF {pinfl[:7]}"
        }
        
    return {
        "success": True,
        "is_registered": existing_patient is not None,
        "existing_patient_id": existing_patient["id"] if existing_patient else None,
        "data": {
            "pinfl": pinfl,
            "full_name": citizen["full_name"],
            "birth_date": citizen["birth_date"],
            "gender": citizen["gender"],
            "address": citizen["address"],
            "verification_source": "O'zbekiston Davlat Xizmatlari Integratsiyasi (Demo Shlyuz)"
        }
    }

@router.get("/appointments-by-pinfl")
async def get_appointments_by_pinfl(pinfl: str = Query(..., description="14 xonali JShShIR")):
    clean_pinfl = pinfl.strip()
    patient = fetch_one("SELECT id, full_name FROM patients WHERE pinfl = ?", (clean_pinfl,))
    if not patient:
        return {"upcoming_appointments": [], "past_appointments": []}
        
    upcoming_appointments = fetch_all("""
        SELECT a.*, d.full_name as doctor_name, d.room_number, d.photo_url as doctor_photo,
               dep.name_uz as department_name, dep.code as department_code,
               qt.ticket_number, qt.status as queue_status, qt.priority_number
        FROM appointments a
        JOIN doctors d ON a.doctor_id = d.id
        JOIN departments dep ON a.department_id = dep.id
        LEFT JOIN queue_tickets qt ON a.id = qt.appointment_id
        WHERE a.patient_id = ? AND a.appointment_date >= DATE('now') AND a.status IN ('waiting', 'in_consultation')
        ORDER BY a.appointment_date ASC, a.start_time ASC
    """, (patient["id"],))
    
    past_appointments = fetch_all("""
        SELECT a.*, d.full_name as doctor_name, d.room_number,
               dep.name_uz as department_name,
               qt.ticket_number, qt.status as queue_status
        FROM appointments a
        JOIN doctors d ON a.doctor_id = d.id
        JOIN departments dep ON a.department_id = dep.id
        LEFT JOIN queue_tickets qt ON a.id = qt.appointment_id
        WHERE a.patient_id = ? AND (a.appointment_date < DATE('now') OR a.status IN ('completed', 'cancelled', 'absent'))
        ORDER BY a.appointment_date DESC, a.start_time DESC
        LIMIT 20
    """, (patient["id"],))
    
    return {
        "patient": patient,
        "upcoming_appointments": upcoming_appointments,
        "past_appointments": past_appointments
    }

@router.get("/me")
async def get_my_patient_profile(current_user: dict = Depends(require_patient)):
    patient = fetch_one("SELECT * FROM patients WHERE user_id = ?", (current_user["id"],))
    if not patient:
        raise HTTPException(status_code=404, detail="Bemor profili topilmadi")
        
    upcoming_appointments = fetch_all("""
        SELECT a.*, d.full_name as doctor_name, d.room_number, d.photo_url as doctor_photo,
               dep.name_uz as department_name, dep.code as department_code,
               qt.ticket_number, qt.status as queue_status, qt.priority_number
        FROM appointments a
        JOIN doctors d ON a.doctor_id = d.id
        JOIN departments dep ON a.department_id = dep.id
        LEFT JOIN queue_tickets qt ON a.id = qt.appointment_id
        WHERE a.patient_id = ? AND a.appointment_date >= DATE('now') AND a.status IN ('waiting', 'in_consultation')
        ORDER BY a.appointment_date ASC, a.start_time ASC
    """, (patient["id"],))
    
    past_appointments = fetch_all("""
        SELECT a.*, d.full_name as doctor_name, d.room_number,
               dep.name_uz as department_name,
               qt.ticket_number, qt.status as queue_status
        FROM appointments a
        JOIN doctors d ON a.doctor_id = d.id
        JOIN departments dep ON a.department_id = dep.id
        LEFT JOIN queue_tickets qt ON a.id = qt.appointment_id
        WHERE a.patient_id = ? AND (a.appointment_date < DATE('now') OR a.status IN ('completed', 'cancelled', 'absent'))
        ORDER BY a.appointment_date DESC, a.start_time DESC
        LIMIT 20
    """, (patient["id"],))
    
    return {
        "user": current_user,
        "patient": patient,
        "upcoming_appointments": upcoming_appointments,
        "past_appointments": past_appointments
    }

@router.put("/me")
async def update_my_patient_profile(req: PatientUpdateProfileRequest, current_user: dict = Depends(require_patient)):
    patient = fetch_one("SELECT id FROM patients WHERE user_id = ?", (current_user["id"],))
    if not patient:
        raise HTTPException(status_code=404, detail="Bemor profili topilmadi")
        
    fields = []
    params = []
    
    for k, v in req.model_dump(exclude_unset=True).items():
        if v is not None:
            fields.append(f"{k} = ?")
            params.append(v)
            
    if fields:
        params.append(patient["id"])
        execute(f"UPDATE patients SET {', '.join(fields)} WHERE id = ?", tuple(params))
        
        if req.full_name:
            execute("UPDATE users SET full_name = ? WHERE id = ?", (req.full_name, current_user["id"]))
        if req.phone:
            execute("UPDATE users SET phone = ? WHERE id = ?", (req.phone, current_user["id"]))
            
    return {"message": "Bemor profili muvaffaqiyatli yangilandi"}

# Admin / Doctor Patient Search & Management
@router.get("", dependencies=[Depends(require_doctor_or_admin)])
async def get_patients(
    search: Optional[str] = None,
    limit: int = 50,
    offset: int = 0
):
    query = """
        SELECT p.*, u.email, u.phone as user_phone,
               (SELECT COUNT(id) FROM appointments WHERE patient_id = p.id) as total_appointments
        FROM patients p
        LEFT JOIN users u ON p.user_id = u.id
        WHERE 1=1
    """
    params = []
    if search:
        query += " AND (p.full_name LIKE ? OR p.pinfl LIKE ? OR p.phone LIKE ?)"
        s = f"%{search}%"
        params.extend([s, s, s])
        
    query += " ORDER BY p.id DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    
    patients = fetch_all(query, tuple(params))
    return {"patients": patients}
