from fastapi import APIRouter, HTTPException, Depends
from backend.database import fetch_all
from backend.auth import require_admin
from typing import Optional

router = APIRouter(prefix="/api/audit-logs", tags=["Audit & Security"])

@router.get("", dependencies=[Depends(require_admin)])
async def get_audit_logs(
    action: Optional[str] = None,
    limit: int = 50,
    offset: int = 0
):
    query = """
        SELECT al.*, u.full_name as user_name, u.role as user_role, u.email as user_email
        FROM audit_logs al
        LEFT JOIN users u ON al.user_id = u.id
        WHERE 1=1
    """
    params = []
    if action:
        query += " AND al.action = ?"
        params.append(action)
        
    query += " ORDER BY al.id DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    
    logs = fetch_all(query, tuple(params))
    return {"audit_logs": logs}
