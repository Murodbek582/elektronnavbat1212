from fastapi import APIRouter, HTTPException, status, Depends, Request
from backend.models import AppointmentBookRequest, AppointmentCancelRequest
from backend.database import get_db, fetch_one, fetch_all, insert, execute
from backend.auth import get_current_user, get_optional_user, require_patient, require_doctor_or_admin, log_audit, hash_password, create_access_token
from backend.websocket_manager import manager
from datetime import datetime, date, timedelta
from typing import Optional
import re

router = APIRouter(prefix="/api/appointments", tags=["Appointments"])


def _resolve_or_create_patient(req: AppointmentBookRequest, conn_cursor) -> tuple:
    """
    Given booking request, resolve the patient_id.
    If patient is in the system (by pinfl), return their id.
    If not, auto-register them using the inline patient info from the request.
    Returns (patient_id, patient_name, patient_phone, user_id)
    """
    pinfl = (req.patient_pinfl or "").strip()
    if not pinfl or not re.match(r"^\d{14}$", pinfl):
        return None, None, None, None

    # Check existing patient
    existing = conn_cursor.execute(
        "SELECT p.id, p.full_name, p.phone, p.user_id FROM patients p WHERE p.pinfl = ?", (pinfl,)
    ).fetchone()

    if existing:
        return existing["id"], existing["full_name"], existing["phone"], existing["user_id"]

    # Auto-register new patient
    full_name = (req.patient_name or f"Bemor {pinfl[-4:]}").strip()
    phone = (req.patient_phone or "+998900000000").strip()
    birth_date = req.patient_birth_date or "1990-01-01"
    gender = req.patient_gender or "male"
    address = req.patient_address or "O'zbekiston"

    # Create user account
    # Use PINFL as username; generate a stable password from pinfl
    pwd_hash = hash_password(f"Patient@{pinfl[:6]}")
    
    # Phone may already exist for a user (use pinfl-based fallback)
    existing_user = conn_cursor.execute("SELECT id FROM users WHERE phone = ?", (phone,)).fetchone()
    if existing_user:
        # Attach patient record to existing user
        user_id = existing_user["id"]
    else:
        conn_cursor.execute(
            "INSERT INTO users (phone, password_hash, role, full_name, is_active) VALUES (?, ?, 'patient', ?, 1)",
            (phone, pwd_hash, full_name)
        )
        user_id = conn_cursor.lastrowid

    conn_cursor.execute(
        """INSERT INTO patients (user_id, pinfl, full_name, birth_date, gender, phone, address, blood_group, is_verified)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)""",
        (user_id, pinfl, full_name, birth_date, gender, phone, address, "O'lchanmagan")
    )
    patient_id = conn_cursor.lastrowid
    return patient_id, full_name, phone, user_id


@router.post("/book")
async def book_appointment(req: AppointmentBookRequest, request: Request, current_user: dict = Depends(get_optional_user)):
    # 1. Determine patient_id — supports authenticated patients, admins, AND guest booking
    patient_id = None
    patient_name = None
    patient_phone = None
    acting_user_id = None

    if current_user and current_user["role"] == "patient":
        pat = fetch_one("SELECT id, full_name, phone FROM patients WHERE user_id = ?", (current_user["id"],))
        if not pat:
            raise HTTPException(status_code=400, detail="Bemor profili topilmadi")
        patient_id = pat["id"]
        patient_name = pat["full_name"]
        patient_phone = pat["phone"]
        acting_user_id = current_user["id"]
    elif current_user and current_user["role"] in ("admin", "doctor"):
        if not req.patient_id:
            raise HTTPException(status_code=400, detail="Bemor ID ko'rsatilishi shart")
        pat = fetch_one("SELECT id, full_name, phone FROM patients WHERE id = ?", (req.patient_id,))
        if not pat:
            raise HTTPException(status_code=404, detail="Ko'rsatilgan bemor topilmadi")
        patient_id = pat["id"]
        patient_name = pat["full_name"]
        patient_phone = pat["phone"]
        acting_user_id = current_user["id"]
    elif req.patient_pinfl:
        # Guest booking: auto-register patient from pinfl + inline info
        with get_db() as _conn:
            _cur = _conn.cursor()
            patient_id, patient_name, patient_phone, auto_user_id = _resolve_or_create_patient(req, _cur)
            acting_user_id = auto_user_id
        if not patient_id:
            raise HTTPException(status_code=400, detail="Bemor ma'lumotlari noto'g'ri yoki JShShIR (PINFL) topilmadi")
    else:
        raise HTTPException(status_code=400, detail="Navbat olish uchun JShShIR (PINFL) yoki bemor akkaunti talab qilinadi")
        
    # 2. Validate Doctor
    doctor = fetch_one("""
        SELECT d.*, dep.name_uz as dept_name, dep.code as dept_code
        FROM doctors d
        JOIN departments dep ON d.department_id = dep.id
        WHERE d.id = ? AND d.is_active = 1
    """, (req.doctor_id,))
    if not doctor:
        raise HTTPException(status_code=404, detail="Shifokor topilmadi yoki faol emas")
        
    department_id = doctor["department_id"]
    dept_code = doctor["dept_code"]
    room_number = doctor["room_number"]
    
    # 3. Validate Date & Working Days
    try:
        appt_date = datetime.strptime(req.appointment_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="Sana noto'g'ri ko'rsatildi (YYYY-MM-DD)")
        
    today = date.today()
    if appt_date < today:
        raise HTTPException(status_code=400, detail="O'tib ketgan sanaga qabul band qilib bo'lmaydi")
        
    weekday = appt_date.weekday()
    working_days = [int(x.strip()) - 1 for x in doctor["working_days"].split(",") if x.strip()]
    if weekday not in working_days:
        raise HTTPException(
            status_code=400,
            detail=f"Shifokor {doctor['full_name']} tanlangan kunda qabul o'tkazmaydi (dam olish kuni)"
        )
        
    # 4. Validate Working Hours & Time Slot
    try:
        slot_dt = datetime.strptime(f"{req.appointment_date} {req.start_time}", "%Y-%m-%d %H:%M")
    except ValueError:
        raise HTTPException(status_code=400, detail="Vaqt noto'g'ri ko'rsatildi (HH:MM)")
        
    if appt_date == today and slot_dt < datetime.now():
        raise HTTPException(status_code=400, detail="Ko'rsatilgan vaqt o'tib ketgan. Kelgusi vaqtni tanlang.")
        
    duration = doctor["appointment_duration"] or 20
    end_time_dt = slot_dt + timedelta(minutes=duration)
    end_time_str = end_time_dt.strftime("%H:%M")
    
    # Check bounds
    if req.start_time < doctor["start_time"] or end_time_str > doctor["end_time"]:
        raise HTTPException(
            status_code=400,
            detail=f"Tanlangan vaqt shifokor ish vaqtidan ({doctor['start_time']} - {doctor['end_time']}) tashqarida"
        )
        
    # Check lunch break (13:00 - 14:00)
    if "13:00" <= req.start_time < "14:00":
        raise HTTPException(status_code=400, detail="Soat 13:00 dan 14:00 gacha tushlik vaqti!")
        
    # 5. REQUIREMENT: Prevent duplicate active bookings for the same patient and doctor
    existing_patient_booking = fetch_one("""
        SELECT id, appointment_number, appointment_date, start_time 
        FROM appointments
        WHERE patient_id = ? AND doctor_id = ? AND appointment_date = ? AND status IN ('waiting', 'in_consultation')
    """, (patient_id, req.doctor_id, req.appointment_date))
    
    if existing_patient_booking:
        raise HTTPException(
            status_code=400,
            detail=f"Sizda allaqachon ushbu shifokor ({doctor['full_name']}) qabuliga {req.appointment_date} soat {existing_patient_booking['start_time']} ga faol navbat mavjud ({existing_patient_booking['appointment_number']}). Bir kunda bitta shifokorga qayta navbat olib bo'lmaydi."
        )
        
    # 6. REQUIREMENT: Prevent two patients from booking the same appointment slot
    with get_db() as conn:
        cursor = conn.cursor()
        
        slot_conflict = cursor.execute("""
            SELECT id FROM appointments 
            WHERE doctor_id = ? AND appointment_date = ? AND start_time = ? AND status != 'cancelled'
        """, (req.doctor_id, req.appointment_date, req.start_time)).fetchone()
        
        if slot_conflict:
            raise HTTPException(
                status_code=409,
                detail=f"Kechirasiz, {req.start_time} vaqtidagi oraliq boshqa bemor tomonidan band qilingan. Iltimos, boshqa vaqtni tanlang."
            )
            
        # 7. Generate Appointment Number & Daily Ticket Number
        # Count daily tickets for this department on this date to guarantee uniqueness
        cursor.execute("""
            SELECT COALESCE(MAX(priority_number), 0) FROM queue_tickets
            WHERE queue_date = ? AND ticket_number LIKE ?
        """, (req.appointment_date, f"{dept_code}-%"))
        daily_count = cursor.fetchone()[0] + 1
        
        ticket_number = f"{dept_code}-{daily_count:03d}"
        appt_number = f"APT-{req.appointment_date.replace('-', '')}-{req.doctor_id:02d}-{daily_count:03d}"
        
        cursor.execute("""
            INSERT INTO appointments (
                appointment_number, patient_id, doctor_id, department_id,
                appointment_date, start_time, end_time, status, reason
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'waiting', ?)
        """, (appt_number, patient_id, req.doctor_id, department_id, req.appointment_date, req.start_time, end_time_str, req.reason))
        appt_id = cursor.lastrowid
        
        # 8. Create Queue Ticket
        cursor.execute("""
            INSERT INTO queue_tickets (
                appointment_id, ticket_number, queue_date, priority_number, status, room_number
            ) VALUES (?, ?, ?, ?, 'waiting', ?)
        """, (appt_id, ticket_number, req.appointment_date, daily_count, room_number))
        ticket_id = cursor.lastrowid
        
        # 9. Create in-app notification & honest simulated SMS
        if acting_user_id:
            cursor.execute("""
                INSERT INTO notifications (user_id, title, message, type, channel, delivery_status)
                VALUES (?, ?, ?, 'booking', 'in_app', 'delivered')
            """, (
                acting_user_id,
                "Qabul muvaffaqiyatli band qilindi",
                f"Talon: {ticket_number}. Shifokor: {doctor['full_name']} ({room_number}-xona). Sana: {req.appointment_date}, Soat: {req.start_time}"
            ))
            
            cursor.execute("""
                INSERT INTO notifications (user_id, title, message, type, channel, delivery_status)
                VALUES (?, ?, ?, 'booking', 'sms', 'simulated')
            """, (
                acting_user_id,
                "SMS Xabarnoma (Simulyatsiya)",
                f"Hurmatli {patient_name}, Siz {req.appointment_date} {req.start_time} da {doctor['specialization_uz']} ({room_number}-xona) qabuliga yozildingiz. Talon: {ticket_number}."
            ))

    client_ip = request.client.host if request.client else "unknown"
    log_audit(acting_user_id, "BOOK_APPOINTMENT", "appointments", str(appt_id), client_ip, f"Booked ticket {ticket_number} for doctor {doctor['full_name']}")
    
    # 10. Broadcast real-time update via WebSocket
    await manager.broadcast({
        "event": "TICKET_CREATED",
        "ticket": {
            "ticket_number": ticket_number,
            "appointment_id": appt_id,
            "doctor_id": req.doctor_id,
            "doctor_name": doctor["full_name"],
            "room_number": room_number,
            "appointment_date": req.appointment_date,
            "start_time": req.start_time,
            "status": "waiting"
        }
    })

    # Generate auto-login token for guest patients so they can view their ticket
    guest_token = None
    if acting_user_id and (not current_user or current_user.get("role") not in ("admin", "doctor")):
        guest_token = create_access_token({"sub": str(acting_user_id), "role": "patient", "name": patient_name})

    return {
        "success": True,
        "message": "Navbat muvaffaqiyatli band qilindi!",
        "guest_token": guest_token,
        "patient_name": patient_name,
        "appointment": {
            "id": appt_id,
            "appointment_number": appt_number,
            "ticket_number": ticket_number,
            "doctor_name": doctor["full_name"],
            "specialization": doctor["specialization_uz"],
            "room_number": room_number,
            "department": doctor["dept_name"],
            "date": req.appointment_date,
            "time": f"{req.start_time} - {end_time_str}",
            "patient_name": patient_name,
            "patient_phone": patient_phone,
            "status": "waiting"
        }
    }

@router.get("/{appointment_id}/ticket")
async def get_appointment_ticket(appointment_id: int):
    query = """
        SELECT a.*, p.full_name as patient_name, p.pinfl as patient_pinfl, p.phone as patient_phone,
               p.birth_date as patient_birth_date,
               d.full_name as doctor_name, d.specialization_uz as doctor_specialization,
               d.room_number, dep.name_uz as department_name, dep.code as department_code,
               qt.ticket_number, qt.priority_number, qt.status as queue_status, qt.called_at
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        JOIN doctors d ON a.doctor_id = d.id
        JOIN departments dep ON a.department_id = dep.id
        LEFT JOIN queue_tickets qt ON a.id = qt.appointment_id
        WHERE a.id = ?
    """
    ticket = fetch_one(query, (appointment_id,))
    if not ticket:
        raise HTTPException(status_code=404, detail="Talon topilmadi")
        
    # Mask PINFL for patient privacy (e.g. 123456******34)
    raw_pinfl = ticket["patient_pinfl"]
    masked_pinfl = raw_pinfl[:6] + "******" + raw_pinfl[-2:] if raw_pinfl and len(raw_pinfl) == 14 else raw_pinfl
    ticket["masked_pinfl"] = masked_pinfl
    
    return {"ticket": ticket}

@router.post("/{appointment_id}/cancel")
async def cancel_appointment(appointment_id: int, req: AppointmentCancelRequest, current_user: dict = Depends(get_current_user)):
    appt = fetch_one("""
        SELECT a.*, p.user_id as patient_user_id, qt.ticket_number 
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        LEFT JOIN queue_tickets qt ON a.id = qt.appointment_id
        WHERE a.id = ?
    """, (appointment_id,))
    
    if not appt:
        raise HTTPException(status_code=404, detail="Qabul topilmadi")
        
    # Authorization check
    if current_user["role"] == "patient" and appt["patient_user_id"] != current_user["id"]:
        raise HTTPException(status_code=403, detail="Siz faqat o'zingizning qabulingizni bekor qila olasiz")
        
    if appt["status"] in ("completed", "cancelled"):
        raise HTTPException(status_code=400, detail=f"Ushbu qabul allaqachon '{appt['status']}' holatida")
        
    # Check cancellation policy: cannot cancel past appointments
    try:
        appt_dt = datetime.strptime(f"{appt['appointment_date']} {appt['start_time']}", "%Y-%m-%d %H:%M")
        if appt_dt < datetime.now() and current_user["role"] == "patient":
            raise HTTPException(status_code=400, detail="O'tib ketgan yoki hozirgi vaqtdagi qabulni bekor qilib bo'lmaydi")
    except ValueError:
        pass
        
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE appointments SET status = 'cancelled', notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                       (f"Bekor qilindi. Sabab: {req.reason}", appointment_id))
        cursor.execute("UPDATE queue_tickets SET status = 'cancelled' WHERE appointment_id = ?", (appointment_id,))
        
        # In-app notification
        cursor.execute("""
            INSERT INTO notifications (user_id, title, message, type, channel, delivery_status)
            VALUES (?, 'Qabul bekor qilindi', ?, 'cancellation', 'in_app', 'delivered')
        """, (appt["patient_user_id"], f"Talon: {appt['ticket_number']}. Qabul bekor qilindi. Sabab: {req.reason}"))
        
    log_audit(current_user["id"], "CANCEL_APPOINTMENT", "appointments", str(appointment_id), details=req.reason)
    
    await manager.broadcast({
        "event": "TICKET_CANCELLED",
        "appointment_id": appointment_id,
        "ticket_number": appt["ticket_number"]
    })
    
    return {"message": "Qabul muvaffaqiyatli bekor qilindi"}

@router.get("")
async def get_all_appointments(
    date: Optional[str] = None,
    doctor_id: Optional[int] = None,
    department_id: Optional[int] = None,
    status: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
    current_user: dict = Depends(require_doctor_or_admin)
):
    query = """
        SELECT a.*, p.full_name as patient_name, p.pinfl as patient_pinfl, p.phone as patient_phone,
               d.full_name as doctor_name, d.room_number,
               dep.name_uz as department_name, dep.code as department_code,
               qt.ticket_number, qt.status as queue_status, qt.called_at, qt.priority_number
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        JOIN doctors d ON a.doctor_id = d.id
        JOIN departments dep ON a.department_id = dep.id
        LEFT JOIN queue_tickets qt ON a.id = qt.appointment_id
        WHERE 1=1
    """
    params = []
    
    # Doctor data isolation: if logged in as doctor, only see their own appointments unless admin!
    if current_user["role"] == "doctor":
        doc = fetch_one("SELECT id FROM doctors WHERE user_id = ?", (current_user["id"],))
        if doc:
            query += " AND a.doctor_id = ?"
            params.append(doc["id"])
    elif doctor_id is not None:
        query += " AND a.doctor_id = ?"
        params.append(doctor_id)
        
    if date:
        query += " AND a.appointment_date = ?"
        params.append(date)
        
    if department_id is not None:
        query += " AND a.department_id = ?"
        params.append(department_id)
        
    if status:
        query += " AND a.status = ?"
        params.append(status)
        
    if search:
        query += " AND (p.full_name LIKE ? OR p.pinfl LIKE ? OR qt.ticket_number LIKE ? OR a.appointment_number LIKE ?)"
        s = f"%{search}%"
        params.extend([s, s, s, s])
        
    query += " ORDER BY a.appointment_date DESC, a.start_time ASC LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    
    appointments = fetch_all(query, tuple(params))
    return {"appointments": appointments}
