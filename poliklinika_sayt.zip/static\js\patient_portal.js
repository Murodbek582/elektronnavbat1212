// Patient Portal & Online Queue Booking Wizard
// Fully reworked: step-by-step wizard with validation, guest booking, multilingual support

// ─── Booking State ──────────────────────────────────────────────────────────
let selectedDepartmentId = null;
let selectedDepartmentData = null;
let selectedDoctorId = null;
let selectedDoctorData = null;
let selectedDate = new Date().toISOString().split('T')[0];
let selectedSlotTime = null;
let verifiedCitizen = null;

// ─── PINFL Mask helper ──────────────────────────────────────────────────────
function maskPINFL(pinfl) {
    if (!pinfl || pinfl.length !== 14) return pinfl || '—';
    return pinfl.slice(0, 6) + '******' + pinfl.slice(-2);
}

// ─── Step visibility helpers ────────────────────────────────────────────────
const STEPS = ['step-pinfl', 'step-department', 'step-doctor', 'step-datetime'];

function showStepProgress(activeStep) {
    // 0 = PINFL, 1 = Department, 2 = Doctor, 3 = Date/Time
    STEPS.forEach((id, i) => {
        const el = document.getElementById(id);
        if (!el) return;
        if (i <= activeStep) {
            el.style.opacity = '1';
            el.style.pointerEvents = '';
        } else {
            el.style.opacity = i === activeStep + 1 ? '0.5' : '0.3';
            el.style.pointerEvents = i > activeStep + 1 ? 'none' : '';
        }
    });

    // Update step badges in progress bar
    for (let i = 1; i <= 3; i++) {
        const badge = document.getElementById(`stepBadge-${i}`);
        if (!badge) continue;
        if (i <= activeStep) {
            badge.className = 'w-7 h-7 rounded-lg bg-blue-600 text-white font-black text-xs flex items-center justify-center shrink-0';
            badge.textContent = '✓';
        } else if (i === activeStep + 1) {
            badge.className = 'w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 font-black text-xs flex items-center justify-center shrink-0 ring-2 ring-blue-500/40';
            badge.textContent = i + 1;
        } else {
            badge.className = 'w-7 h-7 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-500 font-black text-xs flex items-center justify-center shrink-0';
            badge.textContent = i + 1;
        }
    }
}

// ─── Initialize ─────────────────────────────────────────────────────────────
async function initPatientPortal() {
    loadDepartments();
    setupDateSelector();
    showStepProgress(0);

    // Auto-fill if already logged in as patient
    const userStr = localStorage.getItem("poliklinika_user");
    if (userStr) {
        try {
            const user = JSON.parse(userStr);
            if (user.role === "patient" && user.patient && user.patient.pinfl) {
                const pinInput = document.getElementById("patientPinflInput");
                if (pinInput) pinInput.value = user.patient.pinfl;
                verifyPatientPINFL(user.patient.pinfl);
            }
        } catch (e) {}
    }
}

// ─── 1. PINFL Verification ───────────────────────────────────────────────────
async function verifyPatientPINFL(customPinfl = null) {
    const input = document.getElementById("patientPinflInput");
    const pinfl = customPinfl || (input ? input.value.trim() : "");
    const infoBox = document.getElementById("verifiedPatientCard");
    const errorBox = document.getElementById("pinflErrorMsg");

    if (errorBox) { errorBox.textContent = ''; errorBox.classList.add("hidden"); }

    if (!/^\d{14}$/.test(pinfl)) {
        if (errorBox) {
            errorBox.textContent = "JShShIR (PINFL) aynan 14 ta raqamdan iborat bo'lishi shart!";
            errorBox.classList.remove("hidden");
        }
        return;
    }

    // Show loading
    const btn = document.querySelector('[onclick="verifyPatientPINFL()"]');
    if (btn) { btn.disabled = true; btn.textContent = '...'; }

    try {
        const res = await apiCall("/api/patients/verify-pinfl", "POST", { pinfl });
        if (res.success && res.data) {
            verifiedCitizen = res.data;
            if (infoBox) {
                infoBox.classList.remove("hidden");
                document.getElementById("verifiedPatientName").textContent = verifiedCitizen.full_name;
                document.getElementById("verifiedPatientBirth").textContent = `Tug'ilgan sana: ${verifiedCitizen.birth_date}`;
                document.getElementById("verifiedPatientAddress").textContent = verifiedCitizen.address || '';
                document.getElementById("verifiedPatientPinfl").textContent = `JShShIR: ${maskPINFL(verifiedCitizen.pinfl)}`;
            }
            showStepProgress(1);
            updateBookButtonState();
            showToast("Shaxs muvaffaqiyatli tasdiqlandi!", "success");

            // Load existing appointments for this verified citizen
            loadMyAppointments();

            // Smoothly scroll down to Step 2: Department Selection
            setTimeout(() => {
                const step2 = document.getElementById("step-department");
                if (step2) step2.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 250);
        }
    } catch (err) {
        if (errorBox) {
            errorBox.textContent = err.message || "Tekshirishda xatolik yuz berdi";
            errorBox.classList.remove("hidden");
        }
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = t("pinfl_verify_btn") || 'Tekshirish'; }
    }
}

function fillDemoPatient(pinfl) {
    const input = document.getElementById("patientPinflInput");
    if (input) {
        input.value = pinfl;
        verifyPatientPINFL(pinfl);
    }
}

// ─── 2. Load Departments ─────────────────────────────────────────────────────
async function loadDepartments() {
    const grid = document.getElementById("departmentsGrid");
    if (!grid) return;

    grid.innerHTML = `<div class="col-span-3 p-6 text-center text-slate-400 text-sm animate-pulse">Bo'limlar yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/departments");
        const depts = res.departments || [];

        if (depts.length === 0) {
            grid.innerHTML = `<div class="col-span-3 p-6 text-center text-slate-400">Hozircha bo'limlar mavjud emas.</div>`;
            return;
        }

        const lang = (typeof getCurrentLang === 'function') ? getCurrentLang() : 'uz';
        const nameKey = lang === 'ru' ? 'name_ru' : lang === 'en' ? 'name_en' : 'name_uz';
        const descKey = lang === 'ru' ? 'description_ru' : lang === 'en' ? 'description_en' : 'description_uz';

        const DEPT_ICONS = {
            TR: '🩺', KD: '❤️', NV: '🧠', PD: '👶', JR: '🔪', OF: '👁️',
            ST: '🦷', GN: '🌸', EN: '💉', DR: '🧴'
        };

        grid.innerHTML = depts.map(d => {
            const icon = DEPT_ICONS[d.code] || '🏥';
            return `
            <div onclick="selectDepartment(${d.id})" id="dept-card-${d.id}"
                 class="dept-card group p-5 rounded-2xl border-2 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-blue-500 dark:hover:border-blue-500 cursor-pointer transition-all duration-200 shadow-sm hover:shadow-md flex flex-col justify-between select-none active:scale-95"
                 role="button" tabindex="0" aria-label="Tanlash: ${d[nameKey] || d.name_uz}"
                 onkeydown="if(event.key==='Enter'||event.key===' ')selectDepartment(${d.id})">
                <div>
                    <div class="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-2xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                        ${icon}
                    </div>
                    <div class="font-bold text-sm text-slate-800 dark:text-slate-100 mb-1 leading-tight">${d[nameKey] || d.name_uz}</div>
                    <p class="text-xs text-slate-500 dark:text-slate-400 leading-relaxed line-clamp-2">${d[descKey] || d.description_uz || ''}</p>
                </div>
                <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
                    <span class="text-slate-400">${d.doctor_count || 0} ta mutaxassis</span>
                    <span class="px-3 py-1 rounded-lg bg-blue-600 text-white font-bold text-[11px] group-hover:bg-blue-700 transition">Tanlash →</span>
                </div>
            </div>`;
        }).join('');

    } catch (err) {
        grid.innerHTML = `<div class="col-span-3 p-6 text-center text-rose-500 text-sm">Bo'limlarni yuklab bo'lmadi: ${err.message}</div>`;
    }
}

function selectDepartment(deptId) {
    selectedDepartmentId = deptId;
    selectedDoctorId = null;
    selectedDoctorData = null;
    selectedSlotTime = null;

    // Visual selection state
    document.querySelectorAll(".dept-card").forEach(el => {
        el.classList.remove("border-blue-600", "dark:border-blue-500", "ring-2", "ring-blue-500/30", "bg-blue-50", "dark:bg-blue-950/20");
        el.classList.add("border-slate-200", "dark:border-slate-800");
    });
    const active = document.getElementById(`dept-card-${deptId}`);
    if (active) {
        active.classList.remove("border-slate-200", "dark:border-slate-800");
        active.classList.add("border-blue-600", "dark:border-blue-500", "ring-2", "ring-blue-500/30", "bg-blue-50", "dark:bg-blue-950/20");
    }

    updateBookButtonState();
    loadDoctorsForDepartment(deptId);
    showStepProgress(2);

    // Scroll to doctor list on mobile
    setTimeout(() => {
        const doctorEl = document.getElementById("doctorsList");
        if (doctorEl) doctorEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 150);
}

// ─── 3. Load Doctors ─────────────────────────────────────────────────────────
async function loadDoctorsForDepartment(deptId) {
    const list = document.getElementById("doctorsList");
    if (!list) return;

    list.innerHTML = `<div class="p-6 text-center text-slate-400 text-sm animate-pulse">Shifokorlar yuklanmoqda...</div>`;
    updateBookButtonState();

    try {
        const res = await apiCall(`/api/doctors?department_id=${deptId}&is_active=true`);
        const doctors = res.doctors || [];

        if (doctors.length === 0) {
            list.innerHTML = `
                <div class="p-8 text-center rounded-2xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 text-sm">
                    ⚠️ Ushbu bo'limda hozircha faol shifokorlar mavjud emas.
                </div>`;
            return;
        }

        const lang = (typeof getCurrentLang === 'function') ? getCurrentLang() : 'uz';
        const specKey = lang === 'ru' ? 'specialization_ru' : lang === 'en' ? 'specialization_en' : 'specialization_uz';

        list.innerHTML = doctors.map(doc => `
            <div onclick="selectDoctor(${doc.id})" id="doctor-card-${doc.id}"
                 class="doctor-card group p-5 rounded-2xl border-2 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-blue-500 dark:hover:border-blue-500 cursor-pointer transition-all duration-200 shadow-sm hover:shadow-md flex items-center justify-between gap-4 select-none active:scale-[0.98]"
                 role="button" tabindex="0" aria-label="Tanlash: ${doc.full_name}"
                 onkeydown="if(event.key==='Enter'||event.key===' ')selectDoctor(${doc.id})">
                <div class="flex items-center gap-4">
                    <div class="relative shrink-0">
                        <img src="${doc.photo_url || ''}" alt="${doc.full_name}"
                             class="w-16 h-16 rounded-2xl object-cover border-2 border-slate-200 dark:border-slate-700 bg-blue-50"
                             onerror="this.src='';this.onerror=null;this.style.display='none';this.nextElementSibling.style.display='flex'">
                        <div class="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-black text-lg flex items-center justify-center" style="display:none">
                            ${doc.full_name.slice(3, 5).toUpperCase()}
                        </div>
                    </div>
                    <div>
                        <div class="font-bold text-base text-slate-800 dark:text-slate-100">${doc.full_name}</div>
                        <div class="text-xs text-blue-600 dark:text-blue-400 font-semibold">${doc[specKey] || doc.specialization_uz}</div>
                        <div class="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5">
                            <span>🕒 ${doc.start_time} – ${doc.end_time}</span>
                            <span>⏱ ${doc.appointment_duration} daqiqa</span>
                        </div>
                    </div>
                </div>
                <div class="text-right shrink-0 flex flex-col items-end gap-2">
                    <span class="inline-block px-3 py-1.5 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 font-bold text-sm mono">
                        ${doc.room_number}-Xona
                    </span>
                    <span class="px-2.5 py-1 rounded-lg bg-blue-600 text-white font-bold text-[11px] group-hover:bg-blue-700 transition">Tanlash →</span>
                </div>
            </div>
        `).join('');

        // Auto-select first doctor only if none selected
        if (!selectedDoctorId && doctors.length > 0) {
            selectDoctor(doctors[0].id);
        }
    } catch (err) {
        list.innerHTML = `<div class="p-6 text-center text-rose-500 text-sm">Shifokorlarni yuklab bo'lmadi: ${err.message}</div>`;
    }
}

async function selectDoctor(doctorId) {
    selectedDoctorId = doctorId;
    selectedSlotTime = null;

    document.querySelectorAll(".doctor-card").forEach(el => {
        el.classList.remove("border-blue-600", "dark:border-blue-500", "ring-2", "ring-blue-500/30", "bg-blue-50/50", "dark:bg-blue-950/20");
        el.classList.add("border-slate-200", "dark:border-slate-800");
    });
    const active = document.getElementById(`doctor-card-${doctorId}`);
    if (active) {
        active.classList.remove("border-slate-200", "dark:border-slate-800");
        active.classList.add("border-blue-600", "dark:border-blue-500", "ring-2", "ring-blue-500/30", "bg-blue-50/50", "dark:bg-blue-950/20");
    }

    try {
        const res = await apiCall(`/api/doctors/${doctorId}`);
        selectedDoctorData = res.doctor || null;
    } catch (e) {}

    updateBookButtonState();
    loadTimeSlots();
    showStepProgress(3);
}

// ─── 4. Date & Time Slot Selection ───────────────────────────────────────────
function selectQuickDate(daysAhead) {
    const d = new Date();
    d.setDate(d.getDate() + daysAhead);
    const dateStr = d.toISOString().split('T')[0];
    
    const dateInput = document.getElementById("appointmentDateInput");
    if (dateInput) dateInput.value = dateStr;
    
    selectedDate = dateStr;
    selectedSlotTime = null;

    // Highlight button
    [0, 1, 2].forEach(i => {
        const btn = document.getElementById(`quickDateBtn-${i}`);
        if (!btn) return;
        if (i === daysAhead) {
            btn.className = "px-3.5 py-2.5 rounded-xl text-xs font-bold border border-blue-600 bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 transition";
        } else {
            btn.className = "px-3.5 py-2.5 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 hover:border-blue-500 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 transition";
        }
    });

    updateBookButtonState();
    loadTimeSlots();
}

function setupDateSelector() {
    const dateInput = document.getElementById("appointmentDateInput");
    if (!dateInput) return;

    const today = new Date().toISOString().split('T')[0];
    dateInput.value = today;
    dateInput.min = today;
    selectedDate = today;

    const maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + 30);
    dateInput.max = maxDate.toISOString().split('T')[0];

    dateInput.addEventListener("change", (e) => {
        selectedDate = e.target.value;
        selectedSlotTime = null;

        // Reset quick buttons highlight
        [0, 1, 2].forEach(i => {
            const btn = document.getElementById(`quickDateBtn-${i}`);
            if (btn) btn.className = "px-3.5 py-2.5 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 hover:border-blue-500 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 transition";
        });

        updateBookButtonState();
        loadTimeSlots();
    });
}

async function loadTimeSlots() {
    if (!selectedDoctorId) return;

    const container = document.getElementById("timeSlotsContainer");
    if (!container) return;

    container.innerHTML = `<div class="col-span-full p-4 text-center text-slate-400 text-sm animate-pulse">Bo'sh vaqtlar hisoblanmoqda...</div>`;
    selectedSlotTime = null;
    updateBookButtonState();

    try {
        const res = await apiCall(`/api/doctors/${selectedDoctorId}/available-slots?target_date=${selectedDate}`);
        const slots = res.slots || [];

        if (slots.length === 0) {
            container.innerHTML = `
                <div class="col-span-full p-6 text-center text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-800">
                    ⚠️ ${res.message || "Ushbu kunda qabul bo'sh vaqtlari mavjud emas. Boshqa kun tanlang."}
                </div>
            `;
            return;
        }

        container.innerHTML = slots.map(s => {
            if (s.is_lunch) {
                return `<button type="button" disabled
                    class="p-2.5 rounded-xl border border-dashed border-slate-200 dark:border-slate-700 text-slate-300 dark:text-slate-600 text-xs font-semibold text-center cursor-not-allowed bg-slate-50 dark:bg-slate-900">
                    ${s.start_time}<br><span class="text-[10px]">🍽 Tushlik</span>
                </button>`;
            } else if (s.is_booked) {
                return `<button type="button" disabled
                    class="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-400 dark:text-slate-500 text-xs font-semibold text-center cursor-not-allowed">
                    ${s.start_time}<br><span class="text-[10px] text-rose-500">🔒 Band</span>
                </button>`;
            } else if (s.is_past) {
                return `<button type="button" disabled
                    class="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-300 dark:text-slate-600 text-xs font-semibold text-center cursor-not-allowed">
                    ${s.start_time}<br><span class="text-[10px]">O'tgan</span>
                </button>`;
            } else {
                return `<button type="button" onclick="selectSlot('${s.start_time}', '${s.end_time}')"
                    id="slot-btn-${s.start_time.replace(':', '')}"
                    class="slot-btn p-3 rounded-xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:border-blue-500 hover:text-blue-700 dark:hover:text-blue-300 text-xs font-bold text-center cursor-pointer transition-all active:scale-95">
                    ${s.start_time}<br><span class="text-[10px] text-slate-400">${s.end_time}</span>
                </button>`;
            }
        }).join('');
    } catch (err) {
        container.innerHTML = `<div class="col-span-full p-4 text-center text-rose-500 text-sm">${err.message}</div>`;
    }
}

function selectSlot(startTime, endTime) {
    selectedSlotTime = startTime;

    document.querySelectorAll(".slot-btn").forEach(btn => {
        btn.classList.remove("bg-blue-600", "text-white", "border-blue-600", "shadow-md", "dark:bg-blue-600");
        btn.classList.add("bg-white", "dark:bg-slate-800", "text-slate-700", "dark:text-slate-200", "border-slate-200", "dark:border-slate-700");
    });

    const activeBtn = document.getElementById(`slot-btn-${startTime.replace(':', '')}`);
    if (activeBtn) {
        activeBtn.classList.remove("bg-white", "dark:bg-slate-800", "text-slate-700", "dark:text-slate-200", "border-slate-200", "dark:border-slate-700");
        activeBtn.classList.add("bg-blue-600", "dark:bg-blue-600", "text-white", "border-blue-600", "shadow-md");
    }
    updateBookButtonState();
}

function updateBookButtonState() {
    const btn = document.getElementById("submitBookingBtn");
    if (!btn) return;
    const ready = !!(verifiedCitizen && selectedDoctorId && selectedDate && selectedSlotTime);
    btn.disabled = !ready;

    // Update summary label on the button
    if (ready && selectedDoctorData) {
        btn.innerHTML = `<span>✅ Navbat olish — ${selectedDate} soat ${selectedSlotTime}</span> →`;
    } else {
        btn.innerHTML = `<span data-i18n="book_btn">Navbat talonini olish</span> →`;
    }
}

// ─── 5. Submit Booking ────────────────────────────────────────────────────────
async function submitBooking() {
    if (!verifiedCitizen) {
        showToast("Iltimos, avval 14 xonali JShShIR raqamini tasdiqlang", "warning");
        document.getElementById("patientPinflInput")?.focus();
        return;
    }
    if (!selectedDepartmentId) {
        showToast("Iltimos, tibbiyot bo'limini tanlang", "warning");
        return;
    }
    if (!selectedDoctorId) {
        showToast("Iltimos, shifokorni tanlang", "warning");
        return;
    }
    if (!selectedSlotTime) {
        showToast("Iltimos, qabul vaqtini tanlang", "warning");
        return;
    }

    const btn = document.getElementById("submitBookingBtn");
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<span class="inline-block animate-spin mr-2">⟳</span> Talon rasmiylashtirilmoqda...`;
    }

    try {
        const bookingPayload = {
            doctor_id: selectedDoctorId,
            department_id: selectedDepartmentId,
            appointment_date: selectedDate,
            start_time: selectedSlotTime,
            reason: "Umumiy tibbiy maslahat va tekshiruv",
            // Guest fields — backend will auto-register if not logged in
            patient_pinfl: verifiedCitizen.pinfl,
            patient_name: verifiedCitizen.full_name,
            patient_phone: verifiedCitizen.phone || "+998900000000",
            patient_birth_date: verifiedCitizen.birth_date,
            patient_gender: verifiedCitizen.gender || "male",
            patient_address: verifiedCitizen.address
        };

        const res = await apiCall("/api/appointments/book", "POST", bookingPayload);

        if (res.success) {
            // If backend issued a guest token, save it so patient can view their appointments
            if (res.guest_token) {
                localStorage.setItem("poliklinika_token", res.guest_token);
                localStorage.setItem("poliklinika_user", JSON.stringify({
                    full_name: res.patient_name || verifiedCitizen.full_name,
                    role: "patient",
                    patient: { pinfl: verifiedCitizen.pinfl }
                }));
                if (typeof updateAuthUI === 'function') updateAuthUI();
            }

            showToast(res.message || "Navbat muvaffaqiyatli band qilindi!", "success");

            // Event 1: Voice announcement
            const ticketNum = res.appointment?.ticket_number;
            if (typeof announceQueueEvent1 === 'function' && ticketNum) {
                announceQueueEvent1(ticketNum);
            }

            // Show printable ticket
            if (res.appointment?.id) {
                openTicketModal(res.appointment.id);
            }

            // Reset slot selection & reload
            selectedSlotTime = null;
            loadTimeSlots();
            loadMyAppointments();
        }
    } catch (err) {
        showToast(err.message || "Navbat band qilishda xatolik yuz berdi", "error", "Xatolik");
    } finally {
        if (btn) {
            btn.disabled = false;
            updateBookButtonState();
        }
    }
}

// ─── 6. Ticket Modal & Printing ───────────────────────────────────────────────
async function openTicketModal(appointmentId) {
    try {
        const res = await apiCall(`/api/appointments/${appointmentId}/ticket`);
        const ticket = res.ticket;
        if (!ticket) return;

        const modal = document.getElementById("ticketModal");
        if (!modal) return;

        const setEl = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val || '—'; };
        setEl("ticketNumberDisplay", ticket.ticket_number);
        setEl("ticketDoctorDisplay", ticket.doctor_name);
        setEl("ticketSpecializationDisplay", ticket.doctor_specialization);
        setEl("ticketRoomDisplay", `${ticket.room_number}-XONA`);
        setEl("ticketDateDisplay", `${ticket.appointment_date} | ${ticket.start_time} - ${ticket.end_time}`);
        setEl("ticketPatientDisplay", ticket.patient_name);
        setEl("ticketPinflDisplay", `JShShIR: ${ticket.masked_pinfl || maskPINFL(ticket.patient_pinfl)}`);
        setEl("ticketDepartmentDisplay", ticket.department_name);

        const qrImg = document.getElementById("ticketQrImage");
        if (qrImg && ticket.ticket_number) {
            const qrData = encodeURIComponent(`${ticket.ticket_number}|${ticket.appointment_date}|${ticket.room_number}`);
            qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${qrData}`;
        }

        modal.classList.remove("hidden");
        modal.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } catch (err) {
        showToast("Talon ma'lumotlarini yuklab bo'lmadi: " + err.message, "error");
    }
}

function closeTicketModal() {
    const modal = document.getElementById("ticketModal");
    if (modal) modal.classList.add("hidden");
}

function printTicket() {
    window.print();
}

// 7. Load Patient's Appointments
async function loadMyAppointments() {
    const container = document.getElementById("myAppointmentsList");
    if (!container) return;

    // Show loading spinner immediately
    container.innerHTML = `
        <div class="p-8 text-center text-slate-400 text-xs flex items-center justify-center gap-2.5">
            <svg class="animate-spin h-5 w-5 text-blue-600 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
            </svg>
            <span class="font-semibold">Navbatlar yuklanmoqda...</span>
        </div>
    `;

    const token = localStorage.getItem("poliklinika_token");
    const activePinfl = (verifiedCitizen && verifiedCitizen.pinfl) || 
                        document.getElementById("patientPinflInput")?.value?.trim() || "";

    let res = null;
    try {
        if (token) {
            res = await apiCall("/api/patients/me");
        } else if (activePinfl && /^\d{14}$/.test(activePinfl)) {
            // Patient verified PINFL but not signed in
            res = await apiCall(`/api/patients/appointments-by-pinfl?pinfl=${activePinfl}`);
        } else {
            // Not logged in and no verified citizen yet
            container.innerHTML = `
                <div class="p-6 rounded-2xl bg-blue-50/60 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/40 text-center text-xs text-slate-600 dark:text-slate-300">
                    <div class="w-10 h-10 mx-auto mb-2 rounded-xl bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-400 flex items-center justify-center text-lg font-bold">📋</div>
                    <div class="font-bold text-sm text-slate-800 dark:text-slate-100 mb-1">Mening navbatlarim</div>
                    <p class="text-[11px] text-slate-500 dark:text-slate-400 mb-3">
                        Navbatlaringizni ko'rish uchun 1-qadamda JShShIR raqamingizni kiriting yoki tizimga kiring.
                    </p>
                    <button onclick="openAuthModal()" class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition">
                        Tizimga kirish →
                    </button>
                </div>
            `;
            return;
        }

        const upcoming = (res && res.upcoming_appointments) || [];
        const past = (res && res.past_appointments) || [];

        if (upcoming.length === 0 && past.length === 0) {
            container.innerHTML = `
                <div class="p-8 text-center text-slate-400 text-xs">
                    <div class="w-12 h-12 mx-auto mb-2 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center text-xl">📋</div>
                    <p class="font-bold text-slate-700 dark:text-slate-200">Faol navbatlar mavjud emas</p>
                    <p class="text-[11px] text-slate-400 mt-1">Sizda hozircha navbatlar yo'q. Yangi navbat olish uchun chap tomondagi formadan foydalaning.</p>
                </div>
            `;
            return;
        }

        let html = "";
        if (upcoming.length > 0) {
            html += `<h4 class="font-bold text-xs text-slate-700 dark:text-slate-300 mb-2.5 uppercase tracking-wider">Kelgusi navbatlar (${upcoming.length})</h4>`;
            html += upcoming.map(a => `
                <div class="p-4 rounded-2xl border border-emerald-200 dark:border-emerald-800/60 bg-emerald-50/50 dark:bg-emerald-950/20 mb-3 shadow-sm">
                    <div class="flex items-center justify-between mb-2">
                        <span class="px-3 py-1 rounded-xl bg-emerald-600 text-white font-black mono text-base tracking-wider shadow-sm">
                            ${a.ticket_number}
                        </span>
                        <span class="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-900/60 px-2 py-0.5 rounded-lg uppercase">
                            ${a.queue_status || 'Kutilmoqda'}
                        </span>
                    </div>
                    <div class="font-bold text-sm text-slate-800 dark:text-slate-100">${a.doctor_name}</div>
                    <div class="text-xs text-emerald-700 dark:text-emerald-400 font-semibold mt-0.5">${a.department_name} • ${a.room_number}-XONA</div>
                    <div class="text-xs text-slate-500 mt-1">📅 ${a.appointment_date} | ⏰ ${a.start_time} - ${a.end_time || ''}</div>
                    <div class="mt-3 pt-2.5 border-t border-emerald-200/60 dark:border-emerald-800/40 flex items-center justify-end gap-2">
                        <button onclick="openTicketModal(${a.id})" class="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                            Talonni ko'rish ↗
                        </button>
                        <button onclick="cancelAppointmentPrompt(${a.id})" class="px-3 py-1.5 rounded-lg bg-rose-50 text-rose-600 dark:bg-rose-950/50 dark:text-rose-400 text-xs font-bold hover:bg-rose-100 dark:hover:bg-rose-900 transition">
                            Bekor qilish
                        </button>
                    </div>
                </div>
            `).join('');
        }

        if (past.length > 0) {
            html += `<h4 class="font-bold text-xs text-slate-400 dark:text-slate-500 mt-5 mb-2 uppercase tracking-wider">Tarix (${past.length})</h4>`;
            html += past.map(a => `
                <div class="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 mb-2 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
                    <div>
                        <span class="font-bold mono text-slate-800 dark:text-slate-200 mr-2">${a.ticket_number || a.appointment_number}</span>
                        <span>${a.doctor_name}</span>
                        <div class="text-[10px] text-slate-400">${a.appointment_date}</div>
                    </div>
                    <div class="flex items-center gap-1.5">
                        <span class="px-2 py-0.5 rounded-md font-bold text-[10px] uppercase ${
                            a.status === 'completed' ? 'bg-slate-100 dark:bg-slate-800 text-slate-600' :
                            a.status === 'cancelled' ? 'bg-rose-100 dark:bg-rose-950 text-rose-600' : 'bg-slate-100 text-slate-500'
                        }">
                            ${a.status === 'completed' ? 'Tugallangan' : a.status === 'cancelled' ? 'Bekor qilingan' : a.status}
                        </span>
                        ${a.status === 'completed' ? `
                            <button onclick="openReviewModal(${a.doctor_id}, '${(a.doctor_name || '').replace(/'/g, "\\'")}', ${a.id})"
                                    class="px-2 py-0.5 rounded-md bg-amber-50 hover:bg-amber-100 text-amber-700 text-[10px] font-bold border border-amber-200">
                                ⭐ Sharh
                            </button>
                        ` : ''}
                    </div>
                </div>
            `).join('');
        }

        container.innerHTML = html;
    } catch (err) {
        container.innerHTML = `
            <div class="p-6 text-center text-xs bg-rose-50 dark:bg-rose-950/20 rounded-2xl border border-rose-200 dark:border-rose-800 text-rose-600 dark:text-rose-400">
                <div class="font-bold mb-1">Ma'lumotlarni yuklab bo'lmadi</div>
                <p class="text-[11px] mb-3">${err.message}</p>
                <button onclick="loadMyAppointments()" class="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition">
                    Qayta urinish ⟳
                </button>
            </div>
        `;
    }
}

// 8. Patient Tab Switcher
let currentPatientTab = "appointments";

function switchPatientTab(tabName) {
    currentPatientTab = tabName;
    const btns = ["appointments", "documents", "favorites"];
    btns.forEach(b => {
        const btn = document.getElementById(`patientTabBtn-${b}`);
        if (btn) {
            if (b === tabName) {
                btn.className = "flex-1 py-2 px-2.5 rounded-xl transition bg-blue-600 text-white shadow-sm flex items-center justify-center gap-1.5 whitespace-nowrap";
            } else {
                btn.className = "flex-1 py-2 px-2.5 rounded-xl transition text-slate-600 dark:text-slate-300 hover:text-slate-900 flex items-center justify-center gap-1.5 whitespace-nowrap";
            }
        }
    });

    const content = document.getElementById("patientTabContent");
    if (!content) return;

    if (tabName === "appointments") {
        content.innerHTML = `
            <div class="flex items-center justify-between mb-3">
                <h3 class="font-bold text-sm text-slate-800 dark:text-slate-100">Mening navbatlarim</h3>
                <button onclick="loadMyAppointments()" class="text-xs text-blue-600 dark:text-blue-400 font-bold hover:underline">Yangilash ⟳</button>
            </div>
            <div id="myAppointmentsList" class="space-y-3"></div>
        `;
        loadMyAppointments();
    } else if (tabName === "documents") {
        loadMyMedicalDocuments();
    } else if (tabName === "favorites") {
        loadMyFavoriteDoctors();
    }
}

// 9. Digital Medical Documents
async function loadMyMedicalDocuments() {
    const content = document.getElementById("patientTabContent");
    if (!content) return;

    const token = localStorage.getItem("poliklinika_token");
    if (!token) {
        content.innerHTML = `
            <div class="p-6 rounded-2xl bg-blue-50/60 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/40 text-center text-xs text-slate-600 dark:text-slate-300">
                <div class="w-10 h-10 mx-auto mb-2 rounded-xl bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-400 flex items-center justify-center text-lg font-bold">📄</div>
                <div class="font-bold text-sm text-slate-800 dark:text-slate-100 mb-1">Elektron Tibbiy Hujjatlar</div>
                <p class="text-[11px] text-slate-500 dark:text-slate-400 mb-3">
                    Shaxsiy tibbiy ma'lumotnomalar, tahlil natijalari va retseptlarni ko'rish uchun profilingizga kiring.
                </p>
                <button onclick="openAuthModal()" class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-sm transition">
                    Tizimga kirish →
                </button>
            </div>
        `;
        return;
    }

    content.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Hujjatlar yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/documents/my");
        const docs = res.documents || [];

        if (docs.length === 0) {
            content.innerHTML = `
                <div class="p-8 text-center text-slate-400 text-xs">
                    <div class="w-12 h-12 mx-auto mb-2 rounded-2xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 flex items-center justify-center text-xl">📄</div>
                    Hozircha rasmiylashtirilgan tibbiy hujjatlar mavjud emas. Shifokor ko'rigidan so'ng xulosalar shu yerda chiqadi.
                </div>
            `;
            return;
        }

        content.innerHTML = `
            <div class="flex items-center justify-between mb-3">
                <h3 class="font-bold text-sm text-slate-800 dark:text-slate-100">Elektron Tibbiy Hujjatlar (${docs.length})</h3>
                <button onclick="loadMyMedicalDocuments()" class="text-xs text-blue-600 dark:text-blue-400 font-bold hover:underline">Yangilash ⟳</button>
            </div>
            <div class="space-y-3">
                ${docs.map(d => `
                    <div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex items-center justify-between gap-3">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 flex items-center justify-center text-lg font-bold">
                                ${d.doc_type === 'lab_result' ? '🔬' : d.doc_type === 'prescription_rec' ? '💊' : '🩺'}
                            </div>
                            <div>
                                <div class="font-bold text-xs text-slate-800 dark:text-slate-100">${d.title}</div>
                                <div class="text-[11px] text-slate-500">${d.doctor_name || 'Shifokor'} • ${d.created_at ? d.created_at.slice(0, 10) : ''}</div>
                            </div>
                        </div>
                        <button onclick="openDocumentModal(${d.id})" class="px-3 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 text-blue-700 dark:text-blue-300 text-xs font-bold whitespace-nowrap">
                            Ko'rish ↗
                        </button>
                    </div>
                `).join('')}
            </div>
        `;
    } catch (err) {
        content.innerHTML = `<div class="p-4 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

async function openDocumentModal(docId) {
    try {
        const res = await apiCall(`/api/documents/${docId}`);
        const doc = res.document;
        if (!doc) return;

        document.getElementById("docModalTitle").textContent = doc.title;
        document.getElementById("docModalType").textContent = `${doc.doc_type.toUpperCase()} • ${doc.created_at.slice(0, 16)}`;

        let contentHtml = `
            <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 mb-3 space-y-1">
                <div><b>Bemor:</b> ${doc.patient_name} (JShShIR: ${doc.masked_pinfl || '***'})</div>
                <div><b>Shifokor:</b> ${doc.doctor_name || 'Navbatchi shifokor'} (${doc.doctor_specialization || ''})</div>
                <div><b>Xona:</b> ${doc.room_number || '-'}</div>
            </div>
        `;

        if (doc.content && typeof doc.content === 'object') {
            contentHtml += `<div class="space-y-2">`;
            for (const [k, v] of Object.entries(doc.content)) {
                contentHtml += `<div><span class="font-bold capitalize text-slate-600 dark:text-slate-400">${k}:</span> <span class="text-slate-800 dark:text-slate-200">${typeof v === 'object' ? JSON.stringify(v) : v}</span></div>`;
            }
            contentHtml += `</div>`;
        }

        if (doc.notes) {
            contentHtml += `<div class="mt-3 p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 text-amber-900 dark:text-amber-200 text-xs"><b>Qo'shimcha eslatma:</b> ${doc.notes}</div>`;
        }

        document.getElementById("docModalBody").innerHTML = contentHtml;
        document.getElementById("documentDetailModal").classList.remove("hidden");
    } catch (err) {
        showToast("Hujjatni yuklab bo'lmadi: " + err.message, "error");
    }
}

function closeDocumentModal() {
    const modal = document.getElementById("documentDetailModal");
    if (modal) modal.classList.add("hidden");
}

// 10. Favorite Doctors
async function loadMyFavoriteDoctors() {
    const content = document.getElementById("patientTabContent");
    if (!content) return;

    const token = localStorage.getItem("poliklinika_token");
    if (!token) {
        content.innerHTML = `
            <div class="p-6 rounded-2xl bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 text-center text-xs text-slate-600 dark:text-slate-300">
                <div class="w-10 h-10 mx-auto mb-2 rounded-xl bg-rose-100 dark:bg-rose-900/60 text-rose-600 dark:text-rose-400 flex items-center justify-center text-lg font-bold">❤️</div>
                <div class="font-bold text-sm text-slate-800 dark:text-slate-100 mb-1">Sevimli Shifokorlar</div>
                <p class="text-[11px] text-slate-500 dark:text-slate-400 mb-3">
                    O'zingizga ma'qul shifokorlarni saqlab qo'yish va tezkor navbat olish uchun tizimga kiring.
                </p>
                <button onclick="openAuthModal()" class="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-sm transition">
                    Tizimga kirish →
                </button>
            </div>
        `;
        return;
    }

    content.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Sevimli shifokorlar yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/favorites/my");
        const list = res.favorites || [];

        if (list.length === 0) {
            content.innerHTML = `
                <div class="p-8 text-center text-slate-400 text-xs">
                    <div class="w-12 h-12 mx-auto mb-2 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-500 flex items-center justify-center text-xl">❤️</div>
                    Hozircha sevimli shifokorlar belgilanmagan. Shifokor kartalaridagi yurakcha tugmasi orqali saqlab qo'yishingiz mumkin.
                </div>
            `;
            return;
        }

        content.innerHTML = `
            <div class="flex items-center justify-between mb-3">
                <h3 class="font-bold text-sm text-slate-800 dark:text-slate-100">Sevimli Shifokorlar (${list.length})</h3>
                <button onclick="loadMyFavoriteDoctors()" class="text-xs text-blue-600 dark:text-blue-400 font-bold hover:underline">Yangilash ⟳</button>
            </div>
            <div class="space-y-3">
                ${list.map(d => `
                    <div class="p-4 rounded-2xl border border-rose-100 dark:border-rose-950/60 bg-white dark:bg-slate-900 shadow-sm flex items-center justify-between gap-3">
                        <div class="flex items-center gap-3">
                            <div class="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-black text-sm flex items-center justify-center">
                                ${d.full_name.slice(3, 5).toUpperCase()}
                            </div>
                            <div>
                                <div class="font-bold text-xs text-slate-800 dark:text-slate-100">${d.full_name}</div>
                                <div class="text-[11px] text-slate-500">${d.specialization_uz} • ${d.room_number}-xona</div>
                            </div>
                        </div>
                        <div class="flex items-center gap-1.5">
                            <button onclick="openDoctorProfileModal(${d.id})" class="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs">
                                Profil
                            </button>
                            <button onclick="toggleFavoriteDoctor(${d.id})" class="p-1.5 text-rose-500 hover:text-rose-600 text-base" title="Sevimlilardan o'chirish">
                                ❤️
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    } catch (err) {
        content.innerHTML = `<div class="p-4 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

async function toggleFavoriteDoctor(doctorId) {
    try {
        const res = await apiCall(`/api/favorites/toggle/${doctorId}`, "POST", {});
        showToast(res.message, "success");
        if (currentPatientTab === "favorites") {
            loadMyFavoriteDoctors();
        }
    } catch (err) {
        showToast(err.message, "error");
    }
}

// 11. Doctor Reviews
function openReviewModal(doctorId, doctorName, appointmentId) {
    document.getElementById("reviewDoctorId").value = doctorId;
    document.getElementById("reviewAppointmentId").value = appointmentId || "";
    document.getElementById("reviewDoctorName").textContent = doctorName || "Shifokor";
    document.getElementById("reviewCommentInput").value = "";
    setReviewRating(5);
    document.getElementById("doctorReviewModal").classList.remove("hidden");
}

function closeReviewModal() {
    const modal = document.getElementById("doctorReviewModal");
    if (modal) modal.classList.add("hidden");
}

function setReviewRating(rating) {
    document.getElementById("reviewRatingValue").value = rating;
    const stars = document.querySelectorAll("#starRatingContainer .star-item");
    stars.forEach((s, idx) => {
        if (idx < rating) {
            s.className = "star-item text-amber-400";
        } else {
            s.className = "star-item text-slate-300 dark:text-slate-600";
        }
    });
}

async function submitDoctorReview() {
    const doctorId = parseInt(document.getElementById("reviewDoctorId").value);
    const apptId = document.getElementById("reviewAppointmentId").value;
    const rating = parseInt(document.getElementById("reviewRatingValue").value || "5");
    const comment = document.getElementById("reviewCommentInput").value.trim();

    try {
        const res = await apiCall("/api/reviews", "POST", {
            doctor_id: doctorId,
            appointment_id: apptId ? parseInt(apptId) : null,
            rating: rating,
            comment: comment || null
        });
        showToast(res.message, "success");
        closeReviewModal();
    } catch (err) {
        showToast(err.message, "error");
    }
}

// 12. Doctor Profile Modal
async function openDoctorProfileModal(doctorId) {
    const modal = document.getElementById("doctorProfileModal");
    const content = document.getElementById("doctorProfileContent");
    if (!modal || !content) return;

    modal.classList.remove("hidden");
    content.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Shifokor ma'lumotlari yuklanmoqda...</div>`;

    try {
        const [docRes, revRes] = await Promise.all([
            apiCall(`/api/doctors`),
            apiCall(`/api/reviews/doctor/${doctorId}`)
        ]);

        const doctor = (docRes.doctors || []).find(d => d.id === doctorId);
        if (!doctor) {
            content.innerHTML = `<div class="p-8 text-center text-rose-500 text-xs">Shifokor topilmadi</div>`;
            return;
        }

        const reviews = revRes.reviews || [];
        const avgRating = revRes.avg_rating || 5.0;
        const totalReviews = revRes.total_reviews || 0;

        content.innerHTML = `
            <div class="flex items-center gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div class="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-teal-500 text-white font-black text-2xl flex items-center justify-center shadow-md">
                    ${doctor.full_name.slice(3, 5).toUpperCase()}
                </div>
                <div>
                    <h3 class="text-base font-black text-slate-900 dark:text-white">${doctor.full_name}</h3>
                    <p class="text-xs text-blue-600 dark:text-blue-400 font-bold">${doctor.specialization_uz} • ${doctor.room_number}-XONA</p>
                    <div class="flex items-center gap-2 mt-1">
                        <span class="text-amber-400 font-bold text-sm">★ ${avgRating}</span>
                        <span class="text-xs text-slate-400">(${totalReviews} ta sharh)</span>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-3 text-xs">
                <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                    <span class="text-slate-400 block mb-0.5">Ish kunlari</span>
                    <span class="font-bold text-slate-700 dark:text-slate-200">Dushanba - Juma</span>
                </div>
                <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                    <span class="text-slate-400 block mb-0.5">Qabul soatlari</span>
                    <span class="font-bold text-slate-700 dark:text-slate-200">${doctor.start_time} - ${doctor.end_time}</span>
                </div>
            </div>

            <div class="pt-2">
                <h4 class="font-bold text-xs uppercase text-slate-400 mb-2">Bemorlar sharhlari (${reviews.length})</h4>
                <div class="max-h-48 overflow-y-auto space-y-2 pr-1">
                    ${reviews.length === 0 ? `<div class="p-4 text-center text-slate-400 text-xs">Hali sharhlar qoldirilmagan. Birinchi bo'lib fikr bildiring!</div>` : ''}
                    ${reviews.map(r => `
                        <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                            <div class="flex items-center justify-between mb-1">
                                <span class="font-bold text-xs text-slate-800 dark:text-slate-200">${r.patient_name}</span>
                                <span class="text-amber-400 text-xs font-bold">★ ${r.rating}</span>
                            </div>
                            <div class="text-xs text-slate-600 dark:text-slate-400">${r.comment || 'Izoh qoldirilmagan'}</div>
                        </div>
                    `).join('')}
                </div>
            </div>

            <div class="pt-4 flex gap-3">
                <button onclick="selectDoctorAndBook(${doctor.id}, ${doctor.department_id})" class="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow transition">
                    Ushbu shifokorga yozilish
                </button>
                <button onclick="toggleFavoriteDoctor(${doctor.id})" class="px-4 py-3 rounded-xl border border-rose-300 text-rose-500 font-bold text-xs hover:bg-rose-50">
                    ❤️ Sevimlilar
                </button>
            </div>
        `;
    } catch (err) {
        content.innerHTML = `<div class="p-4 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

function closeDoctorProfileModal() {
    const modal = document.getElementById("doctorProfileModal");
    if (modal) modal.classList.add("hidden");
}

function selectDoctorAndBook(doctorId, departmentId) {
    closeDoctorProfileModal();
    showSection('patient');
    if (departmentId) selectDepartment(departmentId);
    setTimeout(() => {
        selectDoctor(doctorId);
    }, 400);
}

async function cancelAppointmentPrompt(appointmentId) {
    const reason = prompt("Qabulni bekor qilish sababini kiriting:");
    if (!reason || reason.trim().length < 3) {
        showToast("Iltimos, bekor qilish sababini to'liq kiriting", "warning");
        return;
    }

    try {
        const res = await apiCall(`/api/appointments/${appointmentId}/cancel`, "POST", { reason });
        showToast(res.message, "success");
        loadMyAppointments();
    } catch (err) {
        showToast(err.message, "error");
    }
}
