# ELEKTRON NAVBAT — POLIKLINIKA TIZIMI (v2.0.0)

> O'zbekiston Respublikasi Ko'p Tarmoqli Markaziy Poliklinikalari uchun zamonaviy, xavfsiz va real-vaqtli elektron navbatni boshqarish axborot tizimi.

---

## 📋 MUNDARIJA
1. [Loyiha haqida](#loyiha-haqida)
2. [Asosiy imkoniyatlar va funksiyalar](#asosiy-imkoniyatlar-va-funksiyalar)
3. [Arxitektura va texnologiyalar](#arxitektura-va-texnologiyalar)
4. [Tibbiyot mutaxassislari (10 ta yo'nalish)](#tibbiyot-mutaxassislari-10-ta-yonalish)
5. [Ma'lumotlar bazasi modellari](#malumotlar-bazasi-modellari)
6. [Demo hisoblar (Kirish ma'lumotlari)](#demo-hisoblar-kirish-malumotlari)
7. [O'rnatish va ishga tushirish](#ornatish-va-ishga-tushirish)
8. [API Hujjatlari (Endpoints)](#api-hujjatlari-endpoints)
9. [Avtomatlashtirilgan testlar](#avtomatlashtirilgan-testlar)
10. [Xavfsizlik va maxfiylik](#xavfsizlik-va-maxfiylik)

---

## 🏥 1. LOYIHA HAQIDA

Mazkur tizim poliklinikalarda tirbandlikni oldini olish, shifokorlar ish vaqtini to'g'ri rejalashtirish, fuqarolarga qulay onlayn qabul va navbat talonlarini berish hamda poliklinika kutish zallaridagi katta TV monitorlarda real-vaqt rejimida (WebSockets) ovozli xabarlar bilan navbatni e'lon qilib borish uchun ishlab chiqilgan.

Loyiha oddiy statik demo emas — to'liq backend (FastAPI, SQLite WAL, WebSockets, JWT, Bcrypt) va zamonaviy responsive frontend (Tailwind CSS, Dark/Light mode, i18n: O'zbekcha / Русский / English) arxitekturasiga ega.

---

## ⚡ 2. ASOSIY IMKONIYATLAR VA FUNKSIYALAR

### 1. Zamonaviy Tibbiy UI/UX
- Tibbiy texnologiyalarga xos ko'k, oq va och kulrang palitra.
- To'liq responsive dizayn (Mobil telefonlar, planshetlar, noutbuklar va katta TV ekranlar).
- **Dark mode** (qorong'u mavzu) va **Light mode** (yorug' mavzu) o'rtasida bir bosishda almashish.
- **Ko'p tillilik (i18n)**: Standart holda O'zbek tili (`uz`), shuningdek Rus tili (`ru`) va Ingliz tili (`en`).
- Smooth animatsiyalar, tibbiy ikonalar va zamonaviy kartalar.

### 2. Bemor Portali va Shaxsni Tasdiqlash
- Bemor ro'yxatdan o'tishi va tizimga xavfsiz kirishi.
- **14 xonali JShShIR (PINFL)** formatini qat'iy tekshirish va tasdiqlash.
- O'zbekiston Davlat Xizmatlari API integratsiyasi shlyuzi (demo rejimda Aliyev Anvar, Karimova Dilnoza, Sobirov Jasur kabi sinov fuqarolari bilan ishlaydi).
- Shaxsiy profilni tahrirlash va ko'rish.

### 3. Onlayn Navbat Olish (Booking Wizard)
- 4 bosqichli qabul yozilishi:
  1. Shaxsni JShShIR orqali tasdiqlash.
  2. 10 ta tibbiyot bo'limidan birini tanlash.
  3. Mutaxassis shifokorni tanlash (rasmi, xonasi, qabul davomiyligi bilan).
  4. Qabul kuni va bo'sh vaqt oralig'ini tanlash.
- **Bir bemorning bitta shifokorga bir kunda takroriy faol navbat olishi qat'iy bloklanadi** (Duplicate active booking prevention).
- **Bitta vaqt oralig'iga ikki bemor yozilishi oldi olingan** (Atomic double-booking prevention).
- Shifokorning ish vaqti (08:30 - 17:30) va tushlik tanaffusidan (13:00 - 14:00) tashqarida navbat olinmaydi.
- Unikal navbat taloni beriladi (masalan: `TR-001`, `KD-002`, `NV-003`).
- **Talonni chop etish** (`window.print()`) va yuklab olish imkoniyati.
- Qabulni bekor qilish siyosati (o'tib ketgan navbat bekor qilinmaydi, sabab ko'rsatiladi).
- "Mening navbatlarim": kelgusi va o'tgan qabullar ro'yxati.

### 4. Jonli Navbat Monitori (TV Display & Real-Time Audio)
- Poliklinika kutish zallaridagi katta TV monitorlar uchun to'liq ekranli maxsus rejim (`Fullscreen TV Mode`).
- **WebSockets** texnologiyasi asosida sahifani yangilamasdan real-vaqtda yangilanadi.
- Hozir chaqirilayotgan talon raqami, xonasi, shifokor ismi yirik yuqori kontrastli shriftlar bilan namoyish etiladi.
- Navbatdagi bemorlar ro'yxati va taxminiy kutish vaqti avtomatik hisoblanadi.
- **Ovozli e'lonlar**:
  - Web Audio API yordamida yoqimli poliklinika gong/qo'ng'irog'i (523Hz -> 659Hz -> 784Hz).
  - Web SpeechSynthesis ovozli chaqiruvi: *"Diqqat! Talon TR-001, 101-xonaga marhamat!"*
  - Ovozni yoqish / o'chirish (Mute) tugmasi.

### 5. Shifokor Kabineti (Doctor Dashboard)
- Shifokor o'z login-paroli bilan kiradi va faqat o'ziga biriktirilgan xona va bemorlarni ko'radi (**Doctor Data Isolation**).
- "Keyingi bemorni chaqirish" tugmasi bir bosishda ekranda chaqiruvni boshlaydi va TV monitorga signal beradi.
- "Qabulni yakunlash" — shifokor tashxis va tibbiy xulosa yozib navbatni yakunlaydi.
- "Bemor kelmadi" — kelmagan bemor holatini belgilash.

### 6. Administrator Boshqaruv Markazi
- 4 ta asosiy KPI ko'rsatkichlari: Jami bemorlar, bugungi navbatlar, faol shifokorlar, o'rtacha kutish vaqti.
- **Navbatni boshqarish**: barcha xonalardagi chaqiruvlarni nazorat qilish, kunlik navbatni tozalash (demo reset).
- **Shifokorlar boshqaruvi (CRUD)**: yangi shifokor qo'shish, tahrirlash, faollashtirish/nofaol qilish.
- **Barcha qabullar**: F.I.Sh, telefon, JShShIR va talon bo'yicha tezkor qidiruv, sana, shifokor, bo'lim va holat bo'yicha filtrlar.
- **Tahlil va hisobotlar**: Haftalik qabullar dinamikasi grafiklari, talab yuqori bo'lgan shifokorlar reytingi.
- **Eksport**: Barcha ma'lumotlarni **Excel / CSV** formatida yuklab olish.
- **SMS Shlyuzi**: Halol va shaffof SMS monitoringi (hozirda simulyatsiya qilingan demo rejimda, real Eskiz.uz yoki PlayMobile API kalitlarini ulash imkoniyati bilan).
- **Audit va Xavfsizlik**: Tizimdagi har bir muhim amal foydalanuvchi, IP manzil va vaqti bilan yozib boriladi.

---

## 🛠️ 3. ARXITEKTURA VA TEXNOLOGIYALAR

```
d:\alitexno\
├── backend/
│   ├── app.py                  # FastAPI ilovasi, middleware va WebSockets
│   ├── config.py               # Sozlamalar, JWT parametrlari, yo'llar
│   ├── database.py             # SQLite WAL bazasi, jadvallar va indekslar
│   ├── models.py               # Pydantic validatsiya sxemalari
│   ├── auth.py                 # Bcrypt shifrlash, JWT va rollar tekshiruvi
│   ├── seed_data.py            # Boshlang'ich poliklinika ma'lumotlari
│   ├── websocket_manager.py    # Real-vaqtli WebSocket mijozlar dispetcheri
│   └── routes/                 # Modulli API marshrutlari
│       ├── auth_routes.py
│       ├── department_routes.py
│       ├── doctor_routes.py
│       ├── patient_routes.py
│       ├── appointment_routes.py
│       ├── queue_routes.py
│       ├── analytics_routes.py
│       ├── notification_routes.py
│       └── audit_routes.py
├── static/
│   ├── css/style.css           # Tibbiy mavzu, animatsiyalar va print uslublari
│   └── js/
│       ├── i18n.js             # UZ / RU / EN tarjimalar lug'ati
│       ├── api.js              # Fetch mijozi va Toast bildirishnomalar
│       ├── live_queue.js       # TV monitor, WebSockets va audio sintez
│       ├── patient_portal.js   # Qabul band qilish va talon generatori
│       ├── doctor_dashboard.js # Shifokor qabuli va xulosalar
│       ├── admin_dashboard.js  # Boshqaruv, statistika va eksport
│       └── app.js              # Asosiy router, navigatsiya va tema
├── templates/
│   └── index.html              # Zamonaviy SPA shabloni (Tailwind CSS)
├── tests/
│   └── test_system.py          # Barcha 16 ta talab bo'yicha avtomat testlar
├── run.py                      # Serverni bir buyruq bilan ishga tushirish
├── requirements.txt            # Python kutubxonalari
└── .env.example                # Konfiguratsiya namunasi
```

---

## 👨‍⚕️ 4. TIBBIYOT MUTAXASSISLARI (10 TA YO'NALISH)

Tizimda talab qilingan barcha 10 ta asosiy shifokor profillari va ularning kabinetlari mavjud:

| № | Bo'lim | Mutaxassis shifokor | Xona | Ish vaqti | Qabul |
|---|---|---|---|---|---|
| 1 | **Terapiya** (TR) | Dr. Rustamov Jamshid Olimovich | **101** | 08:30 - 17:30 | 20 daq |
| 2 | **Kardiologiya** (KD) | Dr. Umarova Nodira Botirovna | **102** | 09:00 - 17:00 | 20 daq |
| 3 | **Nevrologiya** (NV) | Dr. Qosimov Bobur Faxriddinovich | **103** | 08:30 - 16:30 | 20 daq |
| 4 | **Pediatriya** (PD) | Dr. Ismoilova Feruza Mansurovna | **104** | 09:00 - 16:00 | 20 daq |
| 5 | **Jarrohlik** (JR) | Dr. Saidov Sardor Akramovich | **105** | 08:30 - 17:00 | 20 daq |
| 6 | **Oftalmologiya** (OF) | Dr. Mahmudova Gulnora Anvarovna | **106** | 09:00 - 16:30 | 20 daq |
| 7 | **Stomatologiya** (ST) | Dr. Nazarov Ulug'bek Komilovich | **107** | 09:00 - 18:00 | 30 daq |
| 8 | **Ginekologiya** (GN) | Dr. Alimova Malika Shavkatovna | **108** | 08:30 - 16:00 | 20 daq |
| 9 | **Endokrinologiya** (EN) | Dr. Zokirov Eldor Baxtiyorovich | **109** | 09:00 - 17:00 | 20 daq |
| 10 | **Dermatologiya** (DR) | Dr. Xolmatova Nilufar Erkinovna | **110** | 08:30 - 16:30 | 20 daq |

---

## 🗄️ 5. MA'LUMOTLAR BAZASI MODELLARI

Ma'lumotlar bazasi SQLite WAL (Write-Ahead Logging) rejimida ishlaydi:
- `users`: id, email, phone, password_hash, role (`admin`, `doctor`, `patient`), full_name, is_active.
- `departments`: id, name_uz, name_ru, name_en, code, description_uz, icon.
- `doctors`: id, user_id, department_id, full_name, specialization_uz, room_number, appointment_duration, working_days, start_time, end_time, is_active.
- `patients`: id, user_id, pinfl (14 xonali unikal), full_name, birth_date, gender, phone, address, is_verified.
- `doctor_schedules`: id, doctor_id, day_of_week, start_time, end_time, slot_duration, max_patients_per_slot.
- `appointments`: id, appointment_number, patient_id, doctor_id, department_id, appointment_date, start_time, end_time, status, reason, notes.
- `queue_tickets`: id, appointment_id, ticket_number, queue_date, priority_number, status, called_at, served_at, room_number.
- `notifications`: id, user_id, title, message, type, channel, delivery_status, is_read.
- `audit_logs`: id, user_id, action, entity_type, entity_id, ip_address, details, created_at.

---

## 🔑 6. DEMO HISOBLAR (KIRISH MA'LUMOTLARI)

Tizimda barcha asosiy rollar uchun sinov hisoblari mavjud. Kirish oynasida "Tezkor Demo hisoblar" tugmachalari orqali bir bosishda to'ldirish mumkin:

### 1. Bosh Administrator
- **Login:** `admin@poliklinika.uz`
- **Parol:** `Admin123!`
- **Huquq:** To'liq ma'muriy boshqaruv, shifokorlar qo'shish, hisobotlar eksporti, navbatni tozalash.

### 2. Shifokorlar (Namuna)
- **Terapevt (101-xona):** `dr.rustamov@poliklinika.uz` / `Doctor123!`
- **Kardiolog (102-xona):** `dr.umarova@poliklinika.uz` / `Doctor123!`
- **Nevrolog (103-xona):** `dr.qosimov@poliklinika.uz` / `Doctor123!`
- **Pediatr (104-xona):** `dr.ismoilova@poliklinika.uz` / `Doctor123!`

### 3. Bemorlar (Asl namunadan saqlangan demo ma'lumotlar)
- **Bemor 1 (Aliyev Anvar Anvarovich):**
  - JShShIR (PINFL): `12345678901234` | Parol: `Patient123!` | Tug'ilgan sana: 12.04.1985
- **Bemor 2 (Karimova Dilnoza Baxtiyorovna):**
  - JShShIR (PINFL): `11112222333344` | Parol: `Patient123!` | Tug'ilgan sana: 23.08.1992
- **Bemor 3 (Sobirov Jasur Otabekovich):**
  - JShShIR (PINFL): `33334444555566` | Parol: `Patient123!` | Tug'ilgan sana: 05.11.1998

---

## 🚀 7. O'RNATISH VA ISHGA TUSHIRISH

### Talablar
- Python 3.10 yoki undan yuqori (tizimda Python 3.13 mavjud)
- Zamonaviy brauzer (Chrome, Edge, Firefox, Opera, Safari)

### 1-qadam: Kutubxonalarni o'rnatish
```powershell
pip install -r requirements.txt
```

### 2-qadam: Tizimni ishga tushirish
```powershell
python run.py
```
yoki:
```powershell
python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000 --reload
```

### 3-qadam: Brauzerda ochish
- **Asosiy ilova:** [http://127.0.0.1:8000](http://127.0.0.1:8000)
- **Interaktiv API Hujjatlari (Swagger):** [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
- **Muqobil API Hujjatlari (ReDoc):** [http://127.0.0.1:8000/redoc](http://127.0.0.1:8000/redoc)

---

## 📡 8. API HUJJATLARI (ENDPOINTS)

### Autentifikatsiya:
- `POST /api/auth/login` — Foydalanuvchi kirishi (Email, telefon yoki 14 xonali PINFL bilan)
- `POST /api/auth/register-patient` — Yangi bemorni ro'yxatdan o'tkazish
- `GET /api/auth/me` — Joriy foydalanuvchi ma'lumotlari
- `POST /api/auth/change-password` — Parolni o'zgartirish

### Bemorlar:
- `POST /api/patients/verify-pinfl` — 14 xonali JShShIRni tekshirish
- `GET /api/patients/me` — Bemorning profili va faol/tarixiy navbatlari
- `GET /api/patients` — Bemorlar ro'yxati (shifokor va admin uchun)

### Shifokorlar va Bo'limlar:
- `GET /api/departments` — Bo'limlar va shifokorlar soni
- `GET /api/doctors` — Shifokorlar ro'yxati (filtrlar bilan)
- `GET /api/doctors/{id}/available-slots?target_date=YYYY-MM-DD` — Shifokorning bo'sh vaqt slotlari
- `GET /api/doctors/my/dashboard` — Shifokorning shaxsiy kabineti va bugungi navbatlari
- `POST /api/doctors` — Yangi shifokor qo'shish (Admin)
- `PUT /api/doctors/{id}` — Shifokor ma'lumotlarini yangilash (Admin)

### Navbat va Qabul:
- `POST /api/appointments/book` — Navbat band qilish va talon olish
- `GET /api/appointments/{id}/ticket` — Talon ma'lumotlari (chop etish va yuklab olish uchun)
- `POST /api/appointments/{id}/cancel` — Navbatni bekor qilish
- `GET /api/appointments` — Barcha navbatlar ro'yxati va filtrlash
- `GET /api/queue/live` — Jonli navbat ma'lumotlari (TV monitor uchun)
- `POST /api/queue/call-next` — Keyingi bemorni chaqirish (Audio va WebSocket triggeri)
- `POST /api/queue/complete/{id}` — Qabulni yakunlash va tashxis yozish
- `POST /api/queue/absent/{id}` — Bemor kelmadi deb belgilash
- `POST /api/queue/reset-day` — Kunlik demo navbatlarni tozalash

### Tahlil va Hisobotlar:
- `GET /api/analytics/dashboard` — Boshqaruv statistikasi va grafiklar
- `GET /api/analytics/export/csv` — Qabullar hisobotini Excel/CSV fayl sifatida yuklab olish
- `GET /api/notifications/sms-status` — SMS shlyuzi holati va jurnali
- `GET /api/audit-logs` — Xavfsizlik jurnali

---

## 🧪 9. AVTOMATLASHTIRILGAN TESTLAR

Tizimda 11 ta to'liq integratsion test moduli yozilgan. Ular avtorizatsiya, 14 xonali PINFL tekshiruvi, takroriy navbatni oldini olish, xona va shifokorlar xavfsizligini tekshiradi.

Testlarni ishga tushirish uchun:
```powershell
python -m unittest tests/test_system.py
```
Natija:
```
...........
----------------------------------------------------------------------
Ran 11 tests in 2.900s

OK
```

---

## 🔒 10. XAVFSIZLIK VA MAXFIYLIK

1. **Parollar xavfsizligi**: Barcha parollar `bcrypt` (12 rounds) orqali xeshlanadi, bazada ochiq parol saqlanmaydi.
2. **PINFL va Maxfiylik**: Bemorning JShShIR raqami ommaviy interfeyslarda niqoblanadi (`123456******34`), frontend kodida ochiq ma'lumotlar saqlanmaydi.
3. **Rollar izolatsiyasi**: Shifokor faqat o'ziga tegishli bemorlarni ko'radi va chaqiradi, boshqa shifokorning navbatini o'zgartira olmaydi.
4. **SQL Injection himoyasi**: Barcha SQL so'rovlar parametrlashtirilgan (`?` placeholder) va validatsiya qilingan.
5. **XSS va Header himoyasi**: `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `X-XSS-Protection: 1; mode=block`.
6. **Audit Jurnali**: Har bir tizimga kirish, qabul band qilish, chaqirish va o'zgartirish foydalanuvchi IDsi va IP manzili bilan qayd etiladi.
