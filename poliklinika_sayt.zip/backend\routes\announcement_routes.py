from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional
from backend.database import fetch_all, insert, execute
from backend.auth import require_admin, log_audit

router = APIRouter(prefix="/api/announcements", tags=["Clinic Announcements"])

class AnnouncementCreateRequest(BaseModel):
    title: str
    content: str
    priority: str = "normal"  # 'normal', 'high', 'urgent'
    target_role: str = "all"

@router.get("")
async def get_announcements():
    announcements = fetch_all("""
        SELECT * FROM clinic_announcements 
        WHERE is_active = 1 
        ORDER BY id DESC LIMIT 20
    """)
    return {"announcements": announcements}

@router.post("", dependencies=[Depends(require_admin)])
async def create_announcement(req: AnnouncementCreateRequest, current_user: dict = Depends(require_admin)):
    ann_id = insert("""
        INSERT INTO clinic_announcements (title, content, priority, target_role, is_active)
        VALUES (?, ?, ?, ?, 1)
    """, (req.title, req.content, req.priority, req.target_role))

    log_audit(current_user["id"], "CREATE_ANNOUNCEMENT", "clinic_announcements", str(ann_id))
    return {"message": "E'lon muvaffaqiyatli chop etildi", "id": ann_id}

@router.delete("/{announcement_id}", dependencies=[Depends(require_admin)])
async def delete_announcement(announcement_id: int, current_user: dict = Depends(require_admin)):
    execute("UPDATE clinic_announcements SET is_active = 0 WHERE id = ?", (announcement_id,))
    log_audit(current_user["id"], "DELETE_ANNOUNCEMENT", "clinic_announcements", str(announcement_id))
    return {"message": "E'lon o'chirildi"}
