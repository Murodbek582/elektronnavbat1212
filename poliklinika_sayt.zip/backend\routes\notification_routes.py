from fastapi import APIRouter, HTTPException, Depends
from backend.database import fetch_all, fetch_one, execute, insert
from backend.auth import get_current_user, require_admin
from backend.models import SMSGatewayConfigRequest
from typing import Optional

router = APIRouter(prefix="/api/notifications", tags=["Notifications & SMS"])

@router.get("/my")
async def get_my_notifications(current_user: dict = Depends(get_current_user)):
    notifications = fetch_all("""
        SELECT * FROM notifications 
        WHERE user_id = ? 
        ORDER BY id DESC LIMIT 30
    """, (current_user["id"],))
    
    unread_count = fetch_one("""
        SELECT COUNT(id) as count FROM notifications 
        WHERE user_id = ? AND is_read = 0
    """, (current_user["id"],))["count"]
    
    return {
        "notifications": notifications,
        "unread_count": unread_count
    }

@router.post("/mark-read/{notification_id}")
async def mark_notification_read(notification_id: int, current_user: dict = Depends(get_current_user)):
    execute("""
        UPDATE notifications SET is_read = 1 
        WHERE id = ? AND user_id = ?
    """, (notification_id, current_user["id"]))
    return {"message": "O'qilgan deb belgilandi"}

@router.post("/mark-all-read")
async def mark_all_notifications_read(current_user: dict = Depends(get_current_user)):
    execute("""
        UPDATE notifications SET is_read = 1 
        WHERE user_id = ?
    """, (current_user["id"],))
    return {"message": "Barcha xabarlar o'qildi"}

# Honest SMS Gateway Management
@router.get("/sms-status", dependencies=[Depends(require_admin)])
async def get_sms_gateway_status():
    provider_setting = fetch_one("SELECT value FROM system_settings WHERE key = 'sms_gateway_provider'")
    provider = provider_setting["value"] if provider_setting else "demo"
    
    # Recent SMS messages
    recent_sms = fetch_all("""
        SELECT n.id, n.title, n.message, n.delivery_status, n.created_at, u.phone as recipient_phone, u.full_name
        FROM notifications n
        JOIN users u ON n.user_id = u.id
        WHERE n.channel = 'sms'
        ORDER BY n.id DESC LIMIT 20
    """)
    
    return {
        "active_provider": provider,
        "is_demo_mode": provider == "demo",
        "description": "Hozirda tizim DEMO simulyatsiya rejimida ishlamoqda. Haqiqiy SMS yuborilmaydi, lekin barcha xabarlar simulyatsiya qilinib tizimda qayd etiladi.",
        "supported_gateways": ["demo", "eskiz.uz", "playmobile.uz"],
        "recent_sms_logs": recent_sms
    }

@router.post("/sms-config", dependencies=[Depends(require_admin)])
async def update_sms_config(req: SMSGatewayConfigRequest):
    execute("""
        INSERT OR REPLACE INTO system_settings (key, value, description)
        VALUES ('sms_gateway_provider', ?, 'SMS Provider')
    """, (req.provider,))
    
    if req.api_key:
        execute("""
            INSERT OR REPLACE INTO system_settings (key, value, description)
            VALUES ('sms_api_key', ?, 'SMS API Key')
        """, (req.api_key,))
        
    return {
        "message": "SMS shlyuz sozlamalari saqlandi",
        "provider": req.provider,
        "is_demo": req.provider == "demo"
    }
