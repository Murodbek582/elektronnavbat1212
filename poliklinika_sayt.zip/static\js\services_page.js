/**
 * services_page.js
 * Clinic Services (Xizmatlar) page for Elektron Navbat polyclinic project.
 * Vanilla JS, no external dependencies.
 */

// ─── State ────────────────────────────────────────────────────────────────────
let _allServices = [];
let _activeDept  = 'Barchasi';

// ─── Department meta (icon + badge colour) ────────────────────────────────────
const DEPT_META = {
    'Terapiya':        { icon: '🩺', color: 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300' },
    'Kardiologiya':    { icon: '🫀', color: 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300' },
    'Nevrologiya':     { icon: '🧠', color: 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300' },
    'Pediatriya':      { icon: '👶', color: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300' },
    'Jarrohlik':       { icon: '🔪', color: 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300' },
    "Ko'z kasalliklari": { icon: '👁', color: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-300' },
    'Tish shifokori':  { icon: '🦷', color: 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300' },
    'Ginekologiya':    { icon: '🌸', color: 'bg-pink-100 text-pink-700 dark:bg-pink-900 dark:text-pink-300' },
    'Endokrinologiya': { icon: '⚗️', color: 'bg-teal-100 text-teal-700 dark:bg-teal-900 dark:text-teal-300' },
    'Dermatologiya':   { icon: '🧴', color: 'bg-lime-100 text-lime-700 dark:bg-lime-900 dark:text-lime-300' },
    'Laboratoriya':    { icon: '🩸', color: 'bg-rose-100 text-rose-700 dark:bg-rose-900 dark:text-rose-300' },
    'Diagnostika':     { icon: '📡', color: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300' },
};

const DEPARTMENTS = [
    'Barchasi', 'Terapiya', 'Kardiologiya', 'Nevrologiya', 'Pediatriya',
    'Jarrohlik', "Ko'z kasalliklari", 'Tish shifokori', 'Ginekologiya',
    'Endokrinologiya', 'Dermatologiya',
];

// ─── Static fallback data ─────────────────────────────────────────────────────
const STATIC_SERVICES = [
    {
        id: 1, department_id: 1, department: 'Terapiya',
        name: 'Umumiy maslahat',
        description: 'Tajribali terapevt shifokor bilan umumiy tibbiy maslahat. Kasallik tarixi, belgilari va davolash rejasini muhokama qilish.',
        duration: 30, price: 50000,
        available_doctors: ['Dr. Aliyev Bobur', 'Dr. Karimova Nilufar'],
        working_hours: 'Dush–Jum: 08:00–18:00, Shan: 09:00–14:00',
    },
    {
        id: 2, department_id: 10, department: 'Laboratoriya',
        name: 'Qon tahlili',
        description: "To'liq qon tahlili (KLA). Gemoglobin, leykositlar, trombositlar va boshqa ko'rsatkichlar tekshiriladi.",
        duration: 15, price: 35000,
        available_doctors: ['Lab. Yusupov Sherzod'],
        working_hours: 'Dush–Shan: 07:30–13:00',
    },
    {
        id: 3, department_id: 11, department: 'Diagnostika',
        name: 'Ultratovush (UST)',
        description: "Qorin bo'shlig'i organlarini ultratovush usuli bilan tekshirish. Jigar, o't pufagi, buyraklar va boshqalar.",
        duration: 25, price: 80000,
        available_doctors: ['Dr. Nazarov Doniyor'],
        working_hours: 'Dush–Jum: 09:00–17:00',
    },
    {
        id: 4, department_id: 2, department: 'Kardiologiya',
        name: 'EKG (Elektrokardiografiya)',
        description: "Yurak faoliyatini elektrokardiografiya yordamida tekshirish. Aritmiya, miokard infarkti va boshqa yurak kasalliklarini aniqlash.",
        duration: 20, price: 45000,
        available_doctors: ['Dr. Rahimov Jasur', 'Dr. Sobirov Kamol'],
        working_hours: 'Dush–Jum: 08:00–17:00',
    },
    {
        id: 5, department_id: 7, department: 'Tish shifokori',
        name: 'Tish shifokori xizmati',
        description: "Tishlarni davolash, oq qoplama tozalash, tish kovagi va milklar kasalliklarini davolash. Zamonaviy uskunalar bilan ishlash.",
        duration: 45, price: 120000,
        available_doctors: ['Dr. Ergasheva Mohira', 'Dr. Toshmatov Ulugbek'],
        working_hours: 'Dush–Shan: 09:00–18:00',
    },
    {
        id: 6, department_id: 4, department: 'Pediatriya',
        name: 'Pediatrik maslahat',
        description: "Bolalar shifokori bilan bolalar salomatligi bo'yicha maslahat. Emlash jadvali, rivojlanish monitoring va kasalliklarni davolash.",
        duration: 30, price: 55000,
        available_doctors: ["Dr. Xolmatova Zulfiya", 'Dr. Mirzayev Firdavs'],
        working_hours: 'Dush–Jum: 08:00–18:00, Shan: 09:00–13:00',
    },
    {
        id: 7, department_id: 2, department: 'Kardiologiya',
        name: 'Kardiologiya maslahat',
        description: "Yurak-qon tomir kasalliklari bo'yicha mutaxassis kardiolог bilan maslahat. EKG va eхokardiografiya natijalarini tahlil qilish.",
        duration: 40, price: 90000,
        available_doctors: ['Dr. Rahimov Jasur'],
        working_hours: 'Dush–Jum: 09:00–16:00',
    },
    {
        id: 8, department_id: 3, department: 'Nevrologiya',
        name: 'Nevrologiya maslahat',
        description: "Nerv tizimi kasalliklari (bosh og'riq, migren, insult, epilepsiya) bo'yicha nevropatolog bilan maslahat va tekshiruv.",
        duration: 35, price: 85000,
        available_doctors: ['Dr. Abdullayeva Sarvinoz'],
        working_hours: 'Dush–Jum: 09:00–17:00',
    },
    {
        id: 9, department_id: 6, department: "Ko'z kasalliklari",
        name: "Ko'z tekshiruvi",
        description: "Ko'rish keskinligini tekshirish, ko'z tubi ko'rigini o'tkazish, ko'zoynak retsepti berish va ko'z kasalliklarini aniqlash.",
        duration: 30, price: 70000,
        available_doctors: ["Dr. Qodirov Nurbek", "Dr. Hasanova Feruza"],
        working_hours: "Dush–Shan: 09:00–17:00",
    },
    {
        id: 10, department_id: 8, department: 'Ginekologiya',
        name: 'Ginekologiya maslahati',
        description: "Ayollar salomatligi bo'yicha ginekolog bilan maslahat. Profilaktik ko'rik, ultratovush, smear tahlili va davolash.",
        duration: 35, price: 95000,
        available_doctors: ["Dr. Mirzayeva Gulnora", "Dr. Nazarova Kamola"],
        working_hours: "Dush–Jum: 09:00–17:00, Shan: 09:00–13:00",
    },
    {
        id: 11, department_id: 1, department: 'Terapiya',
        name: "Profilaktik ko'rik",
        description: "Yillik profilaktik tibbiy ko'rik. Asosiy organlar va tizimlar tekshiriladi, davolash tavsiyalari beriladi.",
        duration: 60, price: 0,
        available_doctors: ['Dr. Aliyev Bobur', 'Dr. Karimova Nilufar', 'Dr. Yusupov Timur'],
        working_hours: "Dush–Jum: 08:00–17:00",
    },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatPrice(price) {
    if (!price || price === 0) return "Narx belgilanmagan";
    return new Intl.NumberFormat('uz-UZ').format(price) + " so'm";
}

function getDeptMeta(department) {
    return DEPT_META[department] || { icon: '🏥', color: 'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300' };
}

function escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

// ─── Price formatting ─────────────────────────────────────────────────────────

function renderServiceCard(service) {
    const meta       = getDeptMeta(service.department);
    const priceStr   = formatPrice(service.price);
    const isPaid     = service.price > 0;
    const deptSafe   = escapeHtml(service.department);
    const nameSafe   = escapeHtml(service.name);
    const descSafe   = escapeHtml(service.description);

    return `
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow duration-200 flex flex-col overflow-hidden services-card" data-dept="${deptSafe}" data-id="${service.id}">
  <!-- Card header with icon -->
  <div class="bg-gradient-to-br from-blue-50 to-teal-50 dark:from-slate-700 dark:to-slate-600 p-5 flex items-center gap-3">
    <span class="text-4xl select-none" aria-hidden="true">${meta.icon}</span>
    <div class="flex-1 min-w-0">
      <h3 class="font-bold text-slate-800 dark:text-white text-base leading-tight truncate">${nameSafe}</h3>
      <span class="inline-block mt-1 px-2 py-0.5 rounded-full text-xs font-medium ${meta.color}">${deptSafe}</span>
    </div>
  </div>

  <!-- Card body -->
  <div class="flex-1 p-5 flex flex-col gap-3">
    <!-- Description -->
    <p class="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">${descSafe}</p>

    <!-- Badges row -->
    <div class="flex flex-wrap gap-2">
      <!-- Duration -->
      <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-700 text-xs text-slate-600 dark:text-slate-300">
        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        ${service.duration || 30} daqiqa
      </span>
      <!-- Price -->
      <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${isPaid ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300' : 'bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-400'}">
        ${isPaid ? '💰' : '—'} ${escapeHtml(priceStr)}
      </span>
    </div>
  </div>

  <!-- Card footer buttons -->
  <div class="px-5 pb-5 flex gap-2">
    <button
      onclick="openServiceBooking(${service.id}, ${service.department_id})"
      class="flex-1 bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600 text-white text-sm font-semibold rounded-xl py-2.5 px-3 transition-all duration-200 shadow-sm hover:shadow-md active:scale-95"
    >
      📅 Navbat olish
    </button>
    <button
      onclick="openServiceDetail(${service.id})"
      class="px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 text-sm font-medium transition-colors duration-200"
      title="Batafsil"
    >
      ℹ️
    </button>
  </div>
</div>`;
}

// ─── Filter chips ─────────────────────────────────────────────────────────────

function renderFilterChips() {
    return DEPARTMENTS.map(dept => {
        const isActive = dept === _activeDept;
        const cls = isActive
            ? 'bg-blue-600 text-white shadow-md'
            : 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600';
        return `<button
      onclick="filterServicesByDept('${escapeHtml(dept)}')"
      class="whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${cls} dept-chip"
      data-dept="${escapeHtml(dept)}"
    >${escapeHtml(dept)}</button>`;
    }).join('');
}

// ─── Grid renderer ────────────────────────────────────────────────────────────

function renderServicesGrid(services) {
    const grid = document.getElementById('services-grid');
    if (!grid) return;

    if (!services || services.length === 0) {
        grid.innerHTML = `
      <div class="col-span-full flex flex-col items-center justify-center py-20 text-slate-400 dark:text-slate-500">
        <span class="text-6xl mb-4">🔍</span>
        <p class="text-lg font-medium">Xizmatlar topilmadi</p>
        <p class="text-sm mt-1">Boshqa bo'lim tanlang</p>
      </div>`;
        return;
    }

    grid.innerHTML = services.map(renderServiceCard).join('');
}

// ─── Filter function ──────────────────────────────────────────────────────────

function filterServicesByDept(deptName) {
    _activeDept = deptName;

    // Update chip styles
    document.querySelectorAll('.dept-chip').forEach(btn => {
        const isActive = btn.dataset.dept === deptName;
        btn.className = btn.className
            .replace(/bg-blue-600 text-white shadow-md|bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600/g, '')
            .trim();
        btn.className += isActive
            ? ' bg-blue-600 text-white shadow-md'
            : ' bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600';
    });

    const filtered = deptName === 'Barchasi'
        ? _allServices
        : _allServices.filter(s => s.department === deptName);

    renderServicesGrid(filtered);
}

// ─── Booking bridge ───────────────────────────────────────────────────────────

function openServiceBooking(serviceId, departmentId) {
    // Switch to patient/booking section
    if (typeof showSection === 'function') {
        showSection('patient');
    }

    // Pre-select department in booking wizard
    setTimeout(() => {
        const deptSelect = document.getElementById('booking-department') || document.getElementById('department-select');
        if (deptSelect) {
            deptSelect.value = departmentId;
            deptSelect.dispatchEvent(new Event('change', { bubbles: true }));
        }

        // Store context for booking wizard
        window._pendingBooking = { serviceId, departmentId };

        // Dispatch custom event so app.js can react
        document.dispatchEvent(new CustomEvent('service:book', {
            detail: { serviceId, departmentId },
            bubbles: true,
        }));
    }, 300);
}

// ─── Detail Modal ─────────────────────────────────────────────────────────────

function openServiceDetail(serviceId) {
    const service = _allServices.find(s => s.id === serviceId);
    if (!service) return;

    const meta     = getDeptMeta(service.department);
    const priceStr = formatPrice(service.price);
    const isPaid   = service.price > 0;

    const doctorsList = (service.available_doctors || [])
        .map(d => `<li class="flex items-center gap-2 py-1.5 border-b border-slate-100 dark:border-slate-700 last:border-0">
        <span class="text-blue-500">👨‍⚕️</span>
        <span class="text-sm text-slate-700 dark:text-slate-200">${escapeHtml(d)}</span>
      </li>`)
        .join('') || '<li class="text-sm text-slate-400">Ma\'lumot mavjud emas</li>';

    const modal = document.getElementById('service-detail-modal');
    const body  = document.getElementById('service-detail-body');

    if (!modal || !body) return;

    body.innerHTML = `
  <div class="flex items-start gap-4 mb-6">
    <span class="text-5xl">${meta.icon}</span>
    <div>
      <h2 class="text-xl font-bold text-slate-800 dark:text-white">${escapeHtml(service.name)}</h2>
      <span class="inline-block mt-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${meta.color}">${escapeHtml(service.department)}</span>
    </div>
  </div>

  <!-- Description -->
  <div class="mb-5">
    <h3 class="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide mb-2">Tavsif</h3>
    <p class="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">${escapeHtml(service.description)}</p>
  </div>

  <!-- Info pills -->
  <div class="flex flex-wrap gap-3 mb-5">
    <div class="flex items-center gap-2 bg-slate-50 dark:bg-slate-700 rounded-xl px-4 py-2">
      <svg class="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
      </svg>
      <span class="text-sm font-medium text-slate-700 dark:text-slate-200">${service.duration || 30} daqiqa</span>
    </div>
    <div class="flex items-center gap-2 rounded-xl px-4 py-2 ${isPaid ? 'bg-emerald-50 dark:bg-emerald-900' : 'bg-slate-50 dark:bg-slate-700'}">
      <span>${isPaid ? '💰' : '—'}</span>
      <span class="text-sm font-semibold ${isPaid ? 'text-emerald-700 dark:text-emerald-300' : 'text-slate-500'}">${escapeHtml(priceStr)}</span>
    </div>
  </div>

  <!-- Working hours -->
  ${service.working_hours ? `
  <div class="mb-5">
    <h3 class="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide mb-2">Ish vaqti</h3>
    <p class="text-sm text-slate-700 dark:text-slate-300 flex items-center gap-2">
      <span>🕐</span> ${escapeHtml(service.working_hours)}
    </p>
  </div>` : ''}

  <!-- Available doctors -->
  <div class="mb-6">
    <h3 class="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wide mb-2">Mavjud shifokorlar</h3>
    <ul class="divide-y divide-slate-100 dark:divide-slate-700">${doctorsList}</ul>
  </div>

  <!-- CTA -->
  <button
    onclick="closeServiceDetailModal(); openServiceBooking(${service.id}, ${service.department_id})"
    class="w-full bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600 text-white font-semibold rounded-xl py-3 transition-all duration-200 shadow-md hover:shadow-lg active:scale-95"
  >
    📅 Navbat olish
  </button>`;

    modal.classList.remove('hidden');
    modal.classList.add('flex');
    document.body.style.overflow = 'hidden';
}

function closeServiceDetailModal() {
    const modal = document.getElementById('service-detail-modal');
    if (!modal) return;
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    document.body.style.overflow = '';
}

// ─── Full page HTML injector ──────────────────────────────────────────────────

function injectServicesPageHTML() {
    const container = document.getElementById('section-services');
    if (!container) return;

    container.innerHTML = `
  <!-- Hero Banner -->
  <div class="bg-gradient-to-r from-blue-600 via-blue-500 to-teal-500 rounded-2xl p-8 mb-6 text-white shadow-lg relative overflow-hidden">
    <div class="absolute inset-0 opacity-10" style="background-image: radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px); background-size: 60px 60px;"></div>
    <div class="relative z-10">
      <div class="flex items-center gap-3 mb-2">
        <span class="text-4xl">🏥</span>
        <h1 class="text-3xl font-bold tracking-tight">Tibbiy Xizmatlar</h1>
      </div>
      <p class="text-blue-100 text-lg mt-1">Professional tibbiy xizmatlar va tashxis</p>
      <div class="mt-4 flex flex-wrap gap-3">
        <div class="bg-white/20 backdrop-blur-sm rounded-xl px-4 py-2 text-sm font-medium">✅ Sertifikatlangan shifokorlar</div>
        <div class="bg-white/20 backdrop-blur-sm rounded-xl px-4 py-2 text-sm font-medium">⚡ Tez navbat</div>
        <div class="bg-white/20 backdrop-blur-sm rounded-xl px-4 py-2 text-sm font-medium">🔬 Zamonaviy uskunalar</div>
      </div>
    </div>
  </div>

  <!-- Loading indicator -->
  <div id="services-loading" class="flex justify-center items-center py-12 hidden">
    <div class="flex items-center gap-3 text-blue-600 dark:text-blue-400">
      <svg class="animate-spin w-6 h-6" fill="none" viewBox="0 0 24 24">
        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
      </svg>
      <span class="font-medium">Xizmatlar yuklanmoqda…</span>
    </div>
  </div>

  <!-- Error banner -->
  <div id="services-error" class="hidden mb-4 bg-amber-50 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-700 rounded-xl p-4 flex items-center gap-3">
    <span class="text-amber-500 text-xl">⚠️</span>
    <div>
      <p class="text-sm font-semibold text-amber-700 dark:text-amber-300">Server bilan ulanishda muammo</p>
      <p class="text-xs text-amber-600 dark:text-amber-400 mt-0.5">Namunali ma'lumotlar ko'rsatilmoqda</p>
    </div>
  </div>

  <!-- Department filter chips -->
  <div class="mb-6">
    <div class="flex gap-2 overflow-x-auto pb-2 scrollbar-hide" id="dept-filter-row">
      ${renderFilterChips()}
    </div>
  </div>

  <!-- Services count -->
  <div class="flex items-center justify-between mb-4">
    <p class="text-sm text-slate-500 dark:text-slate-400" id="services-count"></p>
  </div>

  <!-- Services grid -->
  <div
    id="services-grid"
    class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-8"
  ></div>

  <!-- Service Detail Modal -->
  <div
    id="service-detail-modal"
    class="hidden fixed inset-0 z-50 items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
    onclick="if(event.target===this) closeServiceDetailModal()"
  >
    <div class="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
      <!-- Modal header -->
      <div class="sticky top-0 bg-white dark:bg-slate-800 flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-700 rounded-t-2xl z-10">
        <span class="font-bold text-slate-800 dark:text-white">Xizmat tafsilotlari</span>
        <button onclick="closeServiceDetailModal()" class="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-500 dark:text-slate-400 transition-colors text-lg font-bold">×</button>
      </div>
      <!-- Modal body -->
      <div class="p-6" id="service-detail-body"></div>
    </div>
  </div>
  `;
}

// ─── Load page from API ───────────────────────────────────────────────────────

async function loadServicesPage() {
    injectServicesPageHTML();

    const loadingEl = document.getElementById('services-loading');
    const errorEl   = document.getElementById('services-error');
    const countEl   = document.getElementById('services-count');

    if (loadingEl) loadingEl.classList.remove('hidden');

    let services = [];
    let usedFallback = false;

    try {
        const response = await fetch('/api/services', {
            headers: { 'Accept': 'application/json' },
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const data = await response.json();

        // Handle both array response and {data: [...]} envelope
        services = Array.isArray(data) ? data : (data.data || data.services || []);

        if (!services.length) throw new Error('Empty response');

    } catch (err) {
        console.warn('[ServicesPage] API error, using static fallback:', err.message);
        services     = STATIC_SERVICES;
        usedFallback = true;
    } finally {
        if (loadingEl) loadingEl.classList.add('hidden');
    }

    _allServices = services;
    _activeDept  = 'Barchasi';

    if (usedFallback && errorEl) {
        errorEl.classList.remove('hidden');
    }

    if (countEl) {
        countEl.textContent = `${_allServices.length} ta xizmat mavjud`;
    }

    renderServicesGrid(_allServices);
}

// ─── Public init ──────────────────────────────────────────────────────────────

async function initServicesSection() {
    await loadServicesPage();
}
