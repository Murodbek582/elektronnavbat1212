from fastapi import APIRouter, HTTPException, status, Depends
from backend.models import DepartmentCreateRequest
from backend.database import fetch_all, fetch_one, insert, execute
from backend.auth import require_admin, log_audit
from typing import Optional

router = APIRouter(prefix="/api/departments", tags=["Departments"])

@router.get("")
async def get_departments():
    query = """
        SELECT d.*, COUNT(doc.id) as doctor_count
        FROM departments d
        LEFT JOIN doctors doc ON d.id = doc.department_id AND doc.is_active = 1
        GROUP BY d.id
        ORDER BY d.id ASC
    """
    departments = fetch_all(query)
    return {"departments": departments}

@router.get("/{dept_id}")
async def get_department(dept_id: int):
    department = fetch_one("SELECT * FROM departments WHERE id = ?", (dept_id,))
    if not department:
        raise HTTPException(status_code=404, detail="Bo'lim topilmadi")
    
    doctors = fetch_all("""
        SELECT id, full_name, specialization_uz, room_number, photo_url, is_active
        FROM doctors 
        WHERE department_id = ? AND is_active = 1
    """, (dept_id,))
    
    return {"department": department, "doctors": doctors}

@router.post("", dependencies=[Depends(require_admin)])
async def create_department(req: DepartmentCreateRequest, current_user: dict = Depends(require_admin)):
    existing = fetch_one("SELECT id FROM departments WHERE code = ?", (req.code.upper(),))
    if existing:
        raise HTTPException(status_code=400, detail="Ushbu kodli bo'lim allaqachon mavjud")
        
    dept_id = insert("""
        INSERT INTO departments (name_uz, name_ru, name_en, code, description_uz, description_ru, description_en, icon)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (req.name_uz, req.name_ru, req.name_en, req.code.upper(), req.description_uz, req.description_ru, req.description_en, req.icon))
    
    log_audit(current_user["id"], "CREATE_DEPARTMENT", "departments", str(dept_id), details=f"Created department {req.name_uz}")
    return {"message": "Bo'lim muvaffaqiyatli yaratildi", "department_id": dept_id}

@router.put("/{dept_id}", dependencies=[Depends(require_admin)])
async def update_department(dept_id: int, req: DepartmentCreateRequest, current_user: dict = Depends(require_admin)):
    dept = fetch_one("SELECT id FROM departments WHERE id = ?", (dept_id,))
    if not dept:
        raise HTTPException(status_code=404, detail="Bo'lim topilmadi")
        
    execute("""
        UPDATE departments SET
            name_uz = ?, name_ru = ?, name_en = ?, code = ?,
            description_uz = ?, description_ru = ?, description_en = ?, icon = ?
        WHERE id = ?
    """, (req.name_uz, req.name_ru, req.name_en, req.code.upper(), req.description_uz, req.description_ru, req.description_en, req.icon, dept_id))
    
    log_audit(current_user["id"], "UPDATE_DEPARTMENT", "departments", str(dept_id))
    return {"message": "Bo'lim muvaffaqiyatli tahrirlandi"}

@router.delete("/{dept_id}", dependencies=[Depends(require_admin)])
async def delete_department(dept_id: int, current_user: dict = Depends(require_admin)):
    # Check if doctors exist
    has_doctors = fetch_one("SELECT id FROM doctors WHERE department_id = ?", (dept_id,))
    if has_doctors:
        raise HTTPException(status_code=400, detail="Ushbu bo'limda shifokorlar mavjud bo'lgani sababli o'chirib bo'lmaydi")
        
    execute("DELETE FROM departments WHERE id = ?", (dept_id,))
    log_audit(current_user["id"], "DELETE_DEPARTMENT", "departments", str(dept_id))
    return {"message": "Bo'lim o'chirildi"}
