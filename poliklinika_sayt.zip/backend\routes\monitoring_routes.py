import os
import shutil
from pathlib import Path
from datetime import datetime, date
from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import FileResponse
from backend.auth import require_admin, log_audit
from backend.database import fetch_all, fetch_one
from backend.config import DATABASE_URL, BACKUP_DIR
from backend.ai_engine import diagnose_system_health

router = APIRouter(prefix="/api/monitoring", tags=["AI Website Monitoring & Backups"])

@router.get("/health", dependencies=[Depends(require_admin)])
async def get_system_health():
    return diagnose_system_health()

@router.get("/incidents", dependencies=[Depends(require_admin)])
async def get_system_incidents():
    # Fetch recent audit actions that indicate potential issues or errors
    incidents = fetch_all("""
        SELECT * FROM audit_logs 
        WHERE action IN ('CANCEL_APPOINTMENT', 'MARK_ABSENT', 'LOGIN_FAILED', 'RESET_DAILY_QUEUE')
        ORDER BY id DESC LIMIT 25
    """)
    return {"incidents": incidents}

@router.post("/create-backup", dependencies=[Depends(require_admin)])
async def create_database_backup(current_user: dict = Depends(require_admin)):
    db_path = Path(DATABASE_URL)
    if not db_path.exists():
        raise HTTPException(status_code=404, detail="Ma'lumotlar bazasi fayli topilmadi")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_filename = f"polyclinic_backup_{timestamp}.db"
    destination = BACKUP_DIR / backup_filename

    try:
        shutil.copy2(db_path, destination)
        log_audit(current_user["id"], "CREATE_BACKUP", "backups", backup_filename)
        return {
            "success": True,
            "message": f"Zaxira nusxasi muvaffaqiyatli yaratildi: {backup_filename}",
            "filename": backup_filename,
            "size_kb": round(destination.stat().st_size / 1024, 2)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Zaxira nusxasi yaratishda xatolik: {e}")

@router.get("/backups", dependencies=[Depends(require_admin)])
async def list_database_backups():
    backups = []
    if BACKUP_DIR.exists():
        for file in sorted(BACKUP_DIR.glob("*.db"), key=os.path.getmtime, reverse=True):
            backups.append({
                "filename": file.name,
                "size_kb": round(file.stat().st_size / 1024, 2),
                "created_at": datetime.fromtimestamp(file.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")
            })
    return {"backups": backups}

@router.get("/download-backup/{filename}", dependencies=[Depends(require_admin)])
async def download_backup_file(filename: str):
    file_path = BACKUP_DIR / filename
    if not file_path.exists() or not filename.endswith(".db"):
        raise HTTPException(status_code=404, detail="Zaxira nusxa fayli topilmadi")
    return FileResponse(file_path, filename=filename, media_type="application/octet-stream")

@router.get("/financial-stats", dependencies=[Depends(require_admin)])
async def get_financial_statistics():
    today = str(date.today())

    # Total completed appointments revenue simulation
    total_completed = fetch_one("""
        SELECT COUNT(id) as count FROM appointments WHERE status = 'completed'
    """)["count"]

    today_completed = fetch_one("""
        SELECT COUNT(id) as count FROM appointments WHERE appointment_date = ? AND status = 'completed'
    """, (today,))["count"]

    # Average consultation standard fee: 50,000 UZS
    std_fee = 50000
    total_rev = total_completed * std_fee
    today_rev = today_completed * std_fee

    # Breakdown by services
    services_list = fetch_all("""
        SELECT s.name_uz, s.price, dep.name_uz as dept_name,
               (SELECT COUNT(id) FROM appointments WHERE department_id = s.department_id AND status = 'completed') as total_served
        FROM services s
        JOIN departments dep ON s.department_id = dep.id
        WHERE s.is_active = 1
        ORDER BY s.price DESC
    """)

    return {
        "summary": {
            "total_revenue_uzs": total_rev,
            "today_revenue_uzs": today_rev,
            "total_consultations": total_completed,
            "today_consultations": today_completed,
            "average_ticket_uzs": std_fee
        },
        "services": services_list
    }
