from fastapi import APIRouter, HTTPException, status, Depends, Request
from backend.models import CallQueueRequest, CompleteAppointmentRequest
from backend.database import fetch_all, fetch_one, execute, get_db
from backend.auth import require_doctor_or_admin, require_admin, get_current_user, log_audit
from backend.websocket_manager import manager
from datetime import datetime, date
from typing import Optional

router = APIRouter(prefix="/api/queue", tags=["Live Queue"])

@router.get("/live")
async def get_live_queue(date_str: Optional[str] = None):
    today = date_str or str(date.today())
    
    # 1. Currently called patients (status: 'calling' or 'serving')
    active_calls = fetch_all("""
        SELECT qt.id as ticket_id, qt.ticket_number, qt.status as queue_status, qt.called_at, qt.room_number,
               d.id as doctor_id, d.full_name as doctor_name, d.specialization_uz as doctor_specialization,
               dep.name_uz as department_name, dep.code as department_code,
               p.full_name as patient_name,
               a.id as appointment_id, a.start_time
        FROM queue_tickets qt
        JOIN appointments a ON qt.appointment_id = a.id
        JOIN doctors d ON a.doctor_id = d.id
        JOIN departments dep ON a.department_id = dep.id
        JOIN patients p ON a.patient_id = p.id
        WHERE qt.queue_date = ? AND qt.status IN ('calling', 'serving')
        ORDER BY qt.called_at DESC
    """, (today,))
    
    # 2. Next waiting patients
    waiting_tickets = fetch_all("""
        SELECT qt.id as ticket_id, qt.ticket_number, qt.status as queue_status, qt.room_number, qt.priority_number,
               d.id as doctor_id, d.full_name as doctor_name, d.specialization_uz as doctor_specialization,
               dep.name_uz as department_name, dep.code as department_code,
               p.full_name as patient_name,
               a.id as appointment_id, a.start_time
        FROM queue_tickets qt
        JOIN appointments a ON qt.appointment_id = a.id
        JOIN doctors d ON a.doctor_id = d.id
        JOIN departments dep ON a.department_id = dep.id
        JOIN patients p ON a.patient_id = p.id
        WHERE qt.queue_date = ? AND qt.status = 'waiting'
        ORDER BY a.start_time ASC, qt.priority_number ASC
        LIMIT 15
    """, (today,))
    
    # 3. Overall queue summary for today
    summary_row = fetch_one("""
        SELECT 
            COUNT(id) as total_today,
            SUM(CASE WHEN status = 'waiting' THEN 1 ELSE 0 END) as waiting_count,
            SUM(CASE WHEN status IN ('calling', 'serving') THEN 1 ELSE 0 END) as in_progress_count,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_count,
            SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent_count,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_count
        FROM queue_tickets
        WHERE queue_date = ?
    """, (today,))
    
    # Calculate estimated average wait time (e.g. waiting count * 15 min / active doctors)
    active_doctors = fetch_one("""
        SELECT COUNT(DISTINCT a.doctor_id) as count 
        FROM appointments a 
        WHERE a.appointment_date = ? AND a.status IN ('waiting', 'in_consultation')
    """, (today,))
    doc_count = active_doctors["count"] if active_doctors and active_doctors["count"] > 0 else 1
    waiting_num = summary_row["waiting_count"] or 0
    estimated_wait_minutes = round((waiting_num * 18) / max(1, doc_count))
    
    return {
        "date": today,
        "current_time": datetime.now().strftime("%H:%M:%S"),
        "active_calls": active_calls,
        "waiting_tickets": waiting_tickets,
        "stats": {
            "total_today": summary_row["total_today"] or 0,
            "waiting": waiting_num,
            "in_progress": summary_row["in_progress_count"] or 0,
            "completed": summary_row["completed_count"] or 0,
            "absent": summary_row["absent_count"] or 0,
            "cancelled": summary_row["cancelled_count"] or 0,
            "estimated_wait_minutes": estimated_wait_minutes
        }
    }

@router.post("/call-next")
async def call_next_patient(req: CallQueueRequest, request: Request, current_user: dict = Depends(require_doctor_or_admin)):
    today_str = str(date.today())
    
    # Determine doctor_id
    doctor_id = req.doctor_id
    if current_user["role"] == "doctor":
        doc = fetch_one("SELECT id, room_number, full_name, specialization_uz FROM doctors WHERE user_id = ?", (current_user["id"],))
        if not doc:
            raise HTTPException(status_code=404, detail="Shifokor profili topilmadi")
        doctor_id = doc["id"]
        doctor_room = doc["room_number"]
        doctor_name = doc["full_name"]
        specialization = doc["specialization_uz"]
    else:
        # Admin must provide doctor_id or calls general next
        if not doctor_id:
            # Pick first doctor with waiting patients
            first_waiting = fetch_one("""
                SELECT a.doctor_id 
                FROM appointments a
                JOIN queue_tickets qt ON a.id = qt.appointment_id
                WHERE qt.queue_date = ? AND qt.status = 'waiting'
                ORDER BY a.start_time ASC, qt.priority_number ASC
                LIMIT 1
            """, (today_str,))
            if not first_waiting:
                raise HTTPException(status_code=404, detail="Hozirda kutilayotgan bemorlar mavjud emas")
            doctor_id = first_waiting["doctor_id"]
            
        doc = fetch_one("SELECT room_number, full_name, specialization_uz FROM doctors WHERE id = ?", (doctor_id,))
        doctor_room = doc["room_number"]
        doctor_name = doc["full_name"]
        specialization = doc["specialization_uz"]

    # If this doctor already has an actively called ticket, mark it as serving
    execute("""
        UPDATE queue_tickets SET status = 'serving'
        WHERE appointment_id IN (
            SELECT id FROM appointments WHERE doctor_id = ? AND appointment_date = ?
        ) AND status = 'calling'
    """, (doctor_id, today_str))

    # Find the next waiting patient for this doctor
    next_ticket = fetch_one("""
        SELECT qt.id as ticket_id, qt.ticket_number, qt.appointment_id,
               p.id as patient_id, p.full_name as patient_name, p.user_id as patient_user_id,
               a.start_time
        FROM queue_tickets qt
        JOIN appointments a ON qt.appointment_id = a.id
        JOIN patients p ON a.patient_id = p.id
        WHERE a.doctor_id = ? AND qt.queue_date = ? AND qt.status = 'waiting'
        ORDER BY a.start_time ASC, qt.priority_number ASC
        LIMIT 1
    """, (doctor_id, today_str))

    if not next_ticket:
        raise HTTPException(
            status_code=404,
            detail=f"{doctor_name} qabulida kutilayotgan navbat topilmadi."
        )

    now_iso = datetime.now().isoformat()
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE queue_tickets 
            SET status = 'calling', called_at = ?, room_number = ?
            WHERE id = ?
        """, (now_iso, doctor_room, next_ticket["ticket_id"]))
        
        cursor.execute("""
            UPDATE appointments
            SET status = 'in_consultation', updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (next_ticket["appointment_id"],))

        # Add in-app notification to patient
        if next_ticket["patient_user_id"]:
            cursor.execute("""
                INSERT INTO notifications (user_id, title, message, type, channel, delivery_status)
                VALUES (?, 'Navbatingiz chaqirilmoqda!', ?, 'queue_call', 'in_app', 'delivered')
            """, (
                next_ticket["patient_user_id"],
                f"Hurmatli {next_ticket['patient_name']}! Talon: {next_ticket['ticket_number']}. Marhamat, {doctor_room}-xonaga kiring ({doctor_name})."
            ))

    client_ip = request.client.host if request.client else "unknown"
    log_audit(current_user["id"], "CALL_PATIENT", "queue_tickets", str(next_ticket["ticket_id"]), client_ip,
              f"Called {next_ticket['ticket_number']} to room {doctor_room}")

    # Broadcast WebSocket Event
    broadcast_payload = {
        "event": "PATIENT_CALLED",
        "ticket": {
            "ticket_number": next_ticket["ticket_number"],
            "patient_name": next_ticket["patient_name"],
            "doctor_name": doctor_name,
            "doctor_specialization": specialization,
            "room_number": doctor_room,
            "appointment_id": next_ticket["appointment_id"],
            "called_at": now_iso
        }
    }
    await manager.broadcast(broadcast_payload)

    return {
        "success": True,
        "message": f"Navbat chaqirildi: {next_ticket['ticket_number']}",
        "called": {
            "ticket_number": next_ticket["ticket_number"],
            "patient_name": next_ticket["patient_name"],
            "doctor_name": doctor_name,
            "room_number": doctor_room,
            "appointment_id": next_ticket["appointment_id"]
        }
    }

@router.post("/complete/{appointment_id}")
async def complete_appointment(appointment_id: int, req: CompleteAppointmentRequest, current_user: dict = Depends(require_doctor_or_admin)):
    appt = fetch_one("SELECT * FROM appointments WHERE id = ?", (appointment_id,))
    if not appt:
        raise HTTPException(status_code=404, detail="Qabul topilmadi")
        
    # Doctor isolation
    if current_user["role"] == "doctor":
        doc = fetch_one("SELECT id FROM doctors WHERE user_id = ?", (current_user["id"],))
        if doc and appt["doctor_id"] != doc["id"]:
            raise HTTPException(status_code=403, detail="Siz boshqa shifokorning qabulini yakunlay olmaysiz")

    notes_text = f"Tashxis/Xulosa: {req.diagnosis or 'Umumiy ko''rik yakunlandi'}. {req.notes or ''}"
    now_iso = datetime.now().isoformat()
    
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE appointments SET status = 'completed', notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                       (notes_text, appointment_id))
        cursor.execute("UPDATE queue_tickets SET status = 'completed', served_at = ? WHERE appointment_id = ?",
                       (now_iso, appointment_id))

    log_audit(current_user["id"], "COMPLETE_APPOINTMENT", "appointments", str(appointment_id))
    
    await manager.broadcast({
        "event": "PATIENT_COMPLETED",
        "appointment_id": appointment_id
    })

    return {"message": "Qabul muvaffaqiyatli yakunlandi"}

@router.post("/absent/{appointment_id}")
async def mark_absent(appointment_id: int, current_user: dict = Depends(require_doctor_or_admin)):
    appt = fetch_one("SELECT * FROM appointments WHERE id = ?", (appointment_id,))
    if not appt:
        raise HTTPException(status_code=404, detail="Qabul topilmadi")
        
    if current_user["role"] == "doctor":
        doc = fetch_one("SELECT id FROM doctors WHERE user_id = ?", (current_user["id"],))
        if doc and appt["doctor_id"] != doc["id"]:
            raise HTTPException(status_code=403, detail="Siz boshqa shifokorning navbatini o'zgartira olmaysiz")

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE appointments SET status = 'absent', updated_at = CURRENT_TIMESTAMP WHERE id = ?", (appointment_id,))
        cursor.execute("UPDATE queue_tickets SET status = 'absent' WHERE appointment_id = ?", (appointment_id,))

    log_audit(current_user["id"], "MARK_ABSENT", "appointments", str(appointment_id))

    await manager.broadcast({
        "event": "PATIENT_ABSENT",
        "appointment_id": appointment_id
    })

    return {"message": "Bemor kelmadi deb belgilandi"}

@router.post("/reset-day", dependencies=[Depends(require_admin)])
async def reset_daily_demo_queues(current_user: dict = Depends(require_admin)):
    today_str = str(date.today())
    
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM queue_tickets WHERE queue_date = ?", (today_str,))
        cursor.execute("UPDATE appointments SET status = 'cancelled', notes = 'Kunlik navbat tozalash (Demo Reset)' WHERE appointment_date = ?", (today_str,))

    log_audit(current_user["id"], "RESET_DAILY_QUEUE", "queue_tickets", today_str, details="Reset daily queue")

    await manager.broadcast({
        "event": "QUEUE_RESET",
        "message": "Kunlik navbat tozalangan"
    })

    return {"message": f"{today_str} sanasidagi barcha navbatlar muvaffaqiyatli tozalandi"}
