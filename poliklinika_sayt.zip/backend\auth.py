import bcrypt
import jwt
from datetime import datetime, timedelta, timezone
from typing import Optional
from fastapi import HTTPException, status, Depends, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from backend.config import SECRET_KEY, ALGORITHM, ACCESS_TOKEN_EXPIRE_MINUTES
from backend.database import fetch_one, insert

security = HTTPBearer(auto_error=False)

def hash_password(password: str) -> str:
    """Hashes password with bcrypt and work factor 12"""
    salt = bcrypt.gensalt(rounds=12)
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifies plain password against hashed password"""
    try:
        return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))
    except Exception:
        return False

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire, "iat": datetime.now(timezone.utc)})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def decode_access_token(token: str) -> Optional[dict]:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.PyJWTError:
        return None

async def get_current_user(credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)) -> dict:
    if not credentials or not credentials.credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Tizimga kirish talab etiladi (Avtorizatsiya tokeni topilmadi)",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    payload = decode_access_token(credentials.credentials)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token yaroqsiz yoki muddati tugagan. Qayta kiring.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    user_id = payload.get("sub")
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Foydalanuvchi ma'lumotlari topilmadi",
        )
        
    user = fetch_one("SELECT id, email, phone, role, full_name, is_active FROM users WHERE id = ?", (user_id,))
    if not user or not user["is_active"]:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Foydalanuvchi hisobi faol emas yoki o'chirilgan",
        )
        
    # Attach doctor or patient profile id if applicable
    if user["role"] == "doctor":
        doc = fetch_one("SELECT id, department_id, room_number, specialization_uz FROM doctors WHERE user_id = ?", (user["id"],))
        if doc:
            user["doctor_id"] = doc["id"]
            user["department_id"] = doc["department_id"]
            user["room_number"] = doc["room_number"]
            user["specialization_uz"] = doc["specialization_uz"]
    elif user["role"] == "patient":
        pat = fetch_one("SELECT id, pinfl, birth_date, gender, blood_group, is_verified FROM patients WHERE user_id = ?", (user["id"],))
        if pat:
            user["patient_id"] = pat["id"]
            user["pinfl"] = pat["pinfl"]
            user["birth_date"] = pat["birth_date"]
            user["is_verified"] = pat["is_verified"]

    return user

async def get_optional_user(credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)) -> Optional[dict]:
    if not credentials or not credentials.credentials:
        return None
    try:
        return await get_current_user(credentials)
    except HTTPException:
        return None

def require_role(allowed_roles: list[str]):
    async def role_checker(current_user: dict = Depends(get_current_user)):
        if current_user["role"] not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Sizda ushbu amalni bajarish uchun ruxsat yo'q. Talab qilinadigan rol: {', '.join(allowed_roles)}",
            )
        return current_user
    return role_checker

require_admin = require_role(["admin"])
require_doctor = require_role(["doctor"])
require_doctor_or_admin = require_role(["doctor", "admin"])
require_patient = require_role(["patient"])

def log_audit(user_id: Optional[int], action: str, entity_type: str, entity_id: Optional[str] = None, ip_address: Optional[str] = None, details: Optional[str] = None):
    try:
        insert(
            "INSERT INTO audit_logs (user_id, action, entity_type, entity_id, ip_address, details) VALUES (?, ?, ?, ?, ?, ?)",
            (user_id, action, entity_type, entity_id, ip_address, details)
        )
    except Exception as e:
        print(f"Audit log error: {e}")
