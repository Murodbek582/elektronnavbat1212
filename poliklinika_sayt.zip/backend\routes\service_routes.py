from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional
from backend.database import fetch_all, fetch_one, insert, execute
from backend.auth import require_admin, log_audit

router = APIRouter(prefix="/api/services", tags=["Clinic Services"])

class ServiceRequest(BaseModel):
    department_id: int
    name_uz: str
    name_ru: str
    name_en: str
    description_uz: Optional[str] = None
    description_ru: Optional[str] = None
    description_en: Optional[str] = None
    price: int = 0
    duration_minutes: int = 20
    is_active: Optional[bool] = True

@router.get("")
async def get_clinic_services():
    query = """
        SELECT s.*, dep.name_uz as department_name_uz, dep.name_ru as department_name_ru,
               dep.name_en as department_name_en, dep.code as department_code
        FROM services s
        JOIN departments dep ON s.department_id = dep.id
        WHERE s.is_active = 1
        ORDER BY s.department_id ASC, s.id ASC
    """
    services = fetch_all(query)
    
    # Attach active doctors for each service's department
    for s in services:
        docs = fetch_all("""
            SELECT id, full_name, room_number, specialization_uz, photo_url 
            FROM doctors 
            WHERE department_id = ? AND is_active = 1
        """, (s["department_id"],))
        s["available_doctors"] = docs

    return {"services": services}

@router.get("/{service_id}")
async def get_service_detail(service_id: int):
    query = """
        SELECT s.*, dep.name_uz as department_name_uz, dep.code as department_code
        FROM services s
        JOIN departments dep ON s.department_id = dep.id
        WHERE s.id = ?
    """
    srv = fetch_one(query, (service_id,))
    if not srv:
        raise HTTPException(status_code=404, detail="Xizmat topilmadi")
        
    doctors = fetch_all("""
        SELECT id, full_name, room_number, specialization_uz, photo_url, start_time, end_time
        FROM doctors 
        WHERE department_id = ? AND is_active = 1
    """, (srv["department_id"],))
    srv["available_doctors"] = doctors

    return {"service": srv}

@router.post("", dependencies=[Depends(require_admin)])
async def create_service(req: ServiceRequest, current_user: dict = Depends(require_admin)):
    srv_id = insert("""
        INSERT INTO services (department_id, name_uz, name_ru, name_en, description_uz, description_ru, description_en, price, duration_minutes, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (req.department_id, req.name_uz, req.name_ru, req.name_en, req.description_uz, req.description_ru, req.description_en, req.price, req.duration_minutes, 1 if req.is_active else 0))
    
    log_audit(current_user["id"], "CREATE_SERVICE", "services", str(srv_id), details=f"Created service {req.name_uz}")
    return {"message": "Yangi xizmat muvaffaqiyatli qo'shildi", "id": srv_id}

@router.put("/{service_id}", dependencies=[Depends(require_admin)])
async def update_service(service_id: int, req: ServiceRequest, current_user: dict = Depends(require_admin)):
    execute("""
        UPDATE services SET
            department_id = ?, name_uz = ?, name_ru = ?, name_en = ?,
            description_uz = ?, description_ru = ?, description_en = ?,
            price = ?, duration_minutes = ?, is_active = ?
        WHERE id = ?
    """, (req.department_id, req.name_uz, req.name_ru, req.name_en, req.description_uz, req.description_ru, req.description_en, req.price, req.duration_minutes, 1 if req.is_active else 0, service_id))
    
    log_audit(current_user["id"], "UPDATE_SERVICE", "services", str(service_id))
    return {"message": "Xizmat ma'lumotlari yangilandi"}

@router.delete("/{service_id}", dependencies=[Depends(require_admin)])
async def delete_service(service_id: int, current_user: dict = Depends(require_admin)):
    execute("UPDATE services SET is_active = 0 WHERE id = ?", (service_id,))
    log_audit(current_user["id"], "DELETE_SERVICE", "services", str(service_id))
    return {"message": "Xizmat o'chirildi (nofaol qilindi)"}
