import os
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware

from backend.config import APP_NAME, APP_VERSION, DEBUG
from backend.database import init_db
from backend.seed_data import seed_database
from backend.websocket_manager import manager

# Import Routes
from backend.routes.auth_routes import router as auth_router
from backend.routes.department_routes import router as department_router
from backend.routes.doctor_routes import router as doctor_router
from backend.routes.patient_routes import router as patient_router
from backend.routes.appointment_routes import router as appointment_router
from backend.routes.queue_routes import router as queue_router
from backend.routes.analytics_routes import router as analytics_router
from backend.routes.notification_routes import router as notification_router
from backend.routes.audit_routes import router as audit_router
from backend.routes.ai_routes import router as ai_router
from backend.routes.service_routes import router as service_router
from backend.routes.document_routes import router as document_router
from backend.routes.review_routes import router as review_router
from backend.routes.monitoring_routes import router as monitoring_router
from backend.routes.announcement_routes import router as announcement_router
from backend.routes.favorite_routes import router as favorite_router

BASE_DIR = Path(__file__).resolve().parent.parent

# Security Headers Middleware
class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        return response

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: ensure tables and seeds exist
    print("Initializing Database & Seed Data...")
    init_db()
    seed_database()
    print("Poliklinika Backend Ready!")
    yield
    # Shutdown
    print("Poliklinika Backend Shutting Down...")

app = FastAPI(
    title=APP_NAME,
    version=APP_VERSION,
    description="O'zbekiston Poliklinikalari uchun Zamonaviy Elektron Navbat Tizimi",
    lifespan=lifespan
)

# Middlewares
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Static Files & Locales
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
app.mount("/locales", StaticFiles(directory=str(BASE_DIR / "locales")), name="locales")

# Include Routers
app.include_router(auth_router)
app.include_router(department_router)
app.include_router(doctor_router)
app.include_router(patient_router)
app.include_router(appointment_router)
app.include_router(queue_router)
app.include_router(analytics_router)
app.include_router(notification_router)
app.include_router(audit_router)
app.include_router(ai_router)
app.include_router(service_router)
app.include_router(document_router)
app.include_router(review_router)
app.include_router(monitoring_router)
app.include_router(announcement_router)
app.include_router(favorite_router)

# Real-time WebSocket Endpoint
@app.websocket("/ws/queue")
async def websocket_queue_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        # Send initial connected message
        await websocket.send_json({
            "event": "CONNECTED",
            "message": "Real-vaqtli elektron navbat tarmog'iga ulandi"
        })
        while True:
            # Keep-alive ping/pong
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception:
        manager.disconnect(websocket)

# Main Application HTML View
@app.get("/", response_class=HTMLResponse)
async def serve_index():
    index_file = BASE_DIR / "templates" / "index.html"
    if not index_file.exists():
        raise HTTPException(status_code=404, detail="Index template not found")
    with open(index_file, "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())

# Friendly Error Handler
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": True, "detail": exc.detail, "status_code": exc.status_code}
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    # Log exception internally but never leak raw trace to patient
    print(f"Internal Server Error: {exc}")
    return JSONResponse(
        status_code=500,
        content={"error": True, "detail": "Tizimda ichki xatolik yuz berdi. Iltimos, keyinroq qayta urinib ko'ring."}
    )
