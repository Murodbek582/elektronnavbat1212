// Centralized Internationalization (i18n) Engine
// Supports Uzbek (uz), Russian (ru), English (en) with zero-delay fallback and live dictionary sync

let currentLang = localStorage.getItem("poliklinika_lang") || "uz";
let translationsCache = {};

// Expose current language globally
function getCurrentLang() { return currentLang; }

// Embedded high-priority fallback dictionary for immediate synchronous rendering
const fallbackTranslations = {
    uz: {
        app_title: "Elektron Navbat — Poliklinika",
        app_subtitle: "O'zbekiston Respublikasi Raqamli Qabul Tizimi",
        polyclinic_name: "Markaziy 1-sonli Ko'p Tarmoqli Poliklinika",
        live_status_connected: "Jonli efir: Ulandi",
        live_status_reconnecting: "Ulanmoqda...",
        working_hours_label: "Ish vaqti: 08:00 - 18:00",
        call_center_label: "Yagona call-markaz",
        nav_patient: "Bemor portali",
        nav_services: "Xizmatlar",
        nav_live_queue: "Navbat monitori (TV)",
        nav_doctor: "Shifokor xonasi",
        nav_admin: "Administrator",
        login_btn: "Kirish",
        register_btn: "Ro'yxatdan o'tish",
        logout_btn: "Chiqish",
        theme_toggle: "Mavzuni o'zgartirish",
        portal_title: "Onlayn elektron navbat olish",
        portal_subtitle: "Tibbiyot bo'limi, shifokor va qulay vaqtni tanlang. Navbat talonini onlayn oling va ekrandagi chaqiruvni kuzating.",
        step1_title: "1. Shaxsni tasdiqlash",
        step1_desc: "14 xonali JShShIR (PINFL) raqamini kiriting",
        pinfl_label: "JShShIR (PINFL) — 14 ta raqam",
        pinfl_placeholder: "14 ta raqamni kiriting...",
        pinfl_verify_btn: "Tasdiqlash",
        pinfl_verified_badge: "Shaxs tasdiqlandi",
        demo_patients_hint: "Tezkor sinov uchun demo bemorlar:",
        step2_title: "2. Tibbiyot bo'limini tanlang",
        step2_desc: "Kerakli ixtisoslashtirilgan tibbiy bo'limni tanlang",
        step3_title: "3. Shifokorni tanlang",
        step3_desc: "Qabuliga yozilmoqchi bo'lgan mutaxassisni tanlang",
        step4_title: "4. Qabul kuni va vaqtini tanlang",
        step4_desc: "Sizga qulay bo'sh vaqt oralig'ini tanlang",
        select_date: "Qabul sanasi",
        available_slots: "Mavjud bo'sh vaqtlar",
        book_btn: "Navbat talonini olish",
        my_appointments: "Mening navbatlarim",
        no_appointments: "Sizda hozircha faol navbatlar mavjud emas.",
        cancel_appt_btn: "Bekor qilish",
        print_ticket_btn: "Talonni chop etish",
        download_ticket_btn: "Yuklab olish",
        room_label: "Xona",
        duration_label: "Qabul davomiyligi",
        minutes: "daqiqa",
        tab_appointments: "📋 Navbatlar",
        tab_documents: "📄 Hujjatlar",
        tab_favorites: "❤️ Sevimlilar",
        tv_title: "ELEKTRON NAVBAT MONITORI",
        tv_calling_now: "HOZIR QABULGA CHAQIRILMOQDA",
        tv_room: "XONA",
        tv_doctor: "SHIFOKOR",
        tv_patient: "BEMOR",
        tv_next_patients: "Navbatdagi bemorlar",
        tv_waiting_count: "Kutayotganlar",
        tv_estimated_wait: "Taxminiy kutish vaqti",
        sound_enabled: "Ovoz: Yoqilgan",
        sound_disabled: "Ovoz: O'chirilgan",
        voice_settings_btn: "Ovoz sozlamalari",
        fullscreen_btn: "To'liq ekran (TV)",
        doctor_welcome: "Xush kelibsiz",
        call_next_btn: "Keyingi bemorni chaqirish",
        finish_consultation_btn: "Qabulni yakunlash",
        mark_absent_btn: "Kelmadi",
        today_queue_list: "Bugungi qabul ro'yxati",
        admin_dashboard_title: "Administrator boshqaruv markazi",
        stat_total_patients: "Jami bemorlar",
        stat_today_appts: "Bugungi navbatlar",
        stat_active_doctors: "Faol shifokorlar",
        stat_avg_wait: "O'rtacha kutish",
        tab_queue_control: "🎯 Navbat",
        tab_ai_assistant: "🤖 ADMIN AI",
        tab_monitoring: "🖥️ Monitoring",
        tab_patients: "👥 Bemorlar",
        tab_doctors: "🩺 Shifokorlar",
        tab_departments: "🏥 Bo'limlar",
        tab_analytics: "📊 Tahlil",
        tab_financial: "💰 Moliya",
        tab_admin_services: "🔬 Xizmatlar",
        tab_knowledge_base: "📚 Bilim bazasi",
        tab_announcements: "📢 E'lonlar",
        tab_reviews: "⭐ Sharhlar",
        tab_users: "👤 Foydalanuvchilar",
        tab_roles: "🛡️ Rollar",
        tab_backups: "💾 Zaxira",
        tab_settings: "⚙️ Sozlamalar",
        tab_audit: "📜 Audit",
        tab_sms: "📱 SMS",
        reset_queue_btn: "Kunlik navbatni tozalash (Demo)",
        export_csv_btn: "Eksport (CSV/Excel)",
        search_placeholder: "F.I.Sh, telefon yoki talon raqami bo'yicha qidiruv...",
        notifications_title: "Xabarnomalar",
        mark_all_read: "Barchasi o'qildi",
        no_notifications: "Yangi xabarnomalar yo'q.",
        save: "Saqlash",
        cancel: "Bekor qilish",
        close: "Yopish"
    },
    ru: {
        app_title: "Электронная Очередь — Поликлиника",
        app_subtitle: "Цифровая медицинская система Республики Узбекистан",
        polyclinic_name: "Центральная Многопрофильная Поликлиника №1",
        live_status_connected: "Онлайн: Подключено",
        live_status_reconnecting: "Подключение...",
        working_hours_label: "Время работы: 08:00 - 18:00",
        call_center_label: "Единый call-центр",
        nav_patient: "Портал пациента",
        nav_services: "Услуги",
        nav_live_queue: "Экран очереди (ТВ)",
        nav_doctor: "Кабинет врача",
        nav_admin: "Администратор",
        login_btn: "Войти",
        register_btn: "Регистрация",
        logout_btn: "Выход",
        theme_toggle: "Сменить тему",
        portal_title: "Онлайн запись в электронную очередь",
        portal_subtitle: "Выберите медицинское отделение, врача и удобное время. Получите талон онлайн и следите за вызовом на экране.",
        step1_title: "1. Идентификация личности",
        step1_desc: "Введите 14-значный номер ПИНФЛ (JShShIR)",
        pinfl_label: "ПИНФЛ — 14 цифр",
        pinfl_placeholder: "Введите 14 цифр...",
        pinfl_verify_btn: "Подтвердить",
        pinfl_verified_badge: "Личность подтверждена",
        demo_patients_hint: "Демо-пациенты для быстрого теста:",
        step2_title: "2. Выберите медицинское отделение",
        step2_desc: "Выберите профильное лечебное отделение",
        step3_title: "3. Выберите врача",
        step3_desc: "Выберите квалифицированного врача-специалиста",
        step4_title: "4. Выберите дату и время приема",
        step4_desc: "Выберите свободное и удобное для вас время",
        select_date: "Дата приема",
        available_slots: "Доступные интервалы времени",
        book_btn: "Записаться и получить талон",
        my_appointments: "Мои записи",
        no_appointments: "У вас пока нет активных записей.",
        cancel_appt_btn: "Отменить",
        print_ticket_btn: "Распечатать талон",
        download_ticket_btn: "Скачать",
        room_label: "Кабинет",
        duration_label: "Длительность приема",
        minutes: "минут",
        tab_appointments: "📋 Очереди",
        tab_documents: "📄 Документы",
        tab_favorites: "❤️ Избранные",
        tv_title: "ЭКРАН ЭЛЕКТРОННОЙ ОЧЕРЕДИ",
        tv_calling_now: "СЕЙЧАС ВЫЗЫВАЕТСЯ НА ПРИЕМ",
        tv_room: "КАБИНЕТ",
        tv_doctor: "ВРАЧ",
        tv_patient: "ПАЦИЕНТ",
        tv_next_patients: "Следующие пациенты в очереди",
        tv_waiting_count: "Ожидают",
        tv_estimated_wait: "Примерное время ожидания",
        sound_enabled: "Звук: Включен",
        sound_disabled: "Звук: Выключен",
        voice_settings_btn: "Настройки голоса",
        fullscreen_btn: "Во весь экран (ТВ)",
        doctor_welcome: "Добро пожаловать",
        call_next_btn: "Вызвать следующего пациента",
        finish_consultation_btn: "Завершить прием",
        mark_absent_btn: "Не явился",
        today_queue_list: "Список приема на сегодня",
        admin_dashboard_title: "Панель управления администратора",
        stat_total_patients: "Всего пациентов",
        stat_today_appts: "Записей на сегодня",
        stat_active_doctors: "Активных врачей",
        stat_avg_wait: "Ср. время ожидания",
        tab_queue_control: "🎯 Очередь",
        tab_ai_assistant: "🤖 ADMIN AI",
        tab_monitoring: "🖥️ Мониторинг",
        tab_patients: "👥 Пациенты",
        tab_doctors: "🩺 Врачи",
        tab_departments: "🏥 Отделения",
        tab_analytics: "📊 Аналитика",
        tab_financial: "💰 Финансы",
        tab_admin_services: "🔬 Услуги",
        tab_knowledge_base: "📚 База знаний",
        tab_announcements: "📢 Объявления",
        tab_reviews: "⭐ Отзывы",
        tab_users: "👤 Пользователи",
        tab_roles: "🛡️ Роли",
        tab_backups: "💾 Бэкапы",
        tab_settings: "⚙️ Настройки",
        tab_audit: "📜 Аудит",
        tab_sms: "📱 СМС",
        reset_queue_btn: "Очистить очередь дня (Демо)",
        export_csv_btn: "Экспорт (CSV/Excel)",
        search_placeholder: "Поиск по ФИО, телефону или номеру талона...",
        notifications_title: "Уведомления",
        mark_all_read: "Отметить все как прочитанные",
        no_notifications: "Новых уведомлений нет.",
        save: "Сохранить",
        cancel: "Отмена",
        close: "Закрыть"
    },
    en: {
        app_title: "Electronic Queue — Polyclinic",
        app_subtitle: "Republic of Uzbekistan Digital Healthcare System",
        polyclinic_name: "Central Multi-profile Polyclinic No. 1",
        live_status_connected: "Online: Connected",
        live_status_reconnecting: "Connecting...",
        working_hours_label: "Working hours: 08:00 - 18:00",
        call_center_label: "Central Call Center",
        nav_patient: "Patient Portal",
        nav_services: "Services",
        nav_live_queue: "Queue Monitor (TV)",
        nav_doctor: "Doctor Room",
        nav_admin: "Administrator",
        login_btn: "Sign In",
        register_btn: "Register",
        logout_btn: "Sign Out",
        theme_toggle: "Toggle Theme",
        portal_title: "Online Electronic Queue Booking",
        portal_subtitle: "Select a medical department, doctor, and convenient time slot. Get your queue ticket online and track calls on the screen.",
        step1_title: "1. Identity Verification",
        step1_desc: "Enter your 14-digit National ID (PINFL)",
        pinfl_label: "PINFL (JShShIR) — 14 digits",
        pinfl_placeholder: "Enter 14 digits...",
        pinfl_verify_btn: "Verify",
        pinfl_verified_badge: "Identity Verified",
        demo_patients_hint: "Demo patients for quick testing:",
        step2_title: "2. Select Medical Department",
        step2_desc: "Choose the specialized medical department",
        step3_title: "3. Select Doctor",
        step3_desc: "Select the qualified specialist doctor",
        step4_title: "4. Select Date & Time Slot",
        step4_desc: "Choose a convenient available time slot",
        select_date: "Appointment Date",
        available_slots: "Available Time Slots",
        book_btn: "Book & Get Ticket",
        my_appointments: "My Appointments",
        no_appointments: "You have no active appointments currently.",
        cancel_appt_btn: "Cancel",
        print_ticket_btn: "Print Ticket",
        download_ticket_btn: "Download",
        room_label: "Room",
        duration_label: "Appointment Duration",
        minutes: "mins",
        tab_appointments: "📋 Queues",
        tab_documents: "📄 Documents",
        tab_favorites: "❤️ Favorites",
        tv_title: "LIVE QUEUE DISPLAY MONITOR",
        tv_calling_now: "NOW BEING CALLED",
        tv_room: "ROOM",
        tv_doctor: "DOCTOR",
        tv_patient: "PATIENT",
        tv_next_patients: "Next Patients in Line",
        tv_waiting_count: "Waiting",
        tv_estimated_wait: "Estimated Wait Time",
        sound_enabled: "Sound: On",
        sound_disabled: "Sound: Off",
        voice_settings_btn: "Voice Settings",
        fullscreen_btn: "Fullscreen (TV)",
        doctor_welcome: "Welcome",
        call_next_btn: "Call Next Patient",
        finish_consultation_btn: "Finish Consultation",
        mark_absent_btn: "Mark as Absent",
        today_queue_list: "Today's Patient Schedule",
        admin_dashboard_title: "Administrator Command Center",
        stat_total_patients: "Total Patients",
        stat_today_appts: "Today's Appointments",
        stat_active_doctors: "Active Doctors",
        stat_avg_wait: "Avg Wait Time",
        tab_queue_control: "🎯 Queue",
        tab_ai_assistant: "🤖 ADMIN AI",
        tab_monitoring: "🖥️ Monitoring",
        tab_patients: "👥 Patients",
        tab_doctors: "🩺 Doctors",
        tab_departments: "🏥 Departments",
        tab_analytics: "📊 Analytics",
        tab_financial: "💰 Financial",
        tab_admin_services: "🔬 Services",
        tab_knowledge_base: "📚 Knowledge Base",
        tab_announcements: "📢 Announcements",
        tab_reviews: "⭐ Reviews",
        tab_users: "👤 Users",
        tab_roles: "🛡️ Roles",
        tab_backups: "💾 Backups",
        tab_settings: "⚙️ Settings",
        tab_audit: "📜 Audit",
        tab_sms: "📱 SMS",
        reset_queue_btn: "Reset Daily Queue (Demo)",
        export_csv_btn: "Export (CSV/Excel)",
        search_placeholder: "Search by name, phone or ticket number...",
        notifications_title: "Notifications",
        mark_all_read: "Mark all as read",
        no_notifications: "No new notifications.",
        save: "Save",
        cancel: "Cancel",
        close: "Close"
    }
};

// Initialize translations from JSON files with fallback
async function initI18n() {
    translationsCache = { ...fallbackTranslations };
    try {
        const langs = ['uz', 'ru', 'en'];
        await Promise.all(langs.map(async (l) => {
            try {
                const res = await fetch(`/locales/${l}.json`);
                if (res.ok) {
                    const data = await res.json();
                    translationsCache[l] = { ...translationsCache[l], ...data };
                }
            } catch (err) {
                console.warn(`Could not load /locales/${l}.json:`, err);
            }
        }));
    } catch (e) {
        console.warn("I18n init warning:", e);
    }
    applyTranslations();
}

function setLanguage(lang) {
    if (!['uz', 'ru', 'en'].includes(lang)) lang = 'uz';
    currentLang = lang;
    localStorage.setItem("poliklinika_lang", lang);

    // Apply translations across all static elements
    applyTranslations();

    // Sync language with MEDI AI assistant
    if (typeof setMediAiLang === 'function') {
        setMediAiLang(lang);
    }

    // Sync language with Voice Announcement Engine
    if (typeof setVoiceAnnouncementLang === 'function') {
        setVoiceAnnouncementLang(lang);
    }

    // Re-render currently active views dynamically without full page reload
    refreshActiveViewLanguage();

    // Dispatch global event for other components
    window.dispatchEvent(new CustomEvent('languageChanged', { detail: { lang: currentLang } }));
}

function t(key, replacements = {}) {
    const dict = (translationsCache[currentLang] || fallbackTranslations[currentLang] || fallbackTranslations["uz"]);
    let text = dict[key] || (fallbackTranslations["uz"] && fallbackTranslations["uz"][key]) || key;
    
    // Replace placeholders like {ticket}, {room}
    if (replacements && typeof replacements === 'object') {
        for (const [k, v] of Object.entries(replacements)) {
            text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), v);
        }
    }
    return text;
}

function applyTranslations() {
    // 1. Text content
    document.querySelectorAll("[data-i18n]").forEach(el => {
        const key = el.getAttribute("data-i18n");
        el.textContent = t(key);
    });

    // 2. Placeholders
    document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
        const key = el.getAttribute("data-i18n-placeholder");
        el.setAttribute("placeholder", t(key));
    });

    // 3. Titles / tooltips
    document.querySelectorAll("[data-i18n-title]").forEach(el => {
        const key = el.getAttribute("data-i18n-title");
        el.setAttribute("title", t(key));
    });

    // 4. Update Header Language Switcher Label
    const langBtn = document.getElementById("currentLangLabel");
    if (langBtn) {
        if (currentLang === "uz") {
            langBtn.innerHTML = `<span>🇺🇿 O'zbekcha</span>`;
        } else if (currentLang === "ru") {
            langBtn.innerHTML = `<span>🇷🇺 Русский</span>`;
        } else {
            langBtn.innerHTML = `<span>🇬🇧 English</span>`;
        }
    }
}

// Refresh dynamic section data when language changes
function refreshActiveViewLanguage() {
    // Refresh Patient Portal dynamic data
    if (typeof currentAppSection !== 'undefined') {
        if (currentAppSection === 'patient') {
            if (typeof loadDepartments === 'function') loadDepartments();
            if (typeof loadMyAppointments === 'function') loadMyAppointments();
        } else if (currentAppSection === 'services') {
            if (typeof loadServicesPage === 'function') loadServicesPage();
        } else if (currentAppSection === 'live') {
            if (typeof loadLiveQueue === 'function') loadLiveQueue();
        } else if (currentAppSection === 'doctor') {
            if (typeof loadDoctorDashboard === 'function') loadDoctorDashboard();
        } else if (currentAppSection === 'admin') {
            if (typeof loadAdminDashboard === 'function') loadAdminDashboard();
        }
    }
}

// Load dictionaries immediately when DOM is ready
document.addEventListener("DOMContentLoaded", () => {
    initI18n();
});
