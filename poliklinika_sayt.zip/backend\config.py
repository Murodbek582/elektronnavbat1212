import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Application Settings
APP_NAME = "Elektron Navbat — Poliklinika (AI Smart Healthcare Platform)"
APP_VERSION = "3.0.0"
DEBUG = os.getenv("DEBUG", "True").lower() == "true"
PORT = int(os.getenv("PORT", 8000))
HOST = os.getenv("HOST", "127.0.0.1")

# Database & Backups
DATABASE_URL = os.getenv("DATABASE_URL", str(BASE_DIR / "polyclinic.db"))
BACKUP_DIR = BASE_DIR / "backups"
BACKUP_DIR.mkdir(exist_ok=True)

# Security
SECRET_KEY = os.getenv("SECRET_KEY", "super-secret-poliklinika-jwt-key-uz-2026-secure-hash")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 hours

# AI Engine Configuration
AI_PROVIDER = os.getenv("AI_PROVIDER", "hybrid")  # 'hybrid', 'openai', 'gemini', 'builtin'
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

# SMS Gateway Configuration (Demo Mode by default)
SMS_GATEWAY_PROVIDER = os.getenv("SMS_GATEWAY_PROVIDER", "demo")  # 'demo', 'eskiz', 'playmobile'
SMS_API_KEY = os.getenv("SMS_API_KEY", "")
SMS_SENDER_NAME = os.getenv("SMS_SENDER_NAME", "Poliklinika")

# Uzbekistan PINFL Mock API vs Live API
PINFL_API_MODE = os.getenv("PINFL_API_MODE", "demo")  # 'demo' or 'live'
PINFL_API_URL = os.getenv("PINFL_API_URL", "https://api.egov.uz/pinfl/v1/verify")
PINFL_API_TOKEN = os.getenv("PINFL_API_TOKEN", "")

# Polyclinic Information
POLYCLINIC_NAME_UZ = "Markaziy 1-sonli Ko'p Tarmoqli Poliklinika"
POLYCLINIC_NAME_RU = "Центральная Многопрофильная Поликлиника №1"
POLYCLINIC_NAME_EN = "Central Multi-profile Polyclinic No. 1"
POLYCLINIC_ADDRESS_UZ = "Toshkent shahri, Chilonzor tumani, Bunyodkor ko'chasi 42-uy"
POLYCLINIC_PHONE = "+998 71 200-00-11"
WORKING_HOURS = "08:00 - 18:00"
