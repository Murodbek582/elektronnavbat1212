from fastapi import APIRouter, HTTPException, status, Depends, Query
from backend.models import DoctorCreateRequest, DoctorUpdateRequest
from backend.database import fetch_all, fetch_one, insert, execute
from backend.auth import require_admin, require_doctor, get_current_user, hash_password, log_audit
from datetime import datetime, date, timedelta
from typing import Optional

router = APIRouter(prefix="/api/doctors", tags=["Doctors"])

@router.get("")
async def get_doctors(
    department_id: Optional[int] = None,
    is_active: Optional[bool] = None,
    search: Optional[str] = None
):
    query = """
        SELECT d.*, dep.name_uz as department_name_uz, dep.name_ru as department_name_ru, dep.name_en as department_name_en, dep.code as department_code
        FROM doctors d
        JOIN departments dep ON d.department_id = dep.id
        WHERE 1=1
    """
    params = []
    
    if department_id is not None:
        query += " AND d.department_id = ?"
        params.append(department_id)
        
    if is_active is not None:
        query += " AND d.is_active = ?"
        params.append(1 if is_active else 0)
        
    if search:
        query += " AND (d.full_name LIKE ? OR d.specialization_uz LIKE ? OR d.room_number LIKE ?)"
        s = f"%{search}%"
        params.extend([s, s, s])
        
    query += " ORDER BY d.department_id ASC, d.id ASC"
    doctors = fetch_all(query, tuple(params))
    return {"doctors": doctors}

@router.get("/{doctor_id}")
async def get_doctor_detail(doctor_id: int):
    query = """
        SELECT d.*, dep.name_uz as department_name_uz, dep.code as department_code,
               u.email as doctor_email
        FROM doctors d
        JOIN departments dep ON d.department_id = dep.id
        LEFT JOIN users u ON d.user_id = u.id
        WHERE d.id = ?
    """
    doctor = fetch_one(query, (doctor_id,))
    if not doctor:
        raise HTTPException(status_code=404, detail="Shifokor topilmadi")
        
    schedules = fetch_all("""
        SELECT * FROM doctor_schedules WHERE doctor_id = ? AND is_active = 1 ORDER BY day_of_week ASC
    """, (doctor_id,))
    
    return {"doctor": doctor, "schedules": schedules}

@router.get("/{doctor_id}/available-slots")
async def get_doctor_available_slots(doctor_id: int, target_date: str = Query(..., description="YYYY-MM-DD")):
    try:
        dt = datetime.strptime(target_date, "%Y-%m-%d").date()
    except ValueError:
        raise HTTPException(status_code=400, detail="Noto'g'ri sana formati. YYYY-MM-DD ko'rinishida kiriting.")
        
    today = date.today()
    if dt < today:
        return {"slots": [], "message": "O'tib ketgan sanaga qabul band qilib bo'lmaydi"}
        
    # Check doctor working days (day of week: 0=Monday, 6=Sunday)
    weekday = dt.weekday()
    doctor = fetch_one("SELECT * FROM doctors WHERE id = ? AND is_active = 1", (doctor_id,))
    if not doctor:
        raise HTTPException(status_code=404, detail="Shifokor faol emas yoki topilmadi")
        
    working_days = [int(x.strip()) - 1 for x in doctor["working_days"].split(",") if x.strip()] # 1-based to 0-based
    if weekday not in working_days:
        return {"slots": [], "message": "Tanlangan kunda shifokor qabul o'tkazmaydi (dam olish kuni)"}
        
    # Generate time slots
    start_time_str = doctor["start_time"] # e.g. "08:30"
    end_time_str = doctor["end_time"]     # e.g. "17:30"
    duration = doctor["appointment_duration"] or 20
    
    sh, sm = map(int, start_time_str.split(":"))
    eh, em = map(int, end_time_str.split(":"))
    
    current_time = datetime(dt.year, dt.month, dt.day, sh, sm)
    end_dt = datetime(dt.year, dt.month, dt.day, eh, em)
    
    # Lunch break 13:00 - 14:00
    lunch_start = datetime(dt.year, dt.month, dt.day, 13, 0)
    lunch_end = datetime(dt.year, dt.month, dt.day, 14, 0)
    
    # Fetch already booked appointments for this doctor on this date (excluding cancelled)
    booked_rows = fetch_all("""
        SELECT start_time FROM appointments 
        WHERE doctor_id = ? AND appointment_date = ? AND status != 'cancelled'
    """, (doctor_id, target_date))
    booked_times = {row["start_time"] for row in booked_rows}
    
    slots = []
    now = datetime.now()
    
    while current_time + timedelta(minutes=duration) <= end_dt:
        slot_start_str = current_time.strftime("%H:%M")
        slot_end_str = (current_time + timedelta(minutes=duration)).strftime("%H:%M")
        
        # Check lunch
        is_lunch = (current_time >= lunch_start and current_time < lunch_end)
        
        # Check if already booked
        is_booked = slot_start_str in booked_times
        
        # Check if time has already passed for today
        is_past = False
        if dt == today and current_time < now:
            is_past = True
            
        available = (not is_lunch) and (not is_booked) and (not is_past)
        
        slots.append({
            "start_time": slot_start_str,
            "end_time": slot_end_str,
            "is_available": available,
            "is_lunch": is_lunch,
            "is_booked": is_booked,
            "is_past": is_past
        })
        current_time += timedelta(minutes=duration)
        
    return {"doctor_id": doctor_id, "date": target_date, "duration": duration, "slots": slots}

# Doctor's own private dashboard routes
@router.get("/my/dashboard")
async def get_my_doctor_dashboard(current_user: dict = Depends(require_doctor)):
    doc = fetch_one("""
        SELECT d.*, dep.name_uz as department_name_uz, dep.code as department_code
        FROM doctors d
        JOIN departments dep ON d.department_id = dep.id
        WHERE d.user_id = ?
    """, (current_user["id"],))
    
    if not doc:
        raise HTTPException(status_code=404, detail="Shifokor profili topilmadi")
        
    today_str = str(date.today())
    
    # Today's appointments for this doctor
    appointments = fetch_all("""
        SELECT a.*, p.full_name as patient_name, p.pinfl as patient_pinfl, p.phone as patient_phone,
               p.birth_date as patient_birth_date, p.gender as patient_gender,
               qt.ticket_number, qt.status as queue_status, qt.called_at, qt.priority_number
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        LEFT JOIN queue_tickets qt ON a.id = qt.appointment_id
        WHERE a.doctor_id = ? AND a.appointment_date = ?
        ORDER BY a.start_time ASC
    """, (doc["id"], today_str))
    
    # Stats for today
    total_today = len(appointments)
    waiting_count = sum(1 for a in appointments if a["status"] in ("waiting", "calling"))
    serving_count = sum(1 for a in appointments if a["status"] == "in_consultation")
    completed_count = sum(1 for a in appointments if a["status"] == "completed")
    
    return {
        "doctor": doc,
        "today_date": today_str,
        "stats": {
            "total_today": total_today,
            "waiting": waiting_count,
            "serving": serving_count,
            "completed": completed_count
        },
        "appointments": appointments
    }

# Admin Doctor Management
@router.post("", dependencies=[Depends(require_admin)])
async def create_doctor(req: DoctorCreateRequest, current_user: dict = Depends(require_admin)):
    email = req.email or f"doc_{int(datetime.now().timestamp())}@poliklinika.uz"
    pwd_hash = hash_password(req.password or "Doctor123!")
    
    user_id = insert("""
        INSERT INTO users (email, phone, password_hash, role, full_name)
        VALUES (?, ?, ?, 'doctor', ?)
    """, (email, req.phone, pwd_hash, req.full_name))
    
    photo = req.photo_url or "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=300"
    
    doc_id = insert("""
        INSERT INTO doctors (
            user_id, department_id, full_name, specialization_uz, specialization_ru, specialization_en,
            room_number, photo_url, phone, appointment_duration, working_days, start_time, end_time, bio_uz
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        user_id, req.department_id, req.full_name, req.specialization_uz, req.specialization_ru, req.specialization_en,
        req.room_number, photo, req.phone, req.appointment_duration, req.working_days, req.start_time, req.end_time, req.bio_uz
    ))
    
    # Create default schedule (Mon-Fri)
    for day in range(5):
        insert("""
            INSERT INTO doctor_schedules (doctor_id, day_of_week, start_time, end_time, slot_duration)
            VALUES (?, ?, ?, ?, ?)
        """, (doc_id, day, req.start_time, req.end_time, req.appointment_duration))
        
    log_audit(current_user["id"], "CREATE_DOCTOR", "doctors", str(doc_id), details=f"Created doctor {req.full_name}")
    return {"message": "Shifokor muvaffaqiyatli qo'shildi", "doctor_id": doc_id}

@router.put("/{doctor_id}", dependencies=[Depends(require_admin)])
async def update_doctor(doctor_id: int, req: DoctorUpdateRequest, current_user: dict = Depends(require_admin)):
    doc = fetch_one("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
    if not doc:
        raise HTTPException(status_code=404, detail="Shifokor topilmadi")
        
    fields = []
    params = []
    
    for k, v in req.model_dump(exclude_unset=True).items():
        if v is not None:
            if k == "is_active":
                fields.append("is_active = ?")
                params.append(1 if v else 0)
            else:
                fields.append(f"{k} = ?")
                params.append(v)
                
    if fields:
        params.append(doctor_id)
        execute(f"UPDATE doctors SET {', '.join(fields)} WHERE id = ?", tuple(params))
        
        # Also update users table full_name if provided
        if req.full_name and doc["user_id"]:
            execute("UPDATE users SET full_name = ? WHERE id = ?", (req.full_name, doc["user_id"]))
            
    log_audit(current_user["id"], "UPDATE_DOCTOR", "doctors", str(doctor_id))
    return {"message": "Shifokor ma'lumotlari yangilandi"}

@router.delete("/{doctor_id}", dependencies=[Depends(require_admin)])
async def delete_doctor(doctor_id: int, current_user: dict = Depends(require_admin)):
    doc = fetch_one("SELECT * FROM doctors WHERE id = ?", (doctor_id,))
    if not doc:
        raise HTTPException(status_code=404, detail="Shifokor topilmadi")
        
    # Check if active upcoming appointments exist
    has_appts = fetch_one("""
        SELECT id FROM appointments 
        WHERE doctor_id = ? AND appointment_date >= DATE('now') AND status IN ('waiting', 'in_consultation')
    """, (doctor_id,))
    if has_appts:
        raise HTTPException(
            status_code=400,
            detail="Ushbu shifokorda faol navbatlar mavjud. Avval ularni bekor qiling yoki boshqa shifokorga o'tkazing."
        )
        
    # Soft delete by deactivating
    execute("UPDATE doctors SET is_active = 0 WHERE id = ?", (doctor_id,))
    if doc["user_id"]:
        execute("UPDATE users SET is_active = 0 WHERE id = ?", (doc["user_id"],))
        
    log_audit(current_user["id"], "DEACTIVATE_DOCTOR", "doctors", str(doctor_id))
    return {"message": "Shifokor tizimdan o'chirildi (nofaol qilindi)"}
