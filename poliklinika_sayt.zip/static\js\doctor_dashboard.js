// Doctor Dashboard Controller

let currentDoctorApptInConsultation = null;

async function loadDoctorDashboard() {
    const container = document.getElementById("doctorSectionContent");
    if (!container) return;

    const token = localStorage.getItem("poliklinika_token");
    const userStr = localStorage.getItem("poliklinika_user");
    
    let isDoctor = false;
    if (userStr) {
        try {
            const u = JSON.parse(userStr);
            isDoctor = u.role === "doctor";
        } catch (e) {}
    }

    if (!token || !isDoctor) {
        container.innerHTML = `
            <div class="p-12 text-center max-w-md mx-auto">
                <div class="w-16 h-16 mx-auto mb-4 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                </div>
                <h3 class="text-xl font-bold text-slate-800 dark:text-slate-100 mb-2">Shifokor xonasiga kirish</h3>
                <p class="text-sm text-slate-500 mb-6">Ushbu bo'limdan foydalanish uchun shifokor akkaunti orqali tizimga kiring.</p>
                
                <div class="space-y-3">
                    <button onclick="quickDoctorLogin('dr.rustamov@poliklinika.uz')" class="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm transition">
                        Dr. Rustamov (Terapevt, 101-xona) sifatida kirish
                    </button>
                    <button onclick="quickDoctorLogin('dr.umarova@poliklinika.uz')" class="w-full py-2.5 px-4 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm transition">
                        Dr. Umarova (Kardiolog, 102-xona) sifatida kirish
                    </button>
                    <button onclick="openAuthModal('doctor')" class="w-full py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-700 font-bold text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800">
                        Boshqa shifokor login-paroli bilan kirish
                    </button>
                </div>
            </div>
        `;
        return;
    }

    try {
        const res = await apiCall("/api/doctors/my/dashboard");
        renderDoctorDashboardUI(res);
    } catch (err) {
        container.innerHTML = `<div class="p-8 text-center text-rose-500 text-sm">${err.message}</div>`;
    }
}

async function quickDoctorLogin(email) {
    try {
        const res = await apiCall("/api/auth/login", "POST", {
            username: email,
            password: "Doctor123!"
        });
        localStorage.setItem("poliklinika_token", res.access_token);
        localStorage.setItem("poliklinika_user", JSON.stringify(res.user));
        updateAuthUI();
        showToast(`${res.user.full_name} kabinetiga muvaffaqiyatli kirildi!`, "success");
        loadDoctorDashboard();
    } catch (err) {
        showToast("Kirishda xatolik: " + err.message, "error");
    }
}

function renderDoctorDashboardUI(data) {
    const container = document.getElementById("doctorSectionContent");
    if (!container) return;

    const doc = data.doctor;
    const stats = data.stats;
    const appointments = data.appointments || [];

    // Find currently active consultation
    currentDoctorApptInConsultation = appointments.find(a => a.status === 'in_consultation' || a.queue_status === 'calling');

    container.innerHTML = `
        <div class="space-y-6">
            <!-- Doctor Header Banner -->
            <div class="p-6 md:p-8 rounded-3xl bg-gradient-to-r from-blue-700 via-indigo-700 to-sky-700 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div class="flex items-center gap-5">
                    <img src="${doc.photo_url || 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200'}"
                         alt="${doc.full_name}" class="w-20 h-20 rounded-2xl object-cover border-2 border-white/30 shadow-md">
                    <div>
                        <div class="text-xs font-bold uppercase tracking-wider text-sky-200">Shifokor Qabul Kabineti</div>
                        <h2 class="text-2xl font-black">${doc.full_name}</h2>
                        <div class="text-sm text-sky-100 font-medium">${doc.specialization_uz} • ${doc.department_name_uz}</div>
                    </div>
                </div>
                <div class="flex items-center gap-3">
                    <div class="px-6 py-4 rounded-2xl bg-white/15 backdrop-blur-md border border-white/20 text-center">
                        <div class="text-xs uppercase tracking-widest text-sky-200 font-bold">Biriktirilgan Xona</div>
                        <div class="text-3xl font-black mono text-amber-300">${doc.room_number}-XONA</div>
                    </div>
                    <button onclick="doctorCallNext()" class="px-6 py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-sm shadow-lg flex items-center gap-2 transition-all transform hover:-translate-y-0.5">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"></path></svg>
                        <span>${t("call_next_btn")}</span>
                    </button>
                </div>
            </div>

            <!-- Stats Grid -->
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                    <div class="text-xs text-slate-500 uppercase font-bold">Bugungi jami bemorlar</div>
                    <div class="text-3xl font-black mono text-slate-800 dark:text-slate-100 mt-2">${stats.total_today}</div>
                </div>
                <div class="p-5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 shadow-sm">
                    <div class="text-xs text-amber-700 dark:text-amber-400 uppercase font-bold">Kutayotganlar</div>
                    <div class="text-3xl font-black mono text-amber-600 dark:text-amber-400 mt-2">${stats.waiting}</div>
                </div>
                <div class="p-5 rounded-2xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/50 shadow-sm">
                    <div class="text-xs text-blue-700 dark:text-blue-400 uppercase font-bold">Qabuldagilar</div>
                    <div class="text-3xl font-black mono text-blue-600 dark:text-blue-400 mt-2">${stats.serving}</div>
                </div>
                <div class="p-5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 shadow-sm">
                    <div class="text-xs text-emerald-700 dark:text-emerald-400 uppercase font-bold">Yakunlangan qabullar</div>
                    <div class="text-3xl font-black mono text-emerald-600 dark:text-emerald-400 mt-2">${stats.completed}</div>
                </div>
            </div>

            <!-- Active Consultation Card (if any) -->
            ${currentDoctorApptInConsultation ? `
                <div class="p-6 rounded-3xl border-2 border-emerald-500 bg-emerald-50/60 dark:bg-emerald-950/30 shadow-lg">
                    <div class="flex items-center justify-between mb-4">
                        <span class="px-3.5 py-1 rounded-full bg-emerald-600 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2">
                            <span class="w-2 h-2 rounded-full bg-white live-pulse"></span>
                            Hozir xonada qabul qilinmoqda
                        </span>
                        <span class="text-2xl font-black mono text-emerald-800 dark:text-emerald-300">
                            ${currentDoctorApptInConsultation.ticket_number}
                        </span>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div>
                            <div class="text-xs text-slate-500 font-bold uppercase">Bemor ma'lumotlari</div>
                            <div class="text-xl font-bold text-slate-800 dark:text-slate-100 mt-1">${currentDoctorApptInConsultation.patient_name}</div>
                            <div class="text-xs text-slate-500 mt-1">
                                JShShIR: ${maskPINFL(currentDoctorApptInConsultation.patient_pinfl)} • Tug'ilgan sana: ${currentDoctorApptInConsultation.patient_birth_date || 'Noma''lum'}
                            </div>
                            <div class="text-xs text-slate-500 mt-0.5">Telefon: ${currentDoctorApptInConsultation.patient_phone}</div>
                            <div class="text-xs text-slate-600 dark:text-slate-300 mt-2 bg-white/70 dark:bg-slate-900/70 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800">
                                <b class="text-slate-700 dark:text-slate-200">Shikoyat/Sabab:</b> ${currentDoctorApptInConsultation.reason || 'Ko''rik'}
                            </div>
                        </div>

                        <div class="space-y-3">
                            <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase">${t("doctor_notes_label")}</label>
                            <input id="consultationDiagnosis" type="text" placeholder="Tashxis (masalan: O'RVI, Gipertoniya 1-bosqich...)"
                                   class="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm">
                            <textarea id="consultationNotes" rows="2" placeholder="Tavsiyalar, dorilar yoki yo'llanmalar..."
                                      class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm"></textarea>
                        </div>
                    </div>

                    <div class="flex flex-wrap items-center justify-end gap-3 pt-4 border-t border-emerald-200 dark:border-emerald-800">
                        <button onclick="doctorMarkAbsent(${currentDoctorApptInConsultation.id})" class="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-300 dark:hover:bg-slate-700">
                            ${t("mark_absent_btn")}
                        </button>
                        <button onclick="doctorCompleteConsultation(${currentDoctorApptInConsultation.id})" class="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold shadow-md">
                            ${t("finish_consultation_btn")} ✓
                        </button>
                    </div>
                </div>
            ` : ''}

            <!-- Appointments Schedule Table -->
            <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                <div class="flex items-center justify-between mb-5">
                    <h3 class="text-lg font-bold text-slate-800 dark:text-slate-100">${t("today_queue_list")}</h3>
                    <button onclick="loadDoctorDashboard()" class="text-xs text-blue-600 dark:text-blue-400 font-bold hover:underline flex items-center gap-1">
                        <span>Yangilash ⟳</span>
                    </button>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm">
                        <thead>
                            <tr class="border-b border-slate-100 dark:border-slate-800 text-xs font-bold text-slate-400 uppercase tracking-wider">
                                <th class="pb-3">Talon</th>
                                <th class="pb-3">Vaqt</th>
                                <th class="pb-3">Bemor F.I.Sh</th>
                                <th class="pb-3">Holat</th>
                                <th class="pb-3 text-right">Amal</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                            ${appointments.length === 0 ? `
                                <tr>
                                    <td colspan="5" class="py-8 text-center text-slate-400">
                                        Bugungi kunda qabulga yozilgan bemorlar yo'q.
                                    </td>
                                </tr>
                            ` : appointments.map(a => `
                                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                                    <td class="py-3.5 font-black mono text-base ${a.status === 'in_consultation' ? 'text-emerald-600' : 'text-slate-700 dark:text-slate-300'}">
                                        ${a.ticket_number || a.appointment_number}
                                    </td>
                                    <td class="py-3.5 text-xs text-slate-500 mono">${a.start_time} - ${a.end_time}</td>
                                    <td class="py-3.5">
                                        <div class="font-bold text-slate-800 dark:text-slate-100">${a.patient_name}</div>
                                        <div class="text-xs text-slate-400">${maskPINFL(a.patient_pinfl)} • ${a.patient_phone}</div>
                                    </td>
                                    <td class="py-3.5">
                                        <span class="px-2.5 py-1 rounded-full text-xs font-bold ${
                                            a.status === 'in_consultation' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' :
                                            a.status === 'waiting' ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300' :
                                            a.status === 'completed' ? 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300' :
                                            'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                        }">
                                            ${a.status === 'in_consultation' ? t('status_serving') :
                                              a.status === 'waiting' ? t('status_waiting') :
                                              a.status === 'completed' ? t('status_completed') :
                                              a.status === 'absent' ? t('status_absent') : t('status_cancelled')}
                                        </span>
                                    </td>
                                    <td class="py-3.5 text-right">
                                        ${a.status === 'waiting' ? `
                                            <button onclick="doctorCallSpecific(${a.doctor_id})" class="px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950 dark:text-emerald-300 text-xs font-bold">
                                                Chaqirish
                                            </button>
                                        ` : a.status === 'in_consultation' ? `
                                            <span class="text-xs font-bold text-emerald-600 animate-pulse">Qabul jarayonida...</span>
                                        ` : `
                                            <span class="text-xs text-slate-400">—</span>
                                        `}
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;
}

async function doctorCallNext() {
    try {
        const res = await apiCall("/api/queue/call-next", "POST", {});
        showToast(res.message, "success", "Bemor chaqirildi");
        loadDoctorDashboard();
    } catch (err) {
        showToast(err.message, "warning");
    }
}

async function doctorCallSpecific(doctorId) {
    try {
        const res = await apiCall("/api/queue/call-next", "POST", { doctor_id: doctorId });
        showToast(res.message, "success");
        loadDoctorDashboard();
    } catch (err) {
        showToast(err.message, "warning");
    }
}

async function doctorCompleteConsultation(appointmentId) {
    const diagInput = document.getElementById("consultationDiagnosis");
    const notesInput = document.getElementById("consultationNotes");

    const diagnosis = diagInput ? diagInput.value.trim() : "";
    const notes = notesInput ? notesInput.value.trim() : "";

    try {
        const res = await apiCall(`/api/queue/complete/${appointmentId}`, "POST", {
            diagnosis,
            notes
        });
        showToast(res.message, "success");
        loadDoctorDashboard();
    } catch (err) {
        showToast(err.message, "error");
    }
}

async function doctorMarkAbsent(appointmentId) {
    if (!confirm("Rostdan ham bemor qabulga kelmadi deb belgilansinmi?")) return;
    try {
        const res = await apiCall(`/api/queue/absent/${appointmentId}`, "POST", {});
        showToast(res.message, "info");
        loadDoctorDashboard();
    } catch (err) {
        showToast(err.message, "error");
    }
}
