from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime, date

from backend.ai_engine import ask_medi_ai, ask_admin_ai, diagnose_system_health
from backend.auth import require_admin, get_optional_user, log_audit
from backend.database import fetch_all, fetch_one, insert, execute

router = APIRouter(prefix="/api/ai", tags=["AI Intelligence Engine"])

class MediAIChatRequest(BaseModel):
    message: str = Field(..., min_length=1)
    history: Optional[List[Dict[str, str]]] = None
    lang: Optional[str] = "uz"

class AdminAIChatRequest(BaseModel):
    query: str = Field(..., min_length=1)

class KnowledgeBaseItemRequest(BaseModel):
    category: str = Field(..., description="clinic, doctor, department, service, rules, faq, contact, preparation")
    question: str
    answer: str
    keywords: Optional[str] = None
    is_active: Optional[bool] = True

# 1. Patient MEDI AI Chat Endpoint
@router.post("/medi-chat")
async def chat_with_medi_ai(req: MediAIChatRequest, request: Request, current_user: Optional[dict] = Depends(get_optional_user)):
    user_id = current_user["id"] if current_user else None
    client_ip = request.client.host if request.client else "unknown"

    response = await ask_medi_ai(req.message, req.history, req.lang or "uz")

    if user_id:
        log_audit(user_id, "AI_MEDI_CHAT", "ai_chat", None, client_ip, f"User asked MEDI AI: {req.message[:50]}...")

    return {
        "success": True,
        "reply": response["reply"],
        "is_emergency": response.get("is_emergency", False),
        "suggested_doctor": response.get("suggested_doctor"),
        "action": response.get("action"),
        "timestamp": datetime.now().isoformat()
    }

# 2. Administrator AI Assistant Endpoint
@router.post("/admin-query")
async def query_admin_ai(req: AdminAIChatRequest, current_user: dict = Depends(require_admin)):
    response = await ask_admin_ai(req.query, current_user)
    log_audit(current_user["id"], "AI_ADMIN_QUERY", "admin_ai", None, None, f"Admin asked: {req.query[:50]}")
    return {
        "success": True,
        "reply": response["reply"],
        "data": response.get("data"),
        "timestamp": datetime.now().isoformat()
    }

# 3. AI System Health Diagnostics
@router.get("/system-diagnostics", dependencies=[Depends(require_admin)])
async def get_system_diagnostics():
    diagnostics = diagnose_system_health()
    return diagnostics

# 4. AI Smart Slot Recommendation
@router.get("/recommend-slot")
async def recommend_smart_slot(doctor_id: int, date_str: str):
    from backend.routes.doctor_routes import get_doctor_available_slots
    slots_res = await get_doctor_available_slots(doctor_id, date_str)
    slots = slots_res.get("slots", [])
    available = [s for s in slots if s.get("is_available")]

    if not available:
        return {
            "has_slots": False,
            "message": "Tanlangan sanada bo'sh vaqtlar qolmagan."
        }

    # Best slot heuristic: middle of morning or mid afternoon (less crowded)
    preferred_times = ["10:20", "10:40", "11:00", "15:00", "15:20", "15:40"]
    best_slot = None
    for p in preferred_times:
        match = next((s for s in available if s["start_time"] == p), None)
        if match:
            best_slot = match
            break

    if not best_slot:
        best_slot = available[0]

    return {
        "has_slots": True,
        "recommended_slot": best_slot,
        "reason": "Ushbu vaqt oralig'ida kutish zallarida bemorlar soni kamroq bo'ladi va kutish vaqti minimal darajaga tushadi."
    }

# 5. AI Knowledge Base CRUD (Admin)
@router.get("/knowledge-base")
async def get_knowledge_base():
    entries = fetch_all("SELECT * FROM ai_knowledge_base ORDER BY id DESC")
    return {"entries": entries}

@router.post("/knowledge-base", dependencies=[Depends(require_admin)])
async def create_kb_entry(req: KnowledgeBaseItemRequest, current_user: dict = Depends(require_admin)):
    kb_id = insert("""
        INSERT INTO ai_knowledge_base (category, question, answer, keywords, is_active)
        VALUES (?, ?, ?, ?, ?)
    """, (req.category, req.question, req.answer, req.keywords, 1 if req.is_active else 0))
    log_audit(current_user["id"], "CREATE_KB_ENTRY", "ai_knowledge_base", str(kb_id))
    return {"message": "Bilimlar bazasiga yangi ma'lumot qo'shildi", "id": kb_id}

@router.put("/knowledge-base/{kb_id}", dependencies=[Depends(require_admin)])
async def update_kb_entry(kb_id: int, req: KnowledgeBaseItemRequest, current_user: dict = Depends(require_admin)):
    execute("""
        UPDATE ai_knowledge_base SET
            category = ?, question = ?, answer = ?, keywords = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (req.category, req.question, req.answer, req.keywords, 1 if req.is_active else 0, kb_id))
    log_audit(current_user["id"], "UPDATE_KB_ENTRY", "ai_knowledge_base", str(kb_id))
    return {"message": "Bilimlar bazasi yangilandi"}

@router.delete("/knowledge-base/{kb_id}", dependencies=[Depends(require_admin)])
async def delete_kb_entry(kb_id: int, current_user: dict = Depends(require_admin)):
    execute("DELETE FROM ai_knowledge_base WHERE id = ?", (kb_id,))
    log_audit(current_user["id"], "DELETE_KB_ENTRY", "ai_knowledge_base", str(kb_id))
    return {"message": "Ma'lumot o'chirildi"}
