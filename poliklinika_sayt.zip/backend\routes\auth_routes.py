from fastapi import APIRouter, HTTPException, status, Depends, Request
from backend.models import LoginRequest, PatientRegisterRequest, ChangePasswordRequest, PasswordResetRequest
from backend.database import fetch_one, insert, execute
from backend.auth import (
    verify_password, hash_password, create_access_token,
    get_current_user, log_audit
)
import re

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

@router.post("/login")
async def login(req: LoginRequest, request: Request):
    username = req.username.strip()
    
    # Check if username is 14-digit PINFL
    user = None
    if re.match(r"^\d{14}$", username):
        patient = fetch_one("SELECT user_id FROM patients WHERE pinfl = ?", (username,))
        if patient:
            user = fetch_one("SELECT * FROM users WHERE id = ?", (patient["user_id"],))
    
    # Otherwise check by email or phone
    if not user:
        clean_phone = re.sub(r"[\s\-\(\)]", "", username)
        if not clean_phone.startswith("+") and clean_phone.startswith("998"):
            clean_phone = "+" + clean_phone
        user = fetch_one("SELECT * FROM users WHERE email = ? OR phone = ? OR phone = ?", 
                         (username, username, clean_phone))
    
    if not user or not verify_password(req.password, user["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Login yoki parol noto'g'ri. Iltimos, qayta tekshirib ko'ring.",
        )
        
    if not user["is_active"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Ushbu foydalanuvchi hisobi faol emas. Administratorga murojaat qiling.",
        )
        
    # Prepare token payload
    token_data = {
        "sub": str(user["id"]),
        "role": user["role"],
        "name": user["full_name"]
    }
    access_token = create_access_token(token_data)
    
    # Extra role-specific data
    extra_data = {}
    if user["role"] == "patient":
        pat = fetch_one("SELECT id, pinfl, birth_date, gender, blood_group, is_verified FROM patients WHERE user_id = ?", (user["id"],))
        if pat:
            extra_data["patient"] = pat
    elif user["role"] == "doctor":
        doc = fetch_one("""
            SELECT d.id, d.department_id, d.room_number, d.specialization_uz, dep.name_uz as department_name 
            FROM doctors d
            JOIN departments dep ON d.department_id = dep.id
            WHERE d.user_id = ?
        """, (user["id"],))
        if doc:
            extra_data["doctor"] = doc
            
    client_ip = request.client.host if request.client else "unknown"
    log_audit(user["id"], "LOGIN", "users", str(user["id"]), client_ip, f"User logged in as {user['role']}")

    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": user["id"],
            "full_name": user["full_name"],
            "email": user["email"],
            "phone": user["phone"],
            "role": user["role"],
            **extra_data
        }
    }

@router.post("/register-patient")
async def register_patient(req: PatientRegisterRequest, request: Request):
    pwd_hash = hash_password(req.password)
    
    # 1. Check if phone already belongs to user
    existing_user = fetch_one("SELECT id, role, full_name FROM users WHERE phone = ?", (req.phone,))
    if existing_user:
        if existing_user["role"] in ("admin", "doctor"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Ushbu telefon raqami ({req.phone}) xizmat xodimi hisobiga tegishli. Boshqa telefon raqam kiriting.",
            )
        # Update existing patient account
        user_id = existing_user["id"]
        execute("""
            UPDATE users 
            SET password_hash = ?, full_name = ?, updated_at = CURRENT_TIMESTAMP 
            WHERE id = ?
        """, (pwd_hash, req.full_name, user_id))
    else:
        # Create new user
        user_id = insert("""
            INSERT INTO users (phone, password_hash, role, full_name)
            VALUES (?, ?, 'patient', ?)
        """, (req.phone, pwd_hash, req.full_name))
        
    # 2. Check if PINFL is registered to another user
    pin_conflict = fetch_one("SELECT id, user_id FROM patients WHERE pinfl = ? AND user_id != ?", (req.pinfl, user_id))
    if pin_conflict:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Ushbu JShShIR ({req.pinfl}) boshqa bemor hisobiga biriktirilgan. Iltimos, JShShIRingizni to'g'ri kiriting.",
        )
        
    # 3. Create or update patient profile
    existing_patient = fetch_one("SELECT id FROM patients WHERE user_id = ? OR pinfl = ?", (user_id, req.pinfl))
    if existing_patient:
        patient_id = existing_patient["id"]
        execute("""
            UPDATE patients 
            SET user_id = ?, pinfl = ?, full_name = ?, birth_date = ?, gender = ?, phone = ?, address = ?, blood_group = ?, is_verified = 1
            WHERE id = ?
        """, (user_id, req.pinfl, req.full_name, req.birth_date, req.gender, req.phone, req.address, req.blood_group or "O'lchanmagan", patient_id))
    else:
        patient_id = insert("""
            INSERT INTO patients (user_id, pinfl, full_name, birth_date, gender, phone, address, blood_group, is_verified)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
        """, (user_id, req.pinfl, req.full_name, req.birth_date, req.gender, req.phone, req.address, req.blood_group or "O'lchanmagan"))
    
    # Notification
    insert("""
        INSERT INTO notifications (user_id, title, message, type, channel, delivery_status)
        VALUES (?, 'Tizimga xush kelibsiz!', 'Elektron navbat poliklinika tizimiga muvaffaqiyatli ro''yxatdan o''tdingiz.', 'system', 'in_app', 'delivered')
    """, (user_id,))
    
    client_ip = request.client.host if request.client else "unknown"
    log_audit(user_id, "REGISTER", "patients", str(patient_id), client_ip, f"Patient registered/updated with PINFL: {req.pinfl}")
    
    token = create_access_token({"sub": str(user_id), "role": "patient", "name": req.full_name})
    
    return {
        "access_token": token,
        "token_type": "bearer",
        "message": "Muvaffaqiyatli ro'yxatdan o'tdingiz!",
        "user": {
            "id": user_id,
            "full_name": req.full_name,
            "phone": req.phone,
            "role": "patient",
            "patient": {
                "id": patient_id,
                "pinfl": req.pinfl,
                "birth_date": req.birth_date,
                "gender": req.gender,
                "is_verified": 1
            }
        }
    }

@router.get("/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    return {"user": current_user}

@router.post("/change-password")
async def change_password(req: ChangePasswordRequest, current_user: dict = Depends(get_current_user)):
    db_user = fetch_one("SELECT password_hash FROM users WHERE id = ?", (current_user["id"],))
    if not verify_password(req.old_password, db_user["password_hash"]):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Joriy parol noto'g'ri kiritildi.",
        )
        
    new_hash = hash_password(req.new_password)
    execute("UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (new_hash, current_user["id"]))
    log_audit(current_user["id"], "CHANGE_PASSWORD", "users", str(current_user["id"]))
    return {"message": "Parol muvaffaqiyatli yangilandi!"}

@router.post("/reset-password-demo")
async def reset_password_demo(req: PasswordResetRequest):
    # Verify PINFL or phone
    patient = None
    if req.pinfl:
        patient = fetch_one("SELECT user_id FROM patients WHERE pinfl = ?", (req.pinfl,))
    
    user = None
    if patient:
        user = fetch_one("SELECT * FROM users WHERE id = ?", (patient["user_id"],))
    else:
        user = fetch_one("SELECT * FROM users WHERE email = ? OR phone = ?", (req.email_or_phone, req.email_or_phone))
        
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Kiritilgan ma'lumotlar bo'yicha foydalanuvchi topilmadi.",
        )
        
    new_hash = hash_password(req.new_password)
    execute("UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (new_hash, user["id"]))
    log_audit(user["id"], "RESET_PASSWORD", "users", str(user["id"]), details="Demo password reset completed")
    return {"message": "Parol muvaffaqiyatli yangilandi! Endi yangi parol bilan tizimga kiring."}

@router.get("/users")
async def list_users(current_user: dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Ruxsat berilmagan")
    users = fetch_all("""
        SELECT u.id, u.username, u.email, u.phone, u.role, u.is_active, u.created_at,
               p.full_name as patient_name, d.full_name as doctor_name
        FROM users u
        LEFT JOIN patients p ON u.id = p.user_id
        LEFT JOIN doctors d ON u.id = d.user_id
        ORDER BY u.id ASC
    """)
    return {"users": users}

@router.post("/users/toggle/{user_id}")
async def toggle_user_active(user_id: int, current_user: dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Ruxsat berilmagan")
    target = fetch_one("SELECT id, is_active FROM users WHERE id = ?", (user_id,))
    if not target:
        raise HTTPException(status_code=404, detail="Foydalanuvchi topilmadi")
    new_state = 0 if target["is_active"] else 1
    execute("UPDATE users SET is_active = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?", (new_state, user_id))
    log_audit(current_user["id"], "TOGGLE_USER_STATUS", "users", str(user_id), details=f"Active set to {new_state}")
    return {"is_active": new_state, "message": "Foydalanuvchi holati o'zgartirildi"}

@router.get("/roles")
async def get_roles(current_user: dict = Depends(get_current_user)):
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Ruxsat berilmagan")
    roles = [
        {"role": "admin", "name": "Bosh Administrator", "permissions": ["Barcha modullar", "Tizim sozlamalari", "Zaxira nusxalar", "Shifokorlar va Bo'limlar", "Audit va monitoring", "AI Boshqaruvi"], "color": "purple"},
        {"role": "doctor", "name": "Shifokor", "permissions": ["Shaxsiy qabul xonasi", "Kutish zalini ko'rish", "Bemorlarni chaqirish", "Qabulni yakunlash", "Tibbiy xulosalar kiritish"], "color": "emerald"},
        {"role": "staff", "name": "Registratura / Hamshira", "permissions": ["Bemorlarni ro'yxatga olish", "Navbat berish", "Umumiy jadvalni ko'rish", "Talon chop etish"], "color": "blue"},
        {"role": "patient", "name": "Bemor (Fuqaro)", "permissions": ["Onlayn navbat olish", "Shaxsiy talonlar", "Tibbiy hujjatlarni ko'rish", "Sevimli shifokorlar", "Shifokorga sharh qoldirish", "MEDI AI maslahati"], "color": "sky"}
    ]
    return {"roles": roles}
