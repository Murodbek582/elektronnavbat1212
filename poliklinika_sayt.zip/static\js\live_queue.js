// Live Queue Display Engine with WebSockets, Audio Chimes, and Multilingual Voice Synthesis

// Voice Settings State (Persisted in localStorage)
let voiceConfig = {
    enabled: localStorage.getItem("poliklinika_voice_enabled") !== "false",
    volume: parseFloat(localStorage.getItem("poliklinika_voice_volume") || "1.0"),
    rate: parseFloat(localStorage.getItem("poliklinika_voice_rate") || "0.95"),
    pitch: parseFloat(localStorage.getItem("poliklinika_voice_pitch") || "1.0"),
    lang: localStorage.getItem("poliklinika_voice_lang") || localStorage.getItem("poliklinika_lang") || "uz",
    voiceURI: localStorage.getItem("poliklinika_voice_uri") || ""
};

let soundMuted = localStorage.getItem("poliklinika_sound_muted") === "true";
let liveSocket = null;
let reconnectTimer = null;
let audioCtx = null;
let lastAnnouncedTicket = null;
const announcedEventsCache = new Set();

// Browser User-Gesture Unlocking for Autoplay Restrictions
function initAudioContext() {
    if (!audioCtx) {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) {
            audioCtx = new AudioCtx();
        }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume().catch(() => {});
    }
}

// Global user gesture listener to unlock audio on first interaction
['click', 'touchstart', 'keydown'].forEach(evt => {
    document.addEventListener(evt, () => {
        initAudioContext();
        if ('speechSynthesis' in window && window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
        }
    }, { once: true, passive: true });
});

// Synthesizes a pleasant medical polyclinic chime
function playHospitalChime() {
    if (soundMuted || !voiceConfig.enabled) return;
    try {
        initAudioContext();
        if (!audioCtx) return;

        const now = audioCtx.currentTime;
        // Chime sequence: C5 (523.25Hz) -> E5 (659.25Hz) -> G5 (783.99Hz)
        const notes = [
            { freq: 523.25, time: 0.0, duration: 0.4 },
            { freq: 659.25, time: 0.22, duration: 0.4 },
            { freq: 783.99, time: 0.44, duration: 0.8 }
        ];

        notes.forEach(n => {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();

            osc.type = "sine";
            osc.frequency.setValueAtTime(n.freq, now + n.time);

            const vol = Math.max(0.01, Math.min(1.0, voiceConfig.volume)) * 0.25;
            gain.gain.setValueAtTime(0.001, now + n.time);
            gain.gain.exponentialRampToValueAtTime(vol, now + n.time + 0.04);
            gain.gain.exponentialRampToValueAtTime(0.001, now + n.time + n.duration);

            osc.connect(gain);
            gain.connect(audioCtx.destination);

            osc.start(now + n.time);
            osc.stop(now + n.time + n.duration);
        });
    } catch (e) {
        console.warn("Audio chime playback blocked or not supported:", e);
    }
}

// Find best matching voice for the target language
function getBestVoiceForLang(targetLang) {
    if (!('speechSynthesis' in window)) return null;
    const voices = window.speechSynthesis.getVoices();
    if (!voices || voices.length === 0) return null;

    // 1. If user selected a specific voice URI
    if (voiceConfig.voiceURI) {
        const custom = voices.find(v => v.voiceURI === voiceConfig.voiceURI);
        if (custom) return custom;
    }

    // 2. Direct language match
    if (targetLang === "uz") {
        const uzVoice = voices.find(v => v.lang.toLowerCase().startsWith("uz"));
        if (uzVoice) return uzVoice;
        // Uzbek Latin is phonetically transparent; Turkish or Russian engines pronounce cleanly
        const trVoice = voices.find(v => v.lang.toLowerCase().startsWith("tr"));
        if (trVoice) return trVoice;
        const ruVoice = voices.find(v => v.lang.toLowerCase().startsWith("ru"));
        if (ruVoice) return ruVoice;
    } else if (targetLang === "ru") {
        const ruVoice = voices.find(v => v.lang.toLowerCase().startsWith("ru"));
        if (ruVoice) return ruVoice;
    } else if (targetLang === "en") {
        const enVoice = voices.find(v => v.lang.toLowerCase().startsWith("en"));
        if (enVoice) return enVoice;
    }

    return voices[0] || null;
}

// Core Speech Synthesis Speaker
function speakText(text, targetLang = null) {
    if (soundMuted || !voiceConfig.enabled || !('speechSynthesis' in window)) return;
    try {
        const lang = targetLang || voiceConfig.lang || currentLang || "uz";
        window.speechSynthesis.cancel(); // clear previous queue

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.volume = Math.max(0.1, Math.min(1.0, voiceConfig.volume));
        utterance.rate = Math.max(0.5, Math.min(1.5, voiceConfig.rate));
        utterance.pitch = Math.max(0.5, Math.min(1.5, voiceConfig.pitch));

        const voice = getBestVoiceForLang(lang);
        if (voice) {
            utterance.voice = voice;
            utterance.lang = voice.lang;
        }

        window.speechSynthesis.speak(utterance);
    } catch (err) {
        console.warn("Speech synthesis error:", err);
    }
}

// EVENT 1 — WHEN A PATIENT BOOKS A QUEUE
function announceQueueEvent1(ticketNumber) {
    if (!ticketNumber) return;
    const lang = voiceConfig.lang || currentLang || "uz";
    let text = "";

    if (lang === "ru") {
        text = `Ваш номер очереди ${ticketNumber}. Пожалуйста, ожидайте своей очереди.`;
    } else if (lang === "en") {
        text = `Your queue number is ${ticketNumber}. Please wait for your turn.`;
    } else {
        text = `Sizning navbat raqamingiz ${ticketNumber}. Iltimos, navbatingizni kuting.`;
    }

    playHospitalChime();
    setTimeout(() => {
        speakText(text, lang);
    }, 600);
}

// EVENT 2 — WHEN AN ADMINISTRATOR OR DOCTOR CALLS A PATIENT
function announceQueueEvent2(ticketNumber, roomNumber, eventId = null) {
    if (!ticketNumber || !roomNumber) return;

    // Deduplication check: do not announce the same event ID twice within 10 seconds
    const dedupeKey = eventId || `${ticketNumber}-${roomNumber}-${Math.floor(Date.now() / 10000)}`;
    if (announcedEventsCache.has(dedupeKey)) {
        return;
    }
    announcedEventsCache.add(dedupeKey);
    // Keep cache bounded
    if (announcedEventsCache.size > 100) {
        const first = announcedEventsCache.values().next().value;
        announcedEventsCache.delete(first);
    }

    lastAnnouncedTicket = { ticketNumber, roomNumber, timestamp: new Date() };
    const lang = voiceConfig.lang || currentLang || "uz";
    let text = "";

    if (lang === "ru") {
        text = `Пациент с номером ${ticketNumber}, пожалуйста, пройдите в кабинет номер ${roomNumber}.`;
    } else if (lang === "en") {
        text = `Patient number ${ticketNumber}, please proceed to room number ${roomNumber}.`;
    } else {
        text = `${ticketNumber} raqamli bemor, iltimos, ${roomNumber}-kabinetga kiring.`;
    }

    playHospitalChime();
    setTimeout(() => {
        speakText(text, lang);
    }, 800);
}

// EVENT 3 — WHEN AN APPOINTMENT IS CANCELLED (Visual notification only, no private patient details)
function announceQueueEvent3(ticketNumber) {
    showToast(`Talon ${ticketNumber} bekor qilindi`, "info", "Navbat bekor qilindi");
}

// Repeat Last Announcement
function repeatLastVoiceAnnouncement() {
    if (!lastAnnouncedTicket) {
        showToast("Hozircha chaqirilgan talonlar mavjud emas", "warning");
        return;
    }
    const { ticketNumber, roomNumber } = lastAnnouncedTicket;
    const lang = voiceConfig.lang || currentLang || "uz";
    let text = "";

    if (lang === "ru") {
        text = `Повторный вызов. Пациент с номером ${ticketNumber}, пожалуйста, пройдите в кабинет номер ${roomNumber}.`;
    } else if (lang === "en") {
        text = `Repeat announcement. Patient number ${ticketNumber}, please proceed to room number ${roomNumber}.`;
    } else {
        text = `Takroriy e'lon. ${ticketNumber} raqamli bemor, iltimos, ${roomNumber}-kabinetga kiring.`;
    }

    playHospitalChime();
    setTimeout(() => {
        speakText(text, lang);
        showToast(`Talon ${ticketNumber} qayta chaqirildi (${roomNumber}-xona)`, "info");
    }, 600);
}

// Test Voice
function testVoiceAnnouncement() {
    initAudioContext();
    const lang = voiceConfig.lang || currentLang || "uz";
    let testMsg = "";
    if (lang === "ru") {
        testMsg = "Тестовое голосовое объявление. Система электронной очереди работает отлично.";
    } else if (lang === "en") {
        testMsg = "Test voice announcement. The electronic queue system is working properly.";
    } else {
        testMsg = "Sinov ovozli e'loni. Elektron navbat tizimi muvaffaqiyatli ishlamoqda.";
    }
    playHospitalChime();
    setTimeout(() => {
        speakText(testMsg, lang);
    }, 600);
}

// Voice Settings Sync
function setVoiceAnnouncementLang(lang) {
    voiceConfig.lang = lang;
    localStorage.setItem("poliklinika_voice_lang", lang);
}

// Legacy wrapper for existing calls
function announceVoice(ticketNumber, roomNumber) {
    announceQueueEvent2(ticketNumber, roomNumber);
}

// Sound Mute Toggle
function toggleSound() {
    initAudioContext();
    soundMuted = !soundMuted;
    localStorage.setItem("poliklinika_sound_muted", soundMuted);
    updateSoundUI();
    
    if (!soundMuted) {
        playHospitalChime();
        showToast(t("sound_enabled"), "info");
    } else {
        showToast(t("sound_disabled"), "warning");
    }
}

function updateSoundUI() {
    const btn = document.getElementById("soundToggleBtn");
    const icon = document.getElementById("soundIcon");
    const text = document.getElementById("soundText");

    if (btn && icon && text) {
        if (soundMuted) {
            btn.className = "px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-500 text-xs font-semibold flex items-center gap-1.5 transition";
            text.textContent = t("sound_disabled");
            icon.innerHTML = `<svg class="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" /></svg>`;
        } else {
            btn.className = "px-3 py-1.5 rounded-lg border border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center gap-1.5 transition";
            text.textContent = t("sound_enabled");
            icon.innerHTML = `<svg class="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" /></svg>`;
        }
    }
}

function toggleTVFullscreen() {
    const elem = document.getElementById("liveQueueSection");
    if (!elem) return;

    if (!document.fullscreenElement) {
        elem.requestFullscreen().catch(err => {
            console.error(`Fullscreen request error: ${err.message}`);
        });
    } else {
        document.exitFullscreen();
    }
}

// Fetch and render Live Queue Snapshot
async function loadLiveQueue() {
    try {
        const res = await apiCall("/api/queue/live");
        renderLiveQueue(res);
    } catch (err) {
        console.error("Failed to load live queue:", err);
    }
}

function renderLiveQueue(data) {
    // 1. Current Calling Card
    const currentContainer = document.getElementById("tvCurrentCalling");
    if (!currentContainer) return;

    const activeCalls = data.active_calls || [];
    if (activeCalls.length > 0) {
        const primary = activeCalls[0];
        currentContainer.innerHTML = `
            <div class="p-8 rounded-3xl bg-gradient-to-br from-emerald-600 via-teal-700 to-cyan-800 text-white shadow-2xl relative overflow-hidden calling-ticket-glow">
                <div class="absolute -right-12 -top-12 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none"></div>
                <div class="flex items-center justify-between mb-4">
                    <span class="px-4 py-1.5 rounded-full bg-white/20 backdrop-blur-md text-sm font-bold tracking-wider uppercase">
                        ${t("tv_calling_now")}
                    </span>
                    <span class="flex items-center gap-2 text-sm font-semibold opacity-90">
                        <span class="w-3 h-3 rounded-full bg-emerald-400 live-pulse"></span>
                        QABULGA MARHAMAT!
                    </span>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                    <div>
                        <div class="text-xs uppercase tracking-widest text-emerald-100 font-bold mb-1">Talon Raqami</div>
                        <div class="text-6xl md:text-8xl font-black tracking-tight mono text-white">${primary.ticket_number}</div>
                    </div>
                    <div class="bg-black/25 backdrop-blur-md p-6 rounded-2xl border border-white/20 flex flex-col justify-center">
                        <div class="text-xs uppercase tracking-widest text-emerald-200 font-bold mb-1">${t("tv_room")}</div>
                        <div class="text-4xl md:text-5xl font-black text-amber-300 mono mb-3">${primary.room_number}-XONA</div>
                        <div class="text-lg font-bold text-white">${primary.doctor_name}</div>
                        <div class="text-sm text-emerald-100 font-medium">${primary.doctor_specialization}</div>
                    </div>
                </div>

                ${activeCalls.length > 1 ? `
                    <div class="mt-6 pt-5 border-t border-white/20">
                        <div class="text-xs font-bold text-emerald-100 uppercase tracking-wider mb-2">Boshqa xonalarda hozir chaqirilganlar:</div>
                        <div class="flex flex-wrap gap-3">
                            ${activeCalls.slice(1).map(c => `
                                <div class="px-4 py-2 rounded-xl bg-white/15 backdrop-blur-sm border border-white/20 flex items-center gap-3">
                                    <span class="font-black mono text-xl text-amber-300">${c.ticket_number}</span>
                                    <span class="text-sm font-bold">${c.room_number}-xona</span>
                                    <span class="text-xs opacity-80">(${c.doctor_name.split(' ')[1] || c.doctor_name})</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
        `;
    } else {
        currentContainer.innerHTML = `
            <div class="p-12 rounded-3xl bg-slate-800/60 border border-slate-700/60 text-center text-slate-300">
                <div class="w-16 h-16 mx-auto mb-4 rounded-full bg-slate-700 flex items-center justify-center text-slate-400">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
                <div class="text-2xl font-bold mb-1">Hozircha navbat chaqirilmagan</div>
                <div class="text-sm text-slate-400">Shifokor xonasidan bemor chaqirilganda ekranda paydo bo'ladi</div>
            </div>
        `;
    }

    // 2. Waiting Patients Table
    const waitingContainer = document.getElementById("tvWaitingList");
    if (waitingContainer) {
        const waiting = data.waiting_tickets || [];
        if (waiting.length === 0) {
            waitingContainer.innerHTML = `
                <div class="p-8 text-center text-slate-400 text-sm">Hozircha kutayotgan bemorlar yo'q</div>
            `;
        } else {
            waitingContainer.innerHTML = waiting.map(w => `
                <div class="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between text-white">
                    <div class="flex items-center gap-3">
                        <span class="font-black mono text-2xl text-emerald-400">${w.ticket_number}</span>
                        <div>
                            <div class="text-xs text-slate-300 font-semibold">${w.department_name}</div>
                            <div class="text-[11px] text-slate-400">${w.doctor_name}</div>
                        </div>
                    </div>
                    <div class="text-right">
                        <span class="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 text-xs font-bold mono">
                            ${w.room_number}-XONA
                        </span>
                    </div>
                </div>
            `).join('');
        }
    }
}

// WebSocket Connection Setup
function connectLiveWebSocket() {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws/queue`;

    try {
        liveSocket = new WebSocket(wsUrl);

        liveSocket.onopen = () => {
            console.log("WebSocket Connected to Live Queue channel");
            const led = document.getElementById("liveStatusLed");
            const txt = document.getElementById("liveStatusText");
            if (led) led.className = "w-2.5 h-2.5 rounded-full bg-emerald-500 live-pulse";
            if (txt) txt.textContent = t("live_status_connected");
        };

        liveSocket.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                handleWebSocketMessage(data);
            } catch (e) {
                console.error("Failed to parse WebSocket message:", e);
            }
        };

        liveSocket.onclose = () => {
            console.warn("WebSocket Disconnected. Reconnecting in 3s...");
            const led = document.getElementById("liveStatusLed");
            const txt = document.getElementById("liveStatusText");
            if (led) led.className = "w-2.5 h-2.5 rounded-full bg-amber-500";
            if (txt) txt.textContent = t("live_status_reconnecting");
            
            clearTimeout(reconnectTimer);
            reconnectTimer = setTimeout(connectLiveWebSocket, 3000);
        };

        liveSocket.onerror = (err) => {
            console.error("WebSocket error:", err);
            liveSocket.close();
        };
    } catch (e) {
        console.error("WebSocket connection setup error:", e);
    }
}

function handleWebSocketMessage(msg) {
    if (!msg || !msg.event) return;

    if (msg.event === "PATIENT_CALLED") {
        if (msg.ticket) {
            announceQueueEvent2(msg.ticket.ticket_number, msg.ticket.room_number, msg.event_id || null);
            showToast(
                `Talon ${msg.ticket.ticket_number} ${msg.ticket.room_number}-xonaga chaqirildi!`,
                "success",
                "Navbat chaqiruvi"
            );
        }
        loadLiveQueue();
        if (typeof loadDoctorDashboard === "function") loadDoctorDashboard();
        if (typeof loadAdminQueue === "function") loadAdminQueue();
    } else if (msg.event === "TICKET_CANCELLED") {
        if (msg.ticket_number) {
            announceQueueEvent3(msg.ticket_number);
        }
        loadLiveQueue();
        if (typeof loadDoctorDashboard === "function") loadDoctorDashboard();
        if (typeof loadAdminQueue === "function") loadAdminQueue();
    } else if (msg.event === "TICKET_CREATED" || msg.event === "PATIENT_COMPLETED" || 
               msg.event === "PATIENT_ABSENT" || msg.event === "QUEUE_RESET") {
        loadLiveQueue();
        if (typeof loadDoctorDashboard === "function") loadDoctorDashboard();
        if (typeof loadAdminQueue === "function") loadAdminQueue();
        if (typeof loadAdminMetrics === "function") loadAdminMetrics();
    }
}

// Live Clock Ticker
function startLiveClock() {
    setInterval(() => {
        const el = document.getElementById("tvLiveClock");
        if (el) {
            const now = new Date();
            const localeStr = currentLang === "ru" ? "ru-RU" : currentLang === "en" ? "en-US" : "uz-UZ";
            const dateFormatted = now.toLocaleDateString(localeStr, { day: '2-digit', month: 'long', year: 'numeric' });
            const timeFormatted = now.toLocaleTimeString(localeStr);
            el.textContent = `${dateFormatted} | ${timeFormatted}`;
        }
    }, 1000);
}

// Voice Settings Modal Controls
function openVoiceSettingsModal() {
    initAudioContext();
    const modal = document.getElementById("voiceSettingsModal");
    if (!modal) return;

    // Populate available voices
    populateVoiceSelect();
    
    // Set current inputs
    const enabledChk = document.getElementById("voiceEnabledChk");
    const volRange = document.getElementById("voiceVolumeRange");
    const rateRange = document.getElementById("voiceRateRange");
    const langSelect = document.getElementById("voiceLangSelect");

    if (enabledChk) enabledChk.checked = voiceConfig.enabled;
    if (volRange) volRange.value = voiceConfig.volume;
    if (rateRange) rateRange.value = voiceConfig.rate;
    if (langSelect) langSelect.value = voiceConfig.lang || currentLang || "uz";

    modal.classList.remove("hidden");
}

function closeVoiceSettingsModal() {
    const modal = document.getElementById("voiceSettingsModal");
    if (modal) modal.classList.add("hidden");
}

function populateVoiceSelect() {
    const sel = document.getElementById("voiceSelectDropdown");
    if (!sel || !('speechSynthesis' in window)) return;

    const voices = window.speechSynthesis.getVoices();
    sel.innerHTML = `<option value="">Avtomatik tanlash (Eng mos keladigani)</option>`;

    voices.forEach(v => {
        const opt = document.createElement("option");
        opt.value = v.voiceURI;
        opt.textContent = `${v.name} (${v.lang})`;
        if (v.voiceURI === voiceConfig.voiceURI) {
            opt.selected = true;
        }
        sel.appendChild(opt);
    });
}

function saveVoiceSettings() {
    const enabledChk = document.getElementById("voiceEnabledChk");
    const volRange = document.getElementById("voiceVolumeRange");
    const rateRange = document.getElementById("voiceRateRange");
    const langSelect = document.getElementById("voiceLangSelect");
    const voiceSelect = document.getElementById("voiceSelectDropdown");

    if (enabledChk) voiceConfig.enabled = enabledChk.checked;
    if (volRange) voiceConfig.volume = parseFloat(volRange.value);
    if (rateRange) voiceConfig.rate = parseFloat(rateRange.value);
    if (langSelect) voiceConfig.lang = langSelect.value;
    if (voiceSelect) voiceConfig.voiceURI = voiceSelect.value;

    localStorage.setItem("poliklinika_voice_enabled", voiceConfig.enabled);
    localStorage.setItem("poliklinika_voice_volume", voiceConfig.volume);
    localStorage.setItem("poliklinika_voice_rate", voiceConfig.rate);
    localStorage.setItem("poliklinika_voice_lang", voiceConfig.lang);
    localStorage.setItem("poliklinika_voice_uri", voiceConfig.voiceURI);

    closeVoiceSettingsModal();
    showToast("Ovoz sozlamalari saqlandi!", "success");
}

// Listen for speech synthesis voice list load
if ('speechSynthesis' in window) {
    window.speechSynthesis.onvoiceschanged = () => {
        populateVoiceSelect();
    };
}
