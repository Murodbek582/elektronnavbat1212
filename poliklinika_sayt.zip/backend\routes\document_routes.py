from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional, Dict, Any
from backend.database import fetch_all, fetch_one, insert
from backend.auth import get_current_user, require_doctor_or_admin, log_audit
import json

router = APIRouter(prefix="/api/documents", tags=["Digital Medical Documents"])

class MedicalDocumentCreateRequest(BaseModel):
    patient_id: int
    doctor_id: Optional[int] = None
    appointment_id: Optional[int] = None
    doc_type: str = "visit_summary"  # 'visit_summary', 'prescription_rec', 'lab_result', 'ticket'
    title: str
    content: Dict[str, Any]
    notes: Optional[str] = None

@router.get("/my")
async def get_my_documents(current_user: dict = Depends(get_current_user)):
    # Find patient record
    patient = fetch_one("SELECT id FROM patients WHERE user_id = ?", (current_user["id"],))
    if not patient:
        raise HTTPException(status_code=400, detail="Bemor profili topilmadi")

    docs = fetch_all("""
        SELECT md.*, d.full_name as doctor_name, d.specialization_uz as doctor_specialization,
               d.room_number, a.appointment_number, a.appointment_date
        FROM medical_documents md
        LEFT JOIN doctors d ON md.doctor_id = d.id
        LEFT JOIN appointments a ON md.appointment_id = a.id
        WHERE md.patient_id = ?
        ORDER BY md.id DESC
    """, (patient["id"],))

    # Parse content_json
    for d in docs:
        if d.get("content_json"):
            try:
                d["content"] = json.loads(d["content_json"])
            except Exception:
                d["content"] = {}

    return {"documents": docs}

@router.get("/{document_id}")
async def get_document_detail(document_id: int, current_user: dict = Depends(get_current_user)):
    doc = fetch_one("""
        SELECT md.*, p.full_name as patient_name, p.pinfl as patient_pinfl, p.user_id as patient_user_id,
               d.full_name as doctor_name, d.specialization_uz as doctor_specialization, d.room_number,
               a.appointment_number, a.appointment_date
        FROM medical_documents md
        JOIN patients p ON md.patient_id = p.id
        LEFT JOIN doctors d ON md.doctor_id = d.id
        LEFT JOIN appointments a ON md.appointment_id = a.id
        WHERE md.id = ?
    """, (document_id,))

    if not doc:
        raise HTTPException(status_code=404, detail="Hujjat topilmadi")

    # Access control: only owner patient, or doctor/admin can view!
    if current_user["role"] == "patient" and doc["patient_user_id"] != current_user["id"]:
        raise HTTPException(status_code=403, detail="Siz boshqa bemorning tibbiy hujjatini ko'ra olmaysiz")

    if doc.get("content_json"):
        try:
            doc["content"] = json.loads(doc["content_json"])
        except Exception:
            doc["content"] = {}

    # Mask PINFL
    pinfl = doc.get("patient_pinfl", "")
    if len(pinfl) == 14:
        doc["patient_pinfl_masked"] = f"{pinfl[:6]}******{pinfl[-2:]}"

    return {"document": doc}

@router.post("", dependencies=[Depends(require_doctor_or_admin)])
async def create_medical_document(req: MedicalDocumentCreateRequest, current_user: dict = Depends(require_doctor_or_admin)):
    doc_id = insert("""
        INSERT INTO medical_documents (patient_id, doctor_id, appointment_id, doc_type, title, content_json, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        req.patient_id, req.doctor_id, req.appointment_id, req.doc_type,
        req.title, json.dumps(req.content, ensure_ascii=False), req.notes
    ))

    log_audit(current_user["id"], "CREATE_MEDICAL_DOC", "medical_documents", str(doc_id))
    return {"message": "Tibbiy hujjat muvaffaqiyatli saqlandi", "id": doc_id}
