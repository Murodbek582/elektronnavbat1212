// Centralized API Client and Toast Notification System

const API_BASE = "";

async function apiCall(endpoint, method = "GET", data = null) {
    const token = localStorage.getItem("poliklinika_token");
    const headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    };

    if (token) {
        headers["Authorization"] = `Bearer ${token}`;
    }

    const options = {
        method,
        headers
    };

    if (data && (method === "POST" || method === "PUT" || method === "PATCH")) {
        options.body = JSON.stringify(data);
    }

    try {
        const response = await fetch(`${API_BASE}${endpoint}`, options);
        
        // Handle 401 Unauthorized
        if (response.status === 401) {
            localStorage.removeItem("poliklinika_token");
            localStorage.removeItem("poliklinika_user");
            updateAuthUI();
            // Only alert if this wasn't an initial /me check
            if (!endpoint.includes("/api/auth/me")) {
                showToast("Sessiya tugadi yoki ruxsat yo'q. Qayta kiring.", "warning");
            }
            throw new Error("Unauthorized");
        }

        const json = await response.json();
        
        if (!response.ok) {
            const errorMsg = json.detail || json.message || "Xatolik yuz berdi";
            throw new Error(errorMsg);
        }

        return json;
    } catch (err) {
        if (err.message !== "Unauthorized") {
            console.error(`API Error on ${endpoint}:`, err);
        }
        throw err;
    }
}

// Toast Notifications System
function showToast(message, type = "info", title = null) {
    const container = document.getElementById("toastContainer");
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = `toast p-4 rounded-xl shadow-lg border max-w-sm flex items-start gap-3 pointer-events-auto transition-all duration-300`;

    let bgColor = "bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border-slate-200 dark:border-slate-700";
    let iconSvg = `<svg class="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>`;
    
    if (type === "success") {
        bgColor = "bg-emerald-50 dark:bg-emerald-950/80 text-emerald-900 dark:text-emerald-100 border-emerald-200 dark:border-emerald-800";
        iconSvg = `<svg class="w-5 h-5 text-emerald-600 dark:text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>`;
    } else if (type === "error") {
        bgColor = "bg-rose-50 dark:bg-rose-950/80 text-rose-900 dark:text-rose-100 border-rose-200 dark:border-rose-800";
        iconSvg = `<svg class="w-5 h-5 text-rose-600 dark:text-rose-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>`;
    } else if (type === "warning") {
        bgColor = "bg-amber-50 dark:bg-amber-950/80 text-amber-900 dark:text-amber-100 border-amber-200 dark:border-amber-800";
        iconSvg = `<svg class="w-5 h-5 text-amber-600 dark:text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>`;
    }

    toast.className += ` ${bgColor}`;
    toast.innerHTML = `
        <div class="shrink-0 mt-0.5">${iconSvg}</div>
        <div class="flex-1 text-sm leading-relaxed">
            ${title ? `<div class="font-bold mb-0.5">${title}</div>` : ""}
            <div>${message}</div>
        </div>
        <button onclick="this.parentElement.remove()" class="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 shrink-0">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
        </button>
    `;

    container.appendChild(toast);
    setTimeout(() => toast.classList.add("show"), 10);

    setTimeout(() => {
        toast.classList.remove("show");
        setTimeout(() => toast.remove(), 350);
    }, 4500);
}

// Helpers
function formatPhone(phone) {
    if (!phone) return "";
    const clean = phone.replace(/\D/g, "");
    if (clean.length === 12 && clean.startsWith("998")) {
        return `+998 (${clean.slice(3,5)}) ${clean.slice(5,8)}-${clean.slice(8,10)}-${clean.slice(10,12)}`;
    }
    return phone;
}

function maskPINFL(pinfl) {
    if (!pinfl || pinfl.length !== 14) return pinfl;
    return `${pinfl.slice(0, 6)}******${pinfl.slice(12, 14)}`;
}
