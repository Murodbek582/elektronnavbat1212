// Administrator Control Center Controller

let currentAdminTab = "queue";
let cachedDoctorsList = [];
let cachedDepartmentsList = [];

async function loadAdminDashboard() {
    const container = document.getElementById("adminSectionContent");
    if (!container) return;

    const token = localStorage.getItem("poliklinika_token");
    const userStr = localStorage.getItem("poliklinika_user");
    
    let isAdmin = false;
    if (userStr) {
        try {
            const u = JSON.parse(userStr);
            isAdmin = u.role === "admin";
        } catch (e) {}
    }

    if (!token || !isAdmin) {
        container.innerHTML = `
            <div class="min-h-[80vh] flex items-center justify-center py-12 px-4">
                <div class="w-full max-w-md">
                    <!-- Background decorations -->
                    <div class="relative">
                        <div class="absolute -top-20 -right-20 w-56 h-56 bg-indigo-500/8 rounded-full blur-3xl pointer-events-none"></div>
                        <div class="absolute -bottom-20 -left-20 w-56 h-56 bg-blue-500/8 rounded-full blur-3xl pointer-events-none"></div>

                        <div class="relative rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl overflow-hidden">
                            <!-- Top accent bar -->
                            <div class="h-1.5 bg-gradient-to-r from-indigo-500 via-blue-500 to-purple-500"></div>

                            <div class="p-8">
                                <!-- Logo & Title -->
                                <div class="text-center mb-8">
                                    <div class="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-indigo-600 to-blue-600 text-white flex items-center justify-center shadow-lg shadow-indigo-500/30">
                                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                                        </svg>
                                    </div>
                                    <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 mb-3 border border-indigo-200 dark:border-indigo-900">
                                        <span class="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
                                        Ma'muriyat Tizimi
                                    </div>
                                    <h2 class="text-2xl font-black text-slate-900 dark:text-white mt-2">Admin Paneliga Kirish</h2>
                                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-1.5 leading-relaxed">
                                        Faqat vakolatli xodimlar uchun. Login va parolni kiriting.
                                    </p>
                                </div>

                                <!-- Login Form -->
                                <form onsubmit="submitAdminLogin(event)" class="space-y-4" autocomplete="off">
                                    <!-- Error message box -->
                                    <div id="adminLoginError" class="hidden p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2.5">
                                        <svg class="w-4 h-4 shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                        </svg>
                                        <span id="adminLoginErrorText"></span>
                                    </div>

                                    <!-- Username field -->
                                    <div>
                                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                                            Login (Email yoki Telefon)
                                        </label>
                                        <div class="relative">
                                            <div class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                                                </svg>
                                            </div>
                                            <input id="adminLoginUsername" type="text"
                                                placeholder="admin@poliklinika.uz"
                                                class="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                                                autocomplete="username" required/>
                                        </div>
                                    </div>

                                    <!-- Password field -->
                                    <div>
                                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                                            Parol
                                        </label>
                                        <div class="relative">
                                            <div class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                                                </svg>
                                            </div>
                                            <input id="adminLoginPassword" type="password"
                                                placeholder="••••••••"
                                                class="w-full pl-10 pr-11 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                                                autocomplete="current-password" required/>
                                            <button type="button" onclick="toggleAdminPasswordVisibility()" class="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition" tabindex="-1">
                                                <svg id="adminEyeIcon" class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Submit button -->
                                    <button type="submit" id="adminLoginBtn"
                                        class="w-full py-3.5 px-5 mt-2 rounded-2xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-bold text-sm shadow-lg shadow-indigo-600/25 active:scale-[0.98] transition flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed">
                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"/>
                                        </svg>
                                        <span>Kirish</span>
                                    </button>
                                </form>

                                <!-- Footer -->
                                <div class="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                                    <button onclick="showSection('patient')" class="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-1">
                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
                                        Bemor portaliga qaytish
                                    </button>
                                    <div class="flex items-center gap-1.5 text-[11px] text-slate-400">
                                        <svg class="w-3.5 h-3.5 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                                        Himoyalangan ulanish
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Auto-focus username field
        setTimeout(() => {
            const inp = document.getElementById('adminLoginUsername');
            if (inp) inp.focus();
        }, 100);

        return;
    }

    try {
        await Promise.all([loadAdminMetrics(), loadDepartmentsAndDoctors()]);
        renderAdminDashboardLayout();
        switchAdminTab(currentAdminTab);
    } catch (err) {
        container.innerHTML = `<div class="p-8 text-center text-rose-500 text-sm">${err.message}</div>`;
    }
}

async function submitAdminLogin(e) {
    e.preventDefault();

    const username = document.getElementById('adminLoginUsername')?.value.trim();
    const password = document.getElementById('adminLoginPassword')?.value.trim();
    const errorBox = document.getElementById('adminLoginError');
    const errorText = document.getElementById('adminLoginErrorText');
    const btn = document.getElementById('adminLoginBtn');

    // Clear previous error
    if (errorBox) errorBox.classList.add('hidden');

    if (!username || !password) {
        if (errorText) errorText.textContent = "Login va parolni to'liq kiriting.";
        if (errorBox) errorBox.classList.remove('hidden');
        return;
    }

    // Show loading state
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<svg class="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/></svg><span>Tekshirilmoqda...</span>`;
    }

    try {
        const res = await apiCall("/api/auth/login", "POST", { username, password });

        if (res.user.role !== 'admin') {
            if (errorText) errorText.textContent = "Bu hisob administrator huquqiga ega emas. Faqat adminlar kira oladi.";
            if (errorBox) errorBox.classList.remove('hidden');
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"/></svg><span>Kirish</span>`;
            }
            return;
        }

        localStorage.setItem("poliklinika_token", res.access_token);
        localStorage.setItem("poliklinika_user", JSON.stringify(res.user));
        updateAuthUI();
        showToast("Administrator boshqaruv markaziga xush kelibsiz, " + res.user.full_name + "!", "success");
        loadAdminDashboard();

    } catch (err) {
        const msg = err.message || "Login yoki parol noto'g'ri.";
        if (errorText) errorText.textContent = msg;
        if (errorBox) errorBox.classList.remove('hidden');
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"/></svg><span>Kirish</span>`;
        }
    }
}

function toggleAdminPasswordVisibility() {
    const inp = document.getElementById('adminLoginPassword');
    const icon = document.getElementById('adminEyeIcon');
    if (!inp) return;
    if (inp.type === 'password') {
        inp.type = 'text';
        if (icon) icon.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>`;
    } else {
        inp.type = 'password';
        if (icon) icon.innerHTML = `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>`;
    }
}

async function loadDepartmentsAndDoctors() {
    try {
        const [dRes, docRes] = await Promise.all([
            apiCall("/api/departments"),
            apiCall("/api/doctors")
        ]);
        cachedDepartmentsList = dRes.departments || [];
        cachedDoctorsList = docRes.doctors || [];
    } catch (e) {
        console.error("Cache load error:", e);
    }
}

async function loadAdminMetrics() {
    try {
        const res = await apiCall("/api/analytics/dashboard");
        renderAdminMetricsUI(res.metrics);
    } catch (e) {
        console.error("Metrics load error:", e);
    }
}

function renderAdminMetricsUI(metrics) {
    const el = document.getElementById("adminMetricsGrid");
    if (!el || !metrics) return;

    const cards = [
        {
            label: t("stat_total_patients") || "Jami Bemorlar",
            value: metrics.total_patients,
            sub: "Ro'yxatga olingan fuqarolar",
            icon: `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"/>`,
            color: "blue",
            bg: "from-blue-500 to-blue-700",
            ring: "ring-blue-500/20",
        },
        {
            label: t("stat_today_appts") || "Bugungi Qabullar",
            value: metrics.today_total,
            sub: `Kutmoqda: ${metrics.today_waiting} &nbsp;•&nbsp; Qabulda: ${metrics.today_serving}`,
            icon: `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>`,
            color: "emerald",
            bg: "from-emerald-500 to-teal-600",
            ring: "ring-emerald-500/20",
        },
        {
            label: t("stat_active_doctors") || "Faol Shifokorlar",
            value: metrics.total_doctors,
            sub: "10 ta asosiy mutaxassislik",
            icon: `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>`,
            color: "violet",
            bg: "from-violet-500 to-indigo-600",
            ring: "ring-violet-500/20",
        },
        {
            label: t("stat_avg_wait") || "O'rtacha Kutish",
            value: `${metrics.avg_waiting_time_minutes} daq`,
            sub: "Talon bo'yicha hisoblangan",
            icon: `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>`,
            color: "amber",
            bg: "from-amber-500 to-orange-500",
            ring: "ring-amber-500/20",
        },
    ];

    el.innerHTML = cards.map(c => `
        <div class="relative overflow-hidden p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-lg transition-all group cursor-default ring-1 ring-transparent hover:${c.ring}">
            <div class="absolute -top-6 -right-6 w-20 h-20 rounded-full bg-gradient-to-br ${c.bg} opacity-5 group-hover:opacity-10 transition-all scale-100 group-hover:scale-150"></div>
            <div class="flex items-start justify-between mb-4">
                <div class="text-[11px] text-slate-500 dark:text-slate-400 uppercase font-black tracking-wider leading-tight">${c.label}</div>
                <div class="w-9 h-9 rounded-xl bg-gradient-to-br ${c.bg} flex items-center justify-center shadow-md shrink-0">
                    <svg class="w-4.5 h-4.5 w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">${c.icon}</svg>
                </div>
            </div>
            <div class="text-3xl font-black mono text-slate-900 dark:text-white mb-1">${c.value}</div>
            <div class="text-[11px] text-slate-400 dark:text-slate-500">${c.sub}</div>
        </div>
    `).join('');
}

function renderAdminDashboardLayout() {
    const container = document.getElementById("adminSectionContent");
    if (!container) return;

    // Tab definitions: [id, icon, label]
    const TABS = [
        ["queue",          "🎯", "Navbat"],
        ["monitoring",     "🖥️", "Monitoring"],
        ["patients",       "👥", "Bemorlar"],
        ["doctors",        "🩺", "Shifokorlar"],
        ["departments",    "🏥", "Bo'limlar"],
        ["appointments",   "📅", "Qabullar"],
        ["analytics",      "📊", "Tahlil"],
        ["announcements",  "📢", "E'lonlar"],
        ["reviews",        "⭐", "Sharhlar"],
        ["users",          "👤", "Foydalanuvchilar"],
        ["settings",       "⚙️", "Sozlamalar"],
        ["audit",          "📜", "Audit"],
        ["ai",             "🤖", "AI Yordamchi"],
        ["financial",      "💰", "Moliya"],
        ["services",       "🔬", "Xizmatlar"],
        ["backups",        "💾", "Zaxira"],
    ];

    const userStr = localStorage.getItem("poliklinika_user");
    let adminName = "Administrator";
    try { adminName = JSON.parse(userStr).full_name; } catch(e) {}

    const now = new Date();
    const timeStr = now.toLocaleTimeString('uz-UZ', {hour:'2-digit', minute:'2-digit'});
    const dateStr = now.toLocaleDateString('uz-UZ', {weekday:'long', day:'numeric', month:'long', year:'numeric'});

    container.innerHTML = `
        <div class="flex flex-col gap-0 -mx-4 sm:-mx-6 lg:-mx-8 -mt-8">

            <!-- ═══ TOP ADMIN HEADER ═══ -->
            <div class="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 px-6 py-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-indigo-900/60 shadow-xl">
                <div class="flex items-center gap-4">
                    <!-- Shield Logo -->
                    <div class="w-11 h-11 rounded-2xl bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center shadow-lg shadow-indigo-500/30 shrink-0">
                        <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                        </svg>
                    </div>
                    <div>
                        <div class="flex items-center gap-2 flex-wrap">
                            <h1 class="text-lg font-black text-white tracking-tight">Boshqaruv Markazi</h1>
                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/25">
                                <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                                Faol
                            </span>
                        </div>
                        <p class="text-xs text-indigo-200 mt-0.5">Xush kelibsiz, <span class="font-bold text-white">${adminName}</span> &nbsp;•&nbsp; ${dateStr}</p>
                    </div>
                </div>
                <div class="flex items-center gap-2 flex-wrap">
                    <div class="px-3 py-1.5 rounded-xl bg-white/8 border border-white/10 text-white text-xs font-mono font-bold">${timeStr}</div>
                    <button onclick="loadAdminDashboard()" title="Yangilash"
                        class="p-2 rounded-xl bg-white/8 hover:bg-white/15 border border-white/10 text-white transition" >
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                    </button>
                    <button onclick="showSection('patient')"
                        class="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-sm shadow-blue-700/40">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                        Bemor portali
                    </button>
                    <button onclick="logoutUser()"
                        class="px-3 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/25 text-xs font-bold transition flex items-center gap-1.5">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
                        Chiqish
                    </button>
                </div>
            </div>

            <!-- ═══ METRICS ROW ═══ -->
            <div class="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 px-6 py-5">
                <div id="adminMetricsGrid" class="grid grid-cols-2 lg:grid-cols-4 gap-4"></div>
            </div>

            <!-- ═══ SIDEBAR + CONTENT LAYOUT ═══ -->
            <div class="flex min-h-[600px] bg-slate-50 dark:bg-slate-950">

                <!-- Sidebar Navigation -->
                <aside class="w-56 shrink-0 hidden md:flex flex-col border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-4 gap-0.5 overflow-y-auto">
                    ${TABS.map(([id, icon, label]) => `
                        <button onclick="switchAdminTab('${id}')" id="adminTabBtn-${id}"
                            class="admin-sidebar-btn w-full flex items-center gap-3 px-4 py-2.5 text-sm font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-white transition-all text-left rounded-none">
                            <span class="text-base w-5 text-center">${icon}</span>
                            <span class="truncate">${label}</span>
                        </button>
                    `).join('')}

                    <div class="mt-auto px-4 pt-4 pb-2 border-t border-slate-100 dark:border-slate-800">
                        <button onclick="resetDailyQueueConfirmation()"
                            class="w-full flex items-center gap-2 px-3 py-2 rounded-xl border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs font-bold hover:bg-rose-100 dark:hover:bg-rose-900/60 transition">
                            <svg class="w-3.5 h-3.5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                            ${t("reset_queue_btn") || "Navbatni tiklash"}
                        </button>
                    </div>
                </aside>

                <!-- Mobile tab strip -->
                <div class="md:hidden flex overflow-x-auto gap-1 px-4 py-3 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 w-full absolute" style="display:none">
                </div>

                <!-- Main content area -->
                <div class="flex-1 overflow-auto">
                    <!-- Mobile tabs scroll -->
                    <div class="md:hidden flex overflow-x-auto gap-1.5 px-4 py-3 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                        ${TABS.map(([id, icon, label]) => `
                            <button onclick="switchAdminTab('${id}')" id="adminTabBtnMob-${id}"
                                class="admin-mob-btn flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 whitespace-nowrap transition">
                                ${icon} ${label}
                            </button>
                        `).join('')}
                    </div>

                    <!-- Dynamic pane -->
                    <div id="adminTabPane" class="p-6 min-h-[500px]"></div>
                </div>
            </div>

        </div>
    `;

    loadAdminMetrics();
}

function switchAdminTab(tabName) {
    currentAdminTab = tabName;

    // ── Sidebar buttons (desktop) ──
    document.querySelectorAll(".admin-sidebar-btn").forEach(btn => {
        btn.className = "admin-sidebar-btn w-full flex items-center gap-3 px-4 py-2.5 text-sm font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-white transition-all text-left";
    });
    const activeSidebar = document.getElementById(`adminTabBtn-${tabName}`);
    if (activeSidebar) {
        activeSidebar.className = "admin-sidebar-btn w-full flex items-center gap-3 px-4 py-2.5 text-sm font-bold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border-r-2 border-indigo-500 text-left";
    }

    // ── Mobile pill buttons ──
    document.querySelectorAll(".admin-mob-btn").forEach(btn => {
        btn.className = "admin-mob-btn flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 whitespace-nowrap transition";
    });
    const activeMob = document.getElementById(`adminTabBtnMob-${tabName}`);
    if (activeMob) {
        activeMob.className = "admin-mob-btn flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold bg-indigo-600 text-white whitespace-nowrap transition";
    }

    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    if (tabName === "queue") loadAdminQueue();
    else if (tabName === "ai") loadAdminAI();
    else if (tabName === "monitoring") loadAdminMonitoring();
    else if (tabName === "patients") loadAdminPatients();
    else if (tabName === "doctors") loadAdminDoctors();
    else if (tabName === "departments") loadAdminDepartments();
    else if (tabName === "appointments") loadAdminAppointments();
    else if (tabName === "analytics") loadAdminAnalytics();
    else if (tabName === "financial") loadAdminFinancial();
    else if (tabName === "services") loadAdminServicesTab();
    else if (tabName === "knowledge_base") loadAdminKnowledgeBase();
    else if (tabName === "announcements") loadAdminAnnouncements();
    else if (tabName === "reviews") loadAdminReviews();
    else if (tabName === "users") loadAdminUsers();
    else if (tabName === "roles") loadAdminRoles();
    else if (tabName === "backups") loadAdminBackups();
    else if (tabName === "settings") loadAdminSettings();
    else if (tabName === "audit") loadAdminAudit();
    else if (tabName === "sms") loadAdminSMS();
}

// 1. Tab A: Queue Control
async function loadAdminQueue() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-sm">Navbat ro'yxati yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/queue/live");
        const active = res.active_calls || [];
        const waiting = res.waiting_tickets || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <!-- Action Bar -->
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h3 class="text-base font-bold text-slate-800 dark:text-slate-100">Jonli Navbat Boshqaruvi</h3>
                        <p class="text-xs text-slate-500">Bugungi navbatdagi bemorlarni chaqirish, qabulni yakunlash yoki bekor qilish</p>
                    </div>
                    <div class="flex items-center gap-3">
                        <button onclick="adminCallNextAny()" class="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow flex items-center gap-2">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"></path></svg>
                            <span>${t("call_next_btn")} (Navbatdagi)</span>
                        </button>
                    </div>
                </div>

                <!-- Currently Active Calls -->
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h4 class="font-bold text-sm text-slate-800 dark:text-slate-200 mb-4 flex items-center gap-2">
                        <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 live-pulse"></span>
                        Ayni damda xonalarga chaqirilganlar (${active.length})
                    </h4>

                    ${active.length === 0 ? `
                        <div class="p-6 text-center text-slate-400 text-xs">Hozirda xonalarda faol qabul qilinayotgan bemorlar yo'q.</div>
                    ` : `
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            ${active.map(c => `
                                <div class="p-4 rounded-2xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50/50 dark:bg-emerald-950/20 flex flex-col justify-between">
                                    <div>
                                        <div class="flex items-center justify-between mb-2">
                                            <span class="font-black mono text-2xl text-emerald-700 dark:text-emerald-300">${c.ticket_number}</span>
                                            <span class="px-2.5 py-1 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 text-xs font-bold mono">
                                                ${c.room_number}-XONA
                                            </span>
                                        </div>
                                        <div class="font-bold text-sm text-slate-800 dark:text-slate-100">${c.patient_name}</div>
                                        <div class="text-xs text-slate-500 mt-0.5">${c.doctor_name} (${c.department_name})</div>
                                    </div>
                                    <div class="mt-4 pt-3 border-t border-emerald-200 dark:border-emerald-800/80 flex items-center justify-end gap-2">
                                        <button onclick="adminMarkAbsent(${c.appointment_id})" class="px-2.5 py-1 rounded-lg text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 text-xs font-semibold">
                                            Kelmadi
                                        </button>
                                        <button onclick="adminComplete(${c.appointment_id})" class="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold">
                                            Yakunlash ✓
                                        </button>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    `}
                </div>

                <!-- Waiting Queue List -->
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h4 class="font-bold text-sm text-slate-800 dark:text-slate-200 mb-4">
                        Kutayotgan bemorlar ro'yxati (${waiting.length})
                    </h4>

                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs">
                            <thead>
                                <tr class="border-b border-slate-100 dark:border-slate-800 text-slate-400 uppercase font-bold">
                                    <th class="pb-3">Talon</th>
                                    <th class="pb-3">Vaqt</th>
                                    <th class="pb-3">Bemor</th>
                                    <th class="pb-3">Shifokor / Bo'lim</th>
                                    <th class="pb-3">Xona</th>
                                    <th class="pb-3 text-right">Amal</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                                ${waiting.length === 0 ? `
                                    <tr>
                                        <td colspan="6" class="py-6 text-center text-slate-400">Hozircha kutayotgan navbatlar yo'q.</td>
                                    </tr>
                                ` : waiting.map(w => `
                                    <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                        <td class="py-3 font-black mono text-emerald-600 dark:text-emerald-400 text-sm">${w.ticket_number}</td>
                                        <td class="py-3 mono text-slate-500">${w.start_time}</td>
                                        <td class="py-3 font-semibold text-slate-800 dark:text-slate-200">${w.patient_name}</td>
                                        <td class="py-3 text-slate-500">${w.doctor_name} <span class="text-slate-400">(${w.department_name})</span></td>
                                        <td class="py-3 font-bold mono text-amber-600">${w.room_number}-xona</td>
                                        <td class="py-3 text-right">
                                            <button onclick="adminCallSpecificDoctor(${w.doctor_id})" class="px-3 py-1 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 font-bold hover:bg-emerald-100 text-xs">
                                                Chaqirish
                                            </button>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

async function adminCallNextAny() {
    try {
        const res = await apiCall("/api/queue/call-next", "POST", {});
        showToast(res.message, "success");
        loadAdminQueue();
        loadAdminMetrics();
    } catch (err) {
        showToast(err.message, "warning");
    }
}

async function adminCallSpecificDoctor(doctorId) {
    try {
        const res = await apiCall("/api/queue/call-next", "POST", { doctor_id: doctorId });
        showToast(res.message, "success");
        loadAdminQueue();
        loadAdminMetrics();
    } catch (err) {
        showToast(err.message, "warning");
    }
}

async function adminComplete(appointmentId) {
    try {
        const res = await apiCall(`/api/queue/complete/${appointmentId}`, "POST", {
            notes: "Administrator tomonidan yakunlandi"
        });
        showToast(res.message, "success");
        loadAdminQueue();
        loadAdminMetrics();
    } catch (err) {
        showToast(err.message, "error");
    }
}

async function adminMarkAbsent(appointmentId) {
    if (!confirm("Bemor qabulga kelmadi deb belgilansinmi?")) return;
    try {
        const res = await apiCall(`/api/queue/absent/${appointmentId}`, "POST", {});
        showToast(res.message, "info");
        loadAdminQueue();
        loadAdminMetrics();
    } catch (err) {
        showToast(err.message, "error");
    }
}

async function resetDailyQueueConfirmation() {
    const confirmation = prompt("DIQQAT! Bugungi barcha demo navbatlar tozalanadi. Tasdiqlash uchun 'RESET' deb yozing:");
    if (confirmation !== "RESET") {
        showToast("Tozalash bekor qilindi.", "info");
        return;
    }

    try {
        const res = await apiCall("/api/queue/reset-day", "POST", {});
        showToast(res.message, "success");
        loadAdminQueue();
        loadAdminMetrics();
    } catch (err) {
        showToast(err.message, "error");
    }
}

// 2. Tab B: Doctor Management (CRUD)
async function loadAdminDoctors() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-sm">Shifokorlar ro'yxati yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/doctors");
        const doctors = res.doctors || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-base font-bold text-slate-800 dark:text-slate-100">Poliklinika Shifokorlari (${doctors.length})</h3>
                        <p class="text-xs text-slate-500">Mutaxassislarni boshqarish, yangi shifokor qo'shish va xonalarni biriktirish</p>
                    </div>
                    <button onclick="openAddDoctorModal()" class="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow flex items-center gap-2">
                        <span>+ Yangi shifokor qo'shish</span>
                    </button>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    ${doctors.map(d => `
                        <div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border ${d.is_active ? 'border-slate-200 dark:border-slate-800' : 'border-rose-200 dark:border-rose-900 opacity-60'} shadow-sm flex flex-col justify-between">
                            <div>
                                <div class="flex items-center justify-between mb-3">
                                    <span class="px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 font-bold text-xs mono">
                                        ${d.room_number}-XONA
                                    </span>
                                    <span class="text-[11px] font-bold ${d.is_active ? 'text-emerald-600' : 'text-rose-500'}">
                                        ${d.is_active ? 'Faol' : 'Nofaol'}
                                    </span>
                                </div>
                                <div class="flex items-center gap-3 mb-3">
                                    <img src="${d.photo_url || 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=120'}"
                                         class="w-12 h-12 rounded-xl object-cover border border-slate-200 dark:border-slate-700 shrink-0">
                                    <div>
                                        <div class="font-bold text-sm text-slate-800 dark:text-slate-100">${d.full_name}</div>
                                        <div class="text-xs text-blue-600 dark:text-blue-400 font-medium">${d.specialization_uz}</div>
                                    </div>
                                </div>
                                <div class="text-xs text-slate-500 space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
                                    <div>Bo'lim: <b class="text-slate-700 dark:text-slate-300">${d.department_name_uz}</b></div>
                                    <div>Qabul vaqti: <b class="text-slate-700 dark:text-slate-300">${d.start_time} - ${d.end_time}</b> (har biri ${d.appointment_duration} daq)</div>
                                </div>
                            </div>
                            <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                                <button onclick="toggleDoctorStatus(${d.id}, ${d.is_active ? 0 : 1})" class="px-2.5 py-1 rounded-lg text-xs font-semibold ${d.is_active ? 'text-rose-600 hover:bg-rose-50' : 'text-emerald-600 hover:bg-emerald-50'}">
                                    ${d.is_active ? 'Nofaol qilish' : 'Faollashtirish'}
                                </button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

async function toggleDoctorStatus(doctorId, newStatus) {
    try {
        await apiCall(`/api/doctors/${doctorId}`, "PUT", { is_active: Boolean(newStatus) });
        showToast("Shifokor holati yangilandi", "success");
        loadAdminDoctors();
    } catch (err) {
        showToast(err.message, "error");
    }
}

// 3. Tab C: All Appointments Master View with Filter & Search
async function loadAdminAppointments() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `
        <div class="space-y-6">
            <!-- Filter & Search Bar -->
            <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-3">
                    <input id="apptFilterSearch" type="text" placeholder="${t('search_placeholder')}"
                           class="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs">
                    <input id="apptFilterDate" type="date" value="${new Date().toISOString().split('T')[0]}"
                           class="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs">
                    <select id="apptFilterStatus" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs">
                        <option value="">Barcha holatlar</option>
                        <option value="waiting">Kutilmoqda</option>
                        <option value="in_consultation">Qabulda</option>
                        <option value="completed">Tugallangan</option>
                        <option value="cancelled">Bekor qilingan</option>
                        <option value="absent">Kelmadi</option>
                    </select>
                    <button onclick="fetchFilteredAppointments()" class="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs">
                        Qidirish va Filtrlash
                    </button>
                </div>
            </div>

            <!-- Appointments Table Container -->
            <div id="appointmentsTableContainer" class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                <div class="text-center text-slate-400 text-xs py-8">Yuklanmoqda...</div>
            </div>
        </div>
    `;

    fetchFilteredAppointments();
}

async function fetchFilteredAppointments() {
    const tableContainer = document.getElementById("appointmentsTableContainer");
    if (!tableContainer) return;

    const search = document.getElementById("apptFilterSearch")?.value || "";
    const date = document.getElementById("apptFilterDate")?.value || "";
    const status = document.getElementById("apptFilterStatus")?.value || "";

    let url = `/api/appointments?limit=100`;
    if (search) url += `&search=${encodeURIComponent(search)}`;
    if (date) url += `&date=${date}`;
    if (status) url += `&status=${status}`;

    try {
        const res = await apiCall(url);
        const list = res.appointments || [];

        tableContainer.innerHTML = `
            <div class="flex items-center justify-between mb-4">
                <div class="font-bold text-xs text-slate-500 uppercase">Topilgan qabullar: ${list.length} ta</div>
                <button onclick="exportAppointmentsCSV()" class="px-3.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-xs hover:bg-emerald-100 flex items-center gap-1.5 border border-emerald-200 dark:border-emerald-800">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    <span>${t("export_csv_btn")}</span>
                </button>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="border-b border-slate-100 dark:border-slate-800 text-slate-400 uppercase font-bold">
                            <th class="pb-3">Talon</th>
                            <th class="pb-3">Sana / Vaqt</th>
                            <th class="pb-3">Bemor F.I.Sh</th>
                            <th class="pb-3">JShShIR</th>
                            <th class="pb-3">Shifokor</th>
                            <th class="pb-3">Xona</th>
                            <th class="pb-3">Holat</th>
                            <th class="pb-3 text-right">Talon</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                        ${list.length === 0 ? `
                            <tr><td colspan="8" class="py-8 text-center text-slate-400">Ko'rsatilgan filtr bo'yicha qabullar topilmadi.</td></tr>
                        ` : list.map(a => `
                            <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                <td class="py-3 font-black mono text-emerald-600 dark:text-emerald-400 text-sm">${a.ticket_number || a.appointment_number}</td>
                                <td class="py-3 mono text-slate-500">${a.appointment_date}<br>${a.start_time} - ${a.end_time}</td>
                                <td class="py-3">
                                    <div class="font-semibold text-slate-800 dark:text-slate-100">${a.patient_name}</div>
                                    <div class="text-[11px] text-slate-400">${a.patient_phone}</div>
                                </td>
                                <td class="py-3 mono text-slate-500">${maskPINFL(a.patient_pinfl)}</td>
                                <td class="py-3 text-slate-700 dark:text-slate-300 font-medium">${a.doctor_name}<br><span class="text-slate-400 text-[11px]">${a.department_name}</span></td>
                                <td class="py-3 font-bold mono text-amber-600">${a.room_number}-xona</td>
                                <td class="py-3">
                                    <span class="px-2.5 py-1 rounded-full text-[11px] font-bold ${
                                        a.status === 'in_consultation' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' :
                                        a.status === 'waiting' ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300' :
                                        a.status === 'completed' ? 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300' :
                                        'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                    }">
                                        ${a.status}
                                    </span>
                                </td>
                                <td class="py-3 text-right">
                                    <button onclick="openTicketModal(${a.id})" class="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 font-bold hover:bg-slate-100 text-[11px]">
                                        Ko'rish
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (err) {
        tableContainer.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

function exportAppointmentsCSV() {
    const token = localStorage.getItem("poliklinika_token");
    const date = document.getElementById("apptFilterDate")?.value || "";
    let url = `/api/analytics/export/csv`;
    if (date) url += `?start_date=${date}&end_date=${date}`;
    
    // Direct download trigger with bearer auth in header or link
    fetch(url, { headers: { "Authorization": `Bearer ${token}` } })
        .then(res => res.blob())
        .then(blob => {
            const downloadUrl = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = downloadUrl;
            a.download = `poliklinika_navbat_hisoboti_${new Date().toISOString().split('T')[0]}.csv`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            showToast("Excel hisoboti muvaffaqiyatli yuklab olindi!", "success");
        })
        .catch(err => showToast("Eksport xatosi: " + err.message, "error"));
}

// 4. Tab D: Analytics & Reports
async function loadAdminAnalytics() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-sm">Tahliliy hisobotlar yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/analytics/dashboard");
        const popDocs = res.popular_doctors || [];
        const deptDist = res.department_distribution || [];
        const dailyTrend = res.daily_trend || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <!-- Top Header & Export -->
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-base font-bold text-slate-800 dark:text-slate-100">Poliklinika Analitikasi va Hisobotlari</h3>
                        <p class="text-xs text-slate-500">Qabullar statistikasi, talab yuqori bo'lgan mutaxassislar va oylik dinamika</p>
                    </div>
                    <button onclick="exportAppointmentsCSV()" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-2 shadow">
                        <span>Hisobotni yuklab olish (.CSV)</span>
                    </button>
                </div>

                <!-- Visual Trend Bars -->
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h4 class="font-bold text-sm text-slate-800 dark:text-slate-200 mb-6">Oxirgi kunlardagi qabullar hajmi</h4>
                    <div class="flex items-end gap-3 h-48 pt-6 pb-2 border-b border-slate-200 dark:border-slate-800">
                        ${dailyTrend.length === 0 ? `
                            <div class="w-full text-center text-slate-400 text-xs self-center">Ma'lumotlar to'planmoqda...</div>
                        ` : dailyTrend.map(d => {
                            const height = Math.min(100, Math.max(15, (d.total * 25)));
                            return `
                                <div class="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                                    <div class="text-[11px] font-bold text-blue-600 dark:text-blue-400 mono">${d.total}</div>
                                    <div class="w-full max-w-[48px] bg-blue-500 dark:bg-blue-600 rounded-t-xl transition-all group-hover:bg-blue-400"
                                         style="height: ${height}%;"></div>
                                    <div class="text-[10px] text-slate-400 truncate max-w-[60px]">${d.date.slice(5)}</div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>

                <!-- Grid: Popular Doctors & Department Distribution -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                        <h4 class="font-bold text-sm text-slate-800 dark:text-slate-200 mb-4">Eng ko'p murojaat qilingan shifokorlar</h4>
                        <div class="space-y-3">
                            ${popDocs.map((d, i) => `
                                <div class="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                                    <div class="flex items-center gap-3">
                                        <span class="w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 text-xs font-bold flex items-center justify-center">
                                            #${i + 1}
                                        </span>
                                        <div>
                                            <div class="font-bold text-xs text-slate-800 dark:text-slate-100">${d.full_name}</div>
                                            <div class="text-[11px] text-slate-400">${d.specialization_uz} • ${d.room_number}-xona</div>
                                        </div>
                                    </div>
                                    <span class="font-black mono text-sm text-blue-600 dark:text-blue-400">${d.total_appointments} qabul</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>

                    <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                        <h4 class="font-bold text-sm text-slate-800 dark:text-slate-200 mb-4">Bo'limlar bo'yicha taqsimot</h4>
                        <div class="space-y-3">
                            ${deptDist.map(dep => `
                                <div>
                                    <div class="flex justify-between text-xs font-bold mb-1">
                                        <span class="text-slate-700 dark:text-slate-300">${dep.name_uz} (${dep.code})</span>
                                        <span class="mono text-slate-500">${dep.appointment_count} ta</span>
                                    </div>
                                    <div class="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                                        <div class="bg-teal-500 h-full rounded-full" style="width: ${Math.min(100, (dep.appointment_count * 15))}%"></div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

// 5. Tab E: Honest SMS Gateway Status
async function loadAdminSMS() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-sm">SMS shlyuzi holati yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/notifications/sms-status");
        const logs = res.recent_sms_logs || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <!-- Status Notice Banner -->
                <div class="p-6 rounded-3xl border border-amber-300 dark:border-amber-800/80 bg-amber-50/70 dark:bg-amber-950/30">
                    <div class="flex items-start gap-4">
                        <div class="w-10 h-10 rounded-xl bg-amber-200 dark:bg-amber-900 text-amber-800 dark:text-amber-200 flex items-center justify-center shrink-0">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        </div>
                        <div>
                            <div class="flex items-center gap-2 mb-1">
                                <h4 class="font-bold text-sm text-amber-900 dark:text-amber-200">SMS Xabarnomalar Holati:</h4>
                                <span class="px-2.5 py-0.5 rounded-full bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-100 font-bold text-xs uppercase">
                                    ${res.active_provider.toUpperCase()} REJIMI
                                </span>
                            </div>
                            <p class="text-xs text-amber-800 dark:text-amber-300 leading-relaxed">${res.description}</p>
                            <p class="text-xs text-amber-800 dark:text-amber-300 mt-2">
                                <b>Eslatma:</b> Haqiqiy SMS yuborish uchun quyida O'zbekistondagi rasmiy provayder (Eskiz.uz yoki PlayMobile) tokenlarini ulashingiz mumkin.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Gateway Configuration Form -->
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
                    <h4 class="font-bold text-sm text-slate-800 dark:text-slate-100">SMS Provayder Sozlamalari</h4>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">Provayder</label>
                            <select id="smsProviderSelect" class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs">
                                <option value="demo" ${res.active_provider === 'demo' ? 'selected' : ''}>Demo Simulyatsiya Shlyuzi</option>
                                <option value="eskiz" ${res.active_provider === 'eskiz' ? 'selected' : ''}>Eskiz.uz API</option>
                                <option value="playmobile" ${res.active_provider === 'playmobile' ? 'selected' : ''}>PlayMobile SMPP / HTTP</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">API Kalit / Token</label>
                            <input id="smsApiKeyInput" type="password" placeholder="Provayder API Tokeni..."
                                   class="w-full px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs">
                        </div>
                        <div class="flex items-end">
                            <button onclick="saveSMSConfig()" class="w-full py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs">
                                Saqlash
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Recent Simulated SMS Table -->
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h4 class="font-bold text-sm text-slate-800 dark:text-slate-100 mb-4">Oxirgi yuborilgan / simulyatsiya qilingan SMS xabarlar</h4>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs">
                            <thead>
                                <tr class="border-b border-slate-100 dark:border-slate-800 text-slate-400 uppercase font-bold">
                                    <th class="pb-3">Vaqt</th>
                                    <th class="pb-3">Qabul qiluvchi</th>
                                    <th class="pb-3">Xabar matni</th>
                                    <th class="pb-3">Holat</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                                ${logs.length === 0 ? `
                                    <tr><td colspan="4" class="py-6 text-center text-slate-400">SMS xabarlar qaydnomasi bo'sh.</td></tr>
                                ` : logs.map(s => `
                                    <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                        <td class="py-3 mono text-slate-400">${s.created_at}</td>
                                        <td class="py-3 font-semibold text-slate-800 dark:text-slate-200">${s.recipient_phone}<br><span class="text-slate-400 text-[10px]">${s.full_name}</span></td>
                                        <td class="py-3 text-slate-600 dark:text-slate-300 max-w-xs">${s.message}</td>
                                        <td class="py-3">
                                            <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                                                ${s.delivery_status}
                                            </span>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

async function saveSMSConfig() {
    const provider = document.getElementById("smsProviderSelect")?.value || "demo";
    const apiKey = document.getElementById("smsApiKeyInput")?.value || "";

    try {
        const res = await apiCall("/api/notifications/sms-config", "POST", {
            provider,
            api_key: apiKey
        });
        showToast(res.message, "success");
        loadAdminSMS();
    } catch (err) {
        showToast(err.message, "error");
    }
}

// 6. Tab F: Audit Logs
async function loadAdminAudit() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-sm">Xavfsizlik qaydnomasi yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/audit-logs?limit=50");
        const logs = res.audit_logs || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-base font-bold text-slate-800 dark:text-slate-100">Xavfsizlik va Tizim Harakatlari Jurnali (Audit Logs)</h3>
                        <p class="text-xs text-slate-500">Tizimdagi barcha avtorizatsiya, navbat olish, bekor qilish va boshqaruv harakatlari monitoringi</p>
                    </div>
                </div>

                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-x-auto">
                    <table class="w-full text-left text-xs">
                        <thead>
                            <tr class="border-b border-slate-100 dark:border-slate-800 text-slate-400 uppercase font-bold">
                                <th class="pb-3">Vaqt</th>
                                <th class="pb-3">Amal</th>
                                <th class="pb-3">Foydalanuvchi</th>
                                <th class="pb-3">Ob'ekt</th>
                                <th class="pb-3">IP Manzil</th>
                                <th class="pb-3">Batafsil</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                            ${logs.length === 0 ? `
                                <tr><td colspan="6" class="py-6 text-center text-slate-400">Audit qaydnomalari mavjud emas.</td></tr>
                            ` : logs.map(l => `
                                <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                                    <td class="py-2.5 mono text-slate-400">${l.created_at}</td>
                                    <td class="py-2.5 font-bold mono text-blue-600 dark:text-blue-400">${l.action}</td>
                                    <td class="py-2.5 text-slate-700 dark:text-slate-300">${l.user_name || 'Tizim'} (${l.user_role || 'anonim'})</td>
                                    <td class="py-2.5 mono text-slate-500">${l.entity_type} #${l.entity_id || ''}</td>
                                    <td class="py-2.5 mono text-slate-400">${l.ip_address || '—'}</td>
                                    <td class="py-2.5 text-slate-500">${l.details || '—'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

// Add Doctor Modal Handlers
function openAddDoctorModal() {
    const modal = document.getElementById("addDoctorModal");
    if (!modal) return;

    // Populate department options
    const deptSelect = document.getElementById("newDocDepartment");
    if (deptSelect && cachedDepartmentsList.length > 0) {
        deptSelect.innerHTML = cachedDepartmentsList.map(d => `
            <option value="${d.id}">${d.name_uz} (${d.code})</option>
        `).join('');
    }
    modal.classList.remove("hidden");
}

function closeAddDoctorModal() {
    const modal = document.getElementById("addDoctorModal");
    if (modal) modal.classList.add("hidden");
}

async function submitNewDoctor() {
    const name = document.getElementById("newDocName")?.value.trim();
    const deptId = document.getElementById("newDocDepartment")?.value;
    const spec = document.getElementById("newDocSpec")?.value.trim();
    const room = document.getElementById("newDocRoom")?.value.trim();
    const phone = document.getElementById("newDocPhone")?.value.trim();
    const duration = parseInt(document.getElementById("newDocDuration")?.value || "20");

    if (!name || !deptId || !spec || !room) {
        showToast("Iltimos, barcha majburiy maydonlarni to'ldiring", "warning");
        return;
    }

    try {
        const payload = {
            full_name: name,
            department_id: parseInt(deptId),
            specialization_uz: spec,
            specialization_ru: spec,
            specialization_en: spec,
            room_number: room,
            phone: phone || "+998901112233",
            appointment_duration: duration,
            working_days: "1,2,3,4,5",
            start_time: "08:30",
            end_time: "17:30"
        };

        const res = await apiCall("/api/doctors", "POST", payload);
        showToast(res.message, "success");
        closeAddDoctorModal();
        loadAdminDoctors();
    } catch (err) {
        showToast(err.message, "error");
    }
}


// =========================================================================
// 7. NEW ADMINISTRATOR MODULES (16 Comprehensive Interactive Modules)
// =========================================================================

// --- MODULE 7: ADMIN AI ASSISTANT ---
async function loadAdminAI() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `
        <div class="space-y-6">
            <div class="p-6 rounded-3xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <div class="flex items-center gap-2 mb-1">
                        <span class="w-3 h-3 rounded-full bg-emerald-400 live-pulse"></span>
                        <span class="text-xs font-bold uppercase tracking-widest text-emerald-400">ADMIN AI INTELLIGENCE</span>
                    </div>
                    <h3 class="text-xl font-black">Poliklinika Boshqaruv AI Yordamchisi</h3>
                    <p class="text-xs text-sky-200 mt-1">Kunlik statistika, navbat tirbandligi, shifokorlar yuklamasi va tizim tahlili bo'yicha aqlli yordamchi</p>
                </div>
            </div>

            <!-- Quick Command Chips -->
            <div class="flex flex-wrap gap-2">
                <button onclick="queryAdminAICustom('Bugungi statistikani va hisobotni ko\\'rsat')" class="px-3.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-bold text-blue-600 dark:text-blue-400 hover:bg-blue-50 shadow-sm">
                    📊 Bugungi statistika
                </button>
                <button onclick="queryAdminAICustom('Eng uzun navbat qaysi shifokorda va yuklama qanday?')" class="px-3.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-bold text-amber-600 dark:text-amber-400 hover:bg-amber-50 shadow-sm">
                    ⏱️ Navbat tirbandligi
                </button>
                <button onclick="queryAdminAICustom('Bugun bekor qilingan va kelmagan bemorlar ro\\'yxati')" class="px-3.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 shadow-sm">
                    ❌ Bekor qilinganlar
                </button>
                <button onclick="queryAdminAICustom('Tizim holati va umumiy tibbiy operatsiyalar xulosasi')" class="px-3.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 shadow-sm">
                    🛡️ Operatsion xulosa
                </button>
            </div>

            <!-- Chat Console Box -->
            <div class="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col h-[460px]">
                <div id="adminAIChatArea" class="flex-1 p-5 overflow-y-auto space-y-3 bg-slate-50/50 dark:bg-slate-950/40 text-xs">
                    <div class="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm max-w-[85%] text-slate-800 dark:text-slate-200">
                        Assalomu alaykum, Administrator! Men <b>ADMIN AI</b> yordamchisiman. Poliklinika statistikasi, shifokorlar faolligi, navbat tirbandligi yoki tizim operatsiyalari bo'yicha har qanday savolingizga javob bera olaman.
                    </div>
                </div>

                <div class="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex gap-2">
                    <input id="adminAIQueryInput" type="text" placeholder="ADMIN AI ga so'rov yuboring (masalan: Bugun nechta bemor qabul qilindi?)..."
                           onkeydown="if(event.key==='Enter')submitAdminAIQuery()"
                           class="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs outline-none">
                    <button onclick="submitAdminAIQuery()" class="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow flex items-center gap-1.5">
                        <span>Yuborish</span>
                    </button>
                </div>
            </div>
        </div>
    `;
}

function queryAdminAICustom(text) {
    const inp = document.getElementById("adminAIQueryInput");
    if (inp) {
        inp.value = text;
        submitAdminAIQuery();
    }
}

async function submitAdminAIQuery() {
    const input = document.getElementById("adminAIQueryInput");
    if (!input || !input.value.trim()) return;
    const query = input.value.trim();
    input.value = "";

    const chatArea = document.getElementById("adminAIChatArea");
    if (!chatArea) return;

    // Render User Query
    chatArea.innerHTML += `
        <div class="flex justify-end">
            <div class="p-3.5 rounded-2xl bg-blue-600 text-white max-w-[85%] font-medium">
                ${escapeHtml(query)}
            </div>
        </div>
    `;
    chatArea.scrollTop = chatArea.scrollHeight;

    // Add Loading Indicator
    const loaderId = `admin-ai-loading-${Date.now()}`;
    chatArea.innerHTML += `
        <div id="${loaderId}" class="flex justify-start">
            <div class="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 flex items-center gap-2">
                <span class="animate-spin text-blue-600">🌀</span> Tahlil qilinmoqda...
            </div>
        </div>
    `;
    chatArea.scrollTop = chatArea.scrollHeight;

    try {
        const res = await apiCall("/api/ai/admin-query", "POST", { query });
        document.getElementById(loaderId)?.remove();

        chatArea.innerHTML += `
            <div class="flex justify-start">
                <div class="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm max-w-[85%] text-slate-800 dark:text-slate-200 leading-relaxed">
                    ${escapeHtml(res.reply).replace(/\n/g, '<br>')}
                </div>
            </div>
        `;
    } catch (err) {
        document.getElementById(loaderId)?.remove();
        chatArea.innerHTML += `
            <div class="flex justify-start">
                <div class="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 max-w-[85%]">
                    ❌ Xatolik yuz berdi: ${err.message}
                </div>
            </div>
        `;
    }
    chatArea.scrollTop = chatArea.scrollHeight;
}

// --- MODULE 8: SYSTEM MONITORING ---
async function loadAdminMonitoring() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Tizim holati diagnostika qilinmoqda...</div>`;

    try {
        const res = await apiCall("/api/monitoring/health");
        const diag = res.diagnostics || res;

        pane.innerHTML = `
            <div class="space-y-6">
                <!-- Header with Action -->
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h3 class="text-base font-black text-slate-900 dark:text-white">AI Tizim Salomatligi va Monitoringi</h3>
                        <p class="text-xs text-slate-500">Haqiqiy vaqtdagi server, CPU, RAM va ma'lumotlar bazasi ko'rsatkichlari</p>
                    </div>
                    <button onclick="createBackupNow()" class="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow flex items-center gap-2">
                        <span>💾 Zaxira nusxa yaratish</span>
                    </button>
                </div>

                <!-- Metrics Grid -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-center">
                        <div class="text-xs text-slate-400 font-bold uppercase mb-1">Health Score</div>
                        <div class="text-4xl font-black mono ${diag.health_score >= 80 ? 'text-emerald-500' : 'text-amber-500'}">${diag.health_score || 100}%</div>
                        <div class="text-[11px] text-slate-400 mt-1">${diag.status ? diag.status.toUpperCase() : 'OPTIMAL'}</div>
                    </div>
                    <div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-center">
                        <div class="text-xs text-slate-400 font-bold uppercase mb-1">CPU Yuklamasi</div>
                        <div class="text-3xl font-black mono text-blue-600 dark:text-blue-400">${diag.cpu_percent || 0}%</div>
                        <div class="text-[11px] text-slate-400 mt-1">Multi-core processor</div>
                    </div>
                    <div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-center">
                        <div class="text-xs text-slate-400 font-bold uppercase mb-1">RAM Xotira</div>
                        <div class="text-3xl font-black mono text-indigo-600 dark:text-indigo-400">${diag.memory_percent || 0}%</div>
                        <div class="text-[11px] text-slate-400 mt-1">Virtual memory</div>
                    </div>
                    <div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-center">
                        <div class="text-xs text-slate-400 font-bold uppercase mb-1">DB So'rov Vaqti</div>
                        <div class="text-3xl font-black mono text-teal-600 dark:text-teal-400">${(diag.database && diag.database.latency_ms) || '1.8'} ms</div>
                        <div class="text-[11px] text-slate-400 mt-1">SQLite WAL</div>
                    </div>
                </div>

                <!-- AI Diagnostic Recommendations -->
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
                    <h4 class="font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
                        <span>🤖 AI Diagnostik Xulosasi va Tavsiyalari</span>
                    </h4>
                    <p class="text-xs text-slate-600 dark:text-slate-300">
                        ${(diag.ai_diagnostics && diag.ai_diagnostics.summary) || 'Tizim barqaror holatda ishlamoqda.'}
                    </p>
                    <div class="space-y-1.5 pt-2">
                        ${((diag.ai_diagnostics && diag.ai_diagnostics.suggestions) || []).map(s => `
                            <div class="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
                                <span class="text-emerald-500">✓</span> <span>${s}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

async function createBackupNow() {
    try {
        const res = await apiCall("/api/monitoring/create-backup", "POST", {});
        showToast(res.message || "Zaxira nusxa yaratildi!", "success");
        if (currentAdminTab === "backups") loadAdminBackups();
    } catch (err) {
        showToast(err.message, "error");
    }
}

// --- MODULE 2: PATIENTS MANAGEMENT ---
async function loadAdminPatients() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Bemorlar ro'yxati yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/patients");
        const patients = res.patients || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h3 class="text-base font-black text-slate-900 dark:text-white">Bemorlar Bazasi (${patients.length})</h3>
                        <p class="text-xs text-slate-500">Poliklinikada ro'yxatdan o'tgan fuqarolar va ularning ma'lumotlari</p>
                    </div>
                </div>

                <div class="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 dark:bg-slate-800/60 text-slate-500 font-bold uppercase border-b border-slate-200 dark:border-slate-800">
                                <tr>
                                    <th class="p-4">F.I.Sh</th>
                                    <th class="p-4">JShShIR (PINFL)</th>
                                    <th class="p-4">Tug'ilgan sana</th>
                                    <th class="p-4">Telefon</th>
                                    <th class="p-4">Manzil</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                                ${patients.map(p => `
                                    <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                                        <td class="p-4 font-bold text-slate-900 dark:text-white">${p.full_name}</td>
                                        <td class="p-4 mono font-bold text-blue-600 dark:text-blue-400">${p.masked_pinfl || p.pinfl}</td>
                                        <td class="p-4">${p.birth_date || '-'}</td>
                                        <td class="p-4 mono">${p.phone || '-'}</td>
                                        <td class="p-4 text-slate-500">${p.address || '-'}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

// --- MODULE 4: DEPARTMENTS MANAGEMENT ---
async function loadAdminDepartments() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Bo'limlar yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/departments");
        const departments = res.departments || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h3 class="text-base font-black text-slate-900 dark:text-white">Tibbiy Bo'limlar (${departments.length})</h3>
                        <p class="text-xs text-slate-500">Ixtisoslashgan bo'limlar, xonalar oralig'i va mutaxassislar taqsimoti</p>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    ${departments.map(d => `
                        <div class="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex flex-col justify-between">
                            <div>
                                <div class="flex items-center justify-between mb-2">
                                    <span class="px-2.5 py-1 rounded-lg bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-black mono text-xs">${d.code}</span>
                                    <span class="text-xs text-emerald-500 font-bold">Faol</span>
                                </div>
                                <h4 class="font-bold text-sm text-slate-900 dark:text-white">${d.name_uz}</h4>
                                <p class="text-xs text-slate-500 mt-1">${d.description_uz || 'Tibbiy xizmatlar ko\\'rsatish'}</p>
                            </div>
                            <div class="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex justify-between">
                                <span>Xonalar: <b>${d.room_range || '-'}</b></span>
                                <span>Shifokorlar: <b>${d.doctor_count || 1}</b></span>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

// --- MODULE 10: FINANCIAL STATISTICS ---
async function loadAdminFinancial() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Moliyaviy ko'rsatkichlar yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/monitoring/financial-stats");

        pane.innerHTML = `
            <div class="space-y-6">
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h3 class="text-base font-black text-slate-900 dark:text-white">Moliyaviy Ko'rsatkichlar va Xizmatlar Tahlili</h3>
                        <p class="text-xs text-slate-500">Ko'rsatilgan tibbiy xizmatlar, pullik tahlillar va kunlik tushumlar</p>
                    </div>
                </div>

                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-center">
                        <div class="text-xs text-slate-400 font-bold uppercase mb-1">Bugungi tushum</div>
                        <div class="text-2xl md:text-3xl font-black mono text-emerald-600 dark:text-emerald-400">
                            ${new Intl.NumberFormat('uz-UZ').format(res.today_estimated_revenue || 0)} so'm
                        </div>
                    </div>
                    <div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-center">
                        <div class="text-xs text-slate-400 font-bold uppercase mb-1">Oylik jami tushum</div>
                        <div class="text-2xl md:text-3xl font-black mono text-blue-600 dark:text-blue-400">
                            ${new Intl.NumberFormat('uz-UZ').format(res.monthly_estimated_revenue || 0)} so'm
                        </div>
                    </div>
                    <div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-center">
                        <div class="text-xs text-slate-400 font-bold uppercase mb-1">Tugallangan qabullar</div>
                        <div class="text-3xl font-black mono text-indigo-600 dark:text-indigo-400">${res.completed_appointments_count || 0} ta</div>
                    </div>
                    <div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-center">
                        <div class="text-xs text-slate-400 font-bold uppercase mb-1">O'rtacha chek</div>
                        <div class="text-2xl font-black mono text-amber-600 dark:text-amber-400">
                            ${new Intl.NumberFormat('uz-UZ').format(res.average_fee_per_patient || 45000)} so'm
                        </div>
                    </div>
                </div>

                <div class="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 text-amber-900 dark:text-amber-200 text-xs border border-amber-200 dark:border-amber-900/60">
                    ℹ️ <b>Eslatma:</b> Ushbu raqamlar elektron navbat bo'yicha yakunlangan pullik xizmatlar va konsultatsiyalar hisobi asosida taxminiy shakllantirilgan bo'lib, rasmiy buxgalteriya balansi bilan taqqoslanadi.
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

// --- MODULE 11: SERVICES MANAGEMENT ---
async function loadAdminServicesTab() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Xizmatlar ro'yxati yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/services");
        const services = res.services || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h3 class="text-base font-black text-slate-900 dark:text-white">Klinika Tibbiy Xizmatlari (${services.length})</h3>
                        <p class="text-xs text-slate-500">Tashxislar, laboratoriya tahlillari va xizmat narxlari nazorati</p>
                    </div>
                </div>

                <div class="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 dark:bg-slate-800/60 text-slate-500 font-bold uppercase border-b border-slate-200 dark:border-slate-800">
                                <tr>
                                    <th class="p-4">Xizmat nomi</th>
                                    <th class="p-4">Bo'lim</th>
                                    <th class="p-4">Davomiyligi</th>
                                    <th class="p-4">Narxi</th>
                                    <th class="p-4">Holat</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                                ${services.map(s => `
                                    <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                                        <td class="p-4 font-bold text-slate-900 dark:text-white">${s.name_uz}</td>
                                        <td class="p-4">${s.department_name_uz || '-'}</td>
                                        <td class="p-4">${s.duration_minutes || 20} daqiqa</td>
                                        <td class="p-4 font-bold text-emerald-600 dark:text-emerald-400">
                                            ${s.price ? new Intl.NumberFormat('uz-UZ').format(s.price) + " so'm" : 'Bepul'}
                                        </td>
                                        <td class="p-4"><span class="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold">Faol</span></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

// --- MODULE 12: KNOWLEDGE BASE ---
async function loadAdminKnowledgeBase() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Bilimlar bazasi yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/ai/knowledge-base");
        const entries = res.entries || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h3 class="text-base font-black text-slate-900 dark:text-white">AI Bilimlar Bazasi (${entries.length})</h3>
                        <p class="text-xs text-slate-500">MEDI AI bemorlarga beradigan tasdiqlangan savol-javoblar ro'yxati</p>
                    </div>
                </div>

                <div class="space-y-3">
                    ${entries.map(e => `
                        <div class="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm space-y-2">
                            <div class="flex items-center justify-between">
                                <span class="px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-bold text-xs uppercase">${e.category}</span>
                                <span class="text-xs text-slate-400">${e.created_at ? e.created_at.slice(0, 10) : ''}</span>
                            </div>
                            <h4 class="font-bold text-sm text-slate-900 dark:text-white">❓ ${e.question}</h4>
                            <p class="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800 leading-relaxed">
                                💡 ${e.answer}
                            </p>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

// --- MODULE 13: ANNOUNCEMENTS ---
async function loadAdminAnnouncements() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">E'lonlar yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/announcements");
        const list = res.announcements || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h3 class="text-base font-black text-slate-900 dark:text-white">Poliklinika E'lonlari va Bildirishnomalari</h3>
                        <p class="text-xs text-slate-500">Sayt yuqorisidagi xabarlar va muhim yangiliklar</p>
                    </div>
                </div>

                <div class="space-y-3">
                    ${list.map(a => `
                        <div class="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex items-start justify-between gap-4">
                            <div>
                                <div class="flex items-center gap-2 mb-1.5">
                                    <span class="px-2 py-0.5 rounded-full ${a.type === 'warning' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'} text-[10px] font-bold uppercase">${a.type}</span>
                                    <span class="text-xs font-bold text-slate-900 dark:text-white">${a.title}</span>
                                </div>
                                <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">${a.content}</p>
                            </div>
                            <span class="text-[11px] text-slate-400 whitespace-nowrap">${a.created_at ? a.created_at.slice(0, 10) : ''}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

// --- MODULE 14: REVIEWS ---
async function loadAdminReviews() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Sharhlar yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/reviews/all");
        const reviews = res.reviews || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h3 class="text-base font-black text-slate-900 dark:text-white">Bemorlar Sharhlari va Baholari (${reviews.length})</h3>
                        <p class="text-xs text-slate-500">Shifokorlar xizmatiga qo'yilgan baholar va izohlar</p>
                    </div>
                </div>

                <div class="space-y-3">
                    ${reviews.length === 0 ? `<div class="p-8 text-center text-slate-400 text-xs">Hozircha sharhlar mavjud emas</div>` : ''}
                    ${reviews.map(r => `
                        <div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
                            <div class="flex items-center justify-between mb-1.5">
                                <div class="font-bold text-xs text-slate-900 dark:text-white">${r.patient_name || 'Bemor'} ➔ ${r.doctor_name || 'Shifokor'}</div>
                                <span class="text-amber-400 font-bold text-xs">★ ${r.rating} / 5</span>
                            </div>
                            <p class="text-xs text-slate-600 dark:text-slate-300">${r.comment || 'Izoh qoldirilmagan'}</p>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

// --- MODULE 15: USERS & ROLES ---
async function loadAdminUsers() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Foydalanuvchilar yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/auth/users");
        const users = res.users || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h3 class="text-base font-black text-slate-900 dark:text-white">Tizim Foydalanuvchilari (${users.length})</h3>
                        <p class="text-xs text-slate-500">Administratorlar, shifokorlar va bemorlarning tizim hisoblari</p>
                    </div>
                </div>

                <div class="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 dark:bg-slate-800/60 text-slate-500 font-bold uppercase border-b border-slate-200 dark:border-slate-800">
                                <tr>
                                    <th class="p-4">ID</th>
                                    <th class="p-4">Login / Email</th>
                                    <th class="p-4">Rol</th>
                                    <th class="p-4">Holat</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                                ${users.map(u => `
                                    <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                                        <td class="p-4 mono font-bold">${u.id}</td>
                                        <td class="p-4 font-bold text-slate-900 dark:text-white">${u.username || u.email || u.phone}</td>
                                        <td class="p-4">
                                            <span class="px-2.5 py-0.5 rounded-full font-bold text-[10px] uppercase ${u.role === 'admin' ? 'bg-purple-100 text-purple-700' : u.role === 'doctor' ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'}">
                                                ${u.role}
                                            </span>
                                        </td>
                                        <td class="p-4">
                                            <span class="px-2 py-0.5 rounded-full ${u.is_active ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'} text-[10px] font-bold">
                                                ${u.is_active ? 'Faol' : 'Nofaol'}
                                            </span>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

async function loadAdminRoles() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `
        <div class="space-y-6">
            <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                <h3 class="text-base font-black text-slate-900 dark:text-white">Rollar va Huquqlar Matritsasi (RBAC)</h3>
                <p class="text-xs text-slate-500">Tizim xavfsizlik chegaralari va foydalanuvchilar vakolatlari</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                    <div class="flex items-center gap-2 mb-2">
                        <span class="px-2.5 py-1 rounded-lg bg-purple-100 text-purple-700 font-bold text-xs uppercase">Administrator</span>
                    </div>
                    <ul class="text-xs text-slate-600 dark:text-slate-300 space-y-1.5 list-disc list-inside">
                        <li>Barcha 16 ta modul ustidan to'liq nazorat</li>
                        <li>Shifokorlar va bo'limlarni tahrirlash</li>
                        <li>Kunlik navbatni boshqarish va tozalash</li>
                        <li>Zaxira nusxalar olish va tizim sozlamalari</li>
                    </ul>
                </div>
                <div class="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                    <div class="flex items-center gap-2 mb-2">
                        <span class="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-700 font-bold text-xs uppercase">Shifokor</span>
                    </div>
                    <ul class="text-xs text-slate-600 dark:text-slate-300 space-y-1.5 list-disc list-inside">
                        <li>Shaxsiy xona navbatini chaqirish</li>
                        <li>Qabulni yakunlash va xulosa kiritish</li>
                        <li>Bemor kelmaganligini belgilash</li>
                        <li>Boshqa shifokorlar bemorlarini ko'ra olmaslik (Izolyatsiya)</li>
                    </ul>
                </div>
            </div>
        </div>
    `;
}

// --- MODULE 16: BACKUPS ---
async function loadAdminBackups() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `<div class="p-8 text-center text-slate-400 text-xs">Zaxira nusxalar yuklanmoqda...</div>`;

    try {
        const res = await apiCall("/api/monitoring/backups");
        const backups = res.backups || [];

        pane.innerHTML = `
            <div class="space-y-6">
                <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h3 class="text-base font-black text-slate-900 dark:text-white">Ma'lumotlar Bazasi Zaxira Nusxalari (Backups)</h3>
                        <p class="text-xs text-slate-500">Avtomatik va qo'lda olingan SQLite xavfsizlik nusxalari</p>
                    </div>
                    <button onclick="createBackupNow()" class="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow">
                        💾 Hozir nusxa olish
                    </button>
                </div>

                <div class="space-y-2">
                    ${backups.length === 0 ? `<div class="p-8 text-center text-slate-400 text-xs">Hozircha saqlangan zaxira nusxalar yo'q.</div>` : ''}
                    ${backups.map(b => `
                        <div class="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex items-center justify-between text-xs">
                            <div class="flex items-center gap-3">
                                <span class="text-lg">💾</span>
                                <div>
                                    <div class="font-bold text-slate-900 dark:text-white mono">${b.filename}</div>
                                    <div class="text-[11px] text-slate-400">${b.size_kb} KB • ${b.created_at || ''}</div>
                                </div>
                            </div>
                            <a href="/api/monitoring/download-backup/${b.filename}" class="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-blue-600 dark:text-blue-400 font-bold text-xs">
                                Yuklab olish ⬇
                            </a>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    } catch (err) {
        pane.innerHTML = `<div class="p-6 text-center text-rose-500 text-xs">${err.message}</div>`;
    }
}

// --- MODULE 14: SETTINGS ---
async function loadAdminSettings() {
    const pane = document.getElementById("adminTabPane");
    if (!pane) return;

    pane.innerHTML = `
        <div class="space-y-6 max-w-2xl">
            <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
                <h3 class="text-base font-black text-slate-900 dark:text-white mb-1">Poliklinika Tizim Sozlamalari</h3>
                <p class="text-xs text-slate-500 mb-6">Tashkilot rekvizitlari, ish vaqti va xavfsizlik qoidalari</p>

                <div class="space-y-4 text-xs">
                    <div>
                        <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Muassasa nomi</label>
                        <input type="text" value="Markaziy 1-sonli Ko'p Tarmoqli Poliklinika" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                    </div>
                    <div>
                        <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Manzil</label>
                        <input type="text" value="Toshkent shahri, Chilonzor tumani, Bunyodkor ko'chasi 42-uy" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                    </div>
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Call-markaz telefoni</label>
                            <input type="text" value="+998 71 200-00-11" class="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 mono">
                        </div>
                        <div>
                            <label class="block font-bold text-slate-700 dark:text-slate-300 mb-1">Ish vaqti</label>
                            <input type="text" value="08:00 - 18:00" class="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 mono">
                        </div>
                    </div>
                    <div class="pt-4">
                        <button onclick="showToast('Sozlamalar saqlandi!', 'success')" class="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow">
                            Sozlamalarni saqlash
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}
